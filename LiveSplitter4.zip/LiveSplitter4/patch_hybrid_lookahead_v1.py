#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil

target = Path("core/generators/hybrid.py")

if not target.exists():
    print("[ERROR] hybrid.py not found")
    exit(1)

text = target.read_text(encoding="utf-8")

backup = Path("core/generators/hybrid.lookahead_v1.bak")
shutil.copy2(target, backup)

old = """            if (
                best is not None
                and best_score >= self.match_threshold
            ):
                detected = best.time
"""

new = """            if (
                best is not None
                and best_score >= self.match_threshold
            ):

                # Look ahead :
                # éviter de donner une transition à une piste
                # si la suivante correspond beaucoup mieux

                keep_current = True

                if index + 1 < len(setlist):
                    next_expected = setlist[index + 1].get(
                        "time",
                        expected
                    )

                    current_delta = abs(
                        best.time - expected
                    )

                    next_delta = abs(
                        best.time - next_expected
                    )

                    if next_delta + 120 < current_delta:
                        keep_current = False

                if keep_current:
                    detected = best.time
                else:
                    detected = max(
                        expected,
                        last_detected
                    )
                    best_score = 0
"""

if old not in text:
    print("[ERROR] target block not found")
    exit(1)

text = text.replace(old, new, 1)

target.write_text(text, encoding="utf-8")

print("[OK] lookahead patch applied")
print("[OK] backup:", backup)
