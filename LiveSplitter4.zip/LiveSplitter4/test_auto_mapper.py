# -*- coding: utf-8 -*-

"""
Test Auto Mapper
"""


from core.auto_mapper import AutoMapper


mapper = AutoMapper(
    None
)


markers = [

    {
        "time": 72,
        "score": 90,
        "quality": 90,
        "type": "silence"
    },

    {
        "time": 480,
        "score": 95,
        "quality": 95,
        "type": "silence"
    },

    {
        "time": 900,
        "score": 80,
        "quality": 80,
        "type": "silence"
    }

]


tracks = mapper.build_tracks(
    markers
)


print(
    tracks
)
