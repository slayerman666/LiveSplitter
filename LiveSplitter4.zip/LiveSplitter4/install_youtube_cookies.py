#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import shutil


DEST = "/storage/emulated/0/LiveSplitter4/cookies.txt"


SEARCH_PATHS = [
    "/storage/emulated/0/Download",
    "/storage/emulated/0/Downloads",
    "/storage/emulated/0/Documents",
    "/storage/emulated/0"
]


def find_cookie():

    for base in SEARCH_PATHS:

        if not os.path.exists(base):
            continue

        for root, dirs, files in os.walk(base):

            for f in files:

                if f.lower() == "cookies.txt":

                    return os.path.join(
                        root,
                        f
                    )

    return None



def validate(path):

    try:

        with open(
            path,
            "r",
            encoding="utf-8",
            errors="ignore"
        ) as f:

            content = f.read(500)

        return (
            "youtube.com" in content
            or ".youtube.com" in content
        )

    except:

        return False



print()
print("=== YouTube cookies installer ===")
print()


cookie = find_cookie()


if not cookie:

    print("[ERROR] cookies.txt introuvable")
    print()
    print("Place ton fichier dans Download/")
    exit(1)



print("[FOUND]")
print(cookie)


if not validate(cookie):

    print()
    print("[WARN] Le fichier ne semble pas contenir YouTube")
    print("Copie quand même ? (y/n)")

    if input("> ").lower() != "y":
        exit()



os.makedirs(
    os.path.dirname(DEST),
    exist_ok=True
)


shutil.copy2(
    cookie,
    DEST
)


print()
print("[OK] Cookies installés")
print(DEST)
