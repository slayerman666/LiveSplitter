# -*- coding: utf-8 -*-

"""
Test Analysis Manager
"""

from core.project import Project
from core.analysis import AnalysisManager


project = Project(
    "projects/Test_Project"
)

project.load()


manager = AnalysisManager(
    project
)


manager.create_analysis()


manager.save_result(
    "test_detector",
    {
        "markers": [
            120,
            250
        ]
    }
)


print("\nAnalysis:")

print(
    manager.get_analysis()
)


print("\nProject recap:")

print(
    project.recap()
)
