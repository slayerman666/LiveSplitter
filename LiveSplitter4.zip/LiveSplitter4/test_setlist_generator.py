# -*- coding: utf-8 -*-

"""
LiveSplitter V4

Test Setlist Generator
"""


from core.project import Project
from core.setlist_generator import SetlistGenerator



for mode in [
    "as_is",
    "auto",
    "hybrid"
]:

    print("\nMode:", mode)


    project = Project(
        "projects/Test_Project"
    )


    project.load()


    generator = SetlistGenerator(
        project,
        mode
    )


    try:

        result = generator.generate()


        print(
            result
        )


    except Exception as error:

        print(
            error
        )
