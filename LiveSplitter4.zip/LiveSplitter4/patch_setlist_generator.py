#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch LiveSplitter V5.2

Fix:
- load_as_is() ne dépend plus de project.setlist_tracks
- recharge la setlist depuis le fichier projet
"""

from pathlib import Path


FILE = Path("core/setlist_generator.py")


OLD = '''        manager_data["tracks"] = (
            self.project.setlist_tracks
            if hasattr(
                self.project,
                "setlist_tracks"
            )
            else []
        )
'''


NEW = '''        from core.setlist import SetlistManager

        manager = SetlistManager(
            self.project
        )

        manager_data["tracks"] = manager.parse(
            setlist_file
        )
'''


def main():

    if not FILE.exists():
        print("[ERROR] File not found:", FILE)
        return

    content = FILE.read_text(
        encoding="utf-8"
    )

    if OLD not in content:
        print(
            "[ERROR] Target block not found"
        )
        return

    backup = FILE.with_suffix(
        ".py.bak"
    )

    backup.write_text(
        content,
        encoding="utf-8"
    )

    content = content.replace(
        OLD,
        NEW
    )

    FILE.write_text(
        content,
        encoding="utf-8"
    )

    print("[OK] Patch applied")
    print("[OK] Backup:", backup)


if __name__ == "__main__":
    main()
