#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch LiveSplitter V4
Ajout persistance NormalizedSetlist dans Project Manager
"""

import os


FILE = "core/project.py"


MARKER = """
    def recap(self):
"""


INSERT = """
    def save_normalized_setlist(self, data):

        filename = self.paths["normalized_setlist"]

        os.makedirs(
            os.path.dirname(filename),
            exist_ok=True
        )

        with open(
            filename,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                data,
                f,
                indent=4,
                ensure_ascii=False
            )

        log(
            "NORMALIZED SETLIST SAVED",
            self
        )


    def load_normalized_setlist(self):

        filename = self.paths["normalized_setlist"]

        if not os.path.exists(filename):

            log(
                "NORMALIZED SETLIST NOT FOUND",
                self
            )

            return None


        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)


        log(
            "NORMALIZED SETLIST LOADED",
            self
        )

        return data


"""


if not os.path.exists(FILE):
    raise FileNotFoundError(FILE)


with open(
    FILE,
    "r",
    encoding="utf-8"
) as f:

    content = f.read()


if INSERT.strip() in content:
    print("[INFO] Patch déjà appliqué")
    exit()


if MARKER not in content:
    raise Exception(
        "Bloc recap() introuvable - aucun changement effectué"
    )


content = content.replace(
    MARKER,
    INSERT + MARKER
)


with open(
    FILE,
    "w",
    encoding="utf-8"
) as f:

    f.write(content)


print("[OK] core/project.py patched")
print("[OK] NormalizedSetlist persistence added")
print("[OK] Logging added")
