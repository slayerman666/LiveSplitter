filename = "core/menus/splitter_menu.py"

with open(filename, "r", encoding="utf-8") as f:
    lines = f.readlines()

for i, line in enumerate(lines):
    if line.strip() == "try:" and i > 100 and i < 120:
        lines[i] = "            try:\n"
        print("[OK] Indentation try corrigée ligne", i + 1)
        break
else:
    print("[WARN] try non trouvé")

with open(filename, "w", encoding="utf-8") as f:
    f.writelines(lines)
