# -*- coding: utf-8 -*-

"""
Test Output Manager
"""

from core.project import Project
from core.output import OutputManager


project = Project(
    "projects/Test_Project"
)

project.load()


manager = OutputManager(
    project
)


manager.initialize()


print("\nOutput:")

print(
    manager.get_output()
)


print("\nProject recap:")

print(
    project.recap()
)
