#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch Splitter Menu V5
Intégration NormalizedSetlist + Builders
"""

filename = "core/menus/splitter_menu.py"


with open(filename, "r", encoding="utf-8") as f:
    data = f.read()


old = """                project_dir = project.path           
                splitter = Splitter(                                     
                    project_dir
                )
                splitter.run()
"""


new = """                from core.builders.as_is_builder import AsIsBuilder
                from core.builders.auto_builder import AutoBuilder
                from core.builders.hybrid_builder import HybridBuilder

                print()
                print("=== SETLIST MODE ===")
                print("1) AS_IS")
                print("2) AUTO")
                print("3) HYBRID")

                mode = input("Choice : ").strip()

                if mode == "1":
                    builder = AsIsBuilder(project)

                elif mode == "2":
                    builder = AutoBuilder(project)

                elif mode == "3":
                    builder = HybridBuilder(project)

                else:
                    print("[WARN] Invalid mode")
                    input("ENTER...")
                    continue

                setlist = builder.generate()

                print()
                print("[SETLIST READY]")
                print(
                    f"Mode : {setlist.mode}"
                )
                print(
                    f"Tracks : {setlist.count()}"
                )

                splitter = Splitter(
                    project.path
                )

                splitter.run(
                    setlist
                )
"""


if old not in data:
    print("[WARN] Bloc Splitter V4 introuvable")
else:
    data = data.replace(old, new, 1)

    with open(filename, "w", encoding="utf-8") as f:
        f.write(data)

    print("[OK] splitter_menu.py patched for V5 pipeline")
