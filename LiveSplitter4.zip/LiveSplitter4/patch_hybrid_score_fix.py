#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.1
Fix Hybrid threshold using calculated score
"""

from pathlib import Path
import shutil


FILE = Path("core/generators/hybrid.py")


if not FILE.exists():
    raise SystemExit("hybrid.py introuvable")


backup = FILE.with_suffix(".py.scorefix.bak")

shutil.copy(
    FILE,
    backup
)

print(f"[OK] Backup : {backup}")


content = FILE.read_text(
    encoding="utf-8"
)


old = """if best and best[1].score >= self.match_threshold:"""


new = """if best and best_value >= self.match_threshold:"""


if old in content:

    content = content.replace(
        old,
        new,
        1
    )

    print(
        "[OK] Seuil corrigé"
    )

else:

    print(
        "[WARN] Ligne non trouvée"
    )


FILE.write_text(
    content,
    encoding="utf-8"
)


print(
    "[OK] Patch terminé"
)
