#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter Builder V1.2

Pipeline :
- Analyzer
- AutoMapper
- Splitter
- Tagger
- Playlist

Options :
--reanalyze
--clean
--retag
--playlist

Compatible Termux / Android
"""

import os
import sys
import json
import argparse
import subprocess


VERSION = "1.2"



def run_step(name, command):

    print()
    print("=" * 50)
    print(f"[STEP] {name}")
    print("=" * 50)
    print()


    result = subprocess.run(
        command
    )


    if result.returncode != 0:

        print(
            f"[ERROR] {name}"
        )

        sys.exit(
            result.returncode
        )


    print(
        f"[OK] {name}"
    )



def load_project(project):

    filename = os.path.join(
        project,
        "project.json"
    )


    with open(
        filename,
        "r",
        encoding="utf-8"
    ) as f:

        return json.load(f)



def clean_project(project):

    folders = [

        os.path.join(
            project,
            "Output",
            "Tracks"
        ),

        os.path.join(
            project,
            "Output",
            "Playlist"
        )

    ]


    count = 0


    for folder in folders:

        if not os.path.exists(folder):
            continue


        for file in os.listdir(folder):

            path = os.path.join(
                folder,
                file
            )


            if os.path.isfile(path):

                os.remove(path)

                count += 1


    print(
        f"[CLEAN] {count} fichiers supprimés"
    )



def analysis_exists(project):

    return os.path.exists(

        os.path.join(

            project,
            "Analysis",
            "Results",
            "Concert_analysis.json"

        )

    )



def count_tracks(project):

    folder = os.path.join(
        project,
        "Output",
        "Tracks"
    )


    if not os.path.exists(folder):

        return 0


    return len(

        [

            f for f in os.listdir(folder)

            if f.lower().endswith(".mp3")

        ]

    )



def get_total_duration(project):

    filename = os.path.join(

        project,
        "project.json"

    )


    try:

        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)


        return int(

            data.get(
                "source",
                {}
            )
            .get(
                "info",
                {}
            )
            .get(
                "duration",
                0
            )

        )


    except:

        return 0



def format_time(seconds):

    h = seconds // 3600

    m = (seconds % 3600) // 60

    s = seconds % 60


    if h:

        return f"{h:02d}:{m:02d}:{s:02d}"


    return f"{m:02d}:{s:02d}"



def summary(project, analysis_status):

    data = load_project(
        project
    )


    metadata = data.get(
        "metadata",
        {}
    )


    tracks = count_tracks(
        project
    )


    duration = get_total_duration(
        project
    )


    playlist = os.path.join(

        project,
        "Output",
        "Playlist",
        "playlist.m3u"

    )


    artwork = os.path.exists(

        metadata.get(
            "artwork",
            ""

        )

    )


    print()

    print("=" * 50)

    print(
        "=== BUILD SUMMARY ==="
    )

    print("=" * 50)

    print()


    print(
        f"Artist   : {metadata.get('artist','')}"
    )

    print(
        f"Album    : {metadata.get('album','')}"
    )

    print(
        f"Analysis : {analysis_status}"
    )

    print(
        f"Tracks   : {tracks}"
    )

    print(
        f"Duration : {format_time(duration)}"
    )

    print(
        f"Artwork  : {'YES' if artwork else 'NO'}"
    )

    print(
        f"Playlist : {'YES' if os.path.exists(playlist) else 'NO'}"
    )

    print()

    print(
        f"Output : {project}/Output"
    )

    print()



def main():

    parser = argparse.ArgumentParser()


    parser.add_argument(
        "project"
    )

    parser.add_argument(
        "--reanalyze",
        action="store_true"
    )

    parser.add_argument(
        "--clean",
        action="store_true"
    )

    parser.add_argument(
        "--retag",
        action="store_true"
    )

    parser.add_argument(
        "--playlist",
        action="store_true"
    )


    args = parser.parse_args()


    project = args.project



    print()

    print(
        f"=== LiveSplitter Bootleg Builder V{VERSION} ==="
    )

    print()

    print(
        f"[PROJECT] {project}"
    )



    if args.clean:

        clean_project(
            project
        )

        return



    data = load_project(
        project
    )


    source = data.get(
        "source",
        {}
    ).get(
        "file"
    )


    if not source:

        print(
            "[ERROR] Source absente"
        )

        sys.exit(1)



    if args.playlist:

        run_step(
            "Playlist",
            [
                "python",
                "core/playlist.py",
                project
            ]
        )

        summary(
            project,
            "SKIP"
        )

        return



    if args.retag:

        run_step(
            "Tagger",
            [
                "python",
                "core/tagger.py",
                project
            ]
        )

        summary(
            project,
            "SKIP"
        )

        return



    if not analysis_exists(project) or args.reanalyze:

        analysis_status = "NEW"


        run_step(

            "Analyzer",

            [
                "python",
                "core/analyzer.py",
                source
            ]

        )


    else:

        analysis_status = "CACHE"

        print(
            "[CACHE] Analyse existante utilisée"
        )



    run_step(

        "AutoMapper",

        [
            "python",
            "core/auto_mapper.py",
            project
        ]

    )


    run_step(

        "Splitter",

        [
            "python",
            "core/splitter.py",
            project
        ]

    )


    run_step(

        "Tagger",

        [
            "python",
            "core/tagger.py",
            project
        ]

    )


    run_step(

        "Playlist",

        [
            "python",
            "core/playlist.py",
            project
        ]

    )


    summary(
        project,
        analysis_status
    )



if __name__ == "__main__":

    main()
