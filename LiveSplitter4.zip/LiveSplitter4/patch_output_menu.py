from pathlib import Path

p = Path("menu.py")

txt = p.read_text(encoding="utf-8")


start = txt.find("def output_manager_menu():")

end = txt.find("def log_manager_menu():")


if start == -1 or end == -1:
    print("Fonctions repères introuvables.")
    raise SystemExit(1)


new_block = '''def output_manager_menu():

    if not require_project():

        return

    from core.menus.output_menu import output_menu

    output_menu(
        CURRENT_PROJECT
    )


'''


txt = txt[:start] + new_block + txt[end:]


p.write_text(
    txt,
    encoding="utf-8"
)

print("Patch output menu appliqué.")
