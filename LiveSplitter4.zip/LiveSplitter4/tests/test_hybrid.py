#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Hybrid Engine Test

Test isolé du moteur Hybrid
"""

from core.generators.hybrid import apply_hybrid


# ==================================================
# SETLIST SIMULEE
# ==================================================

setlist = [

    {
        "number": 1,
        "title": "Tipping Point",
        "time": 0
    },

    {
        "number": 2,
        "title": "Hangar 18",
        "time": 266
    },

    {
        "number": 3,
        "title": "Take No Prisoners",
        "time": 598
    },

    {
        "number": 4,
        "title": "Sweating Bullets",
        "time": 800
    },

    {
        "number": 5,
        "title": "Holy Wars",
        "time": 3812
    }

]


# ==================================================
# TRANSITIONS DETECTEES SIMULEES
# ==================================================

transitions = [

    {
        "time": 270,
        "score": 94,
        "source": "silence"
    },

    {
        "time": 266,
        "score": 82,
        "source": "energy"
    },

    {
        "time": 598,
        "score": 91,
        "source": "silence"
    },

    {
        "time": 605,
        "score": 70,
        "source": "energy"
    },

    {
        "time": 803,
        "score": 89,
        "source": "silence"
    },

    {
        "time": 120,
        "score": 20,
        "source": "noise"
    },

    {
        "time": 3810,
        "score": 96,
        "source": "silence"
    }

]


# ==================================================
# EXECUTION
# ==================================================

print()
print("=" * 60)
print(" HYBRID ENGINE TEST")
print("=" * 60)
print()


result = apply_hybrid(
    setlist,
    transitions,
    window=30
)


# ==================================================
# REPORT
# ==================================================

for track in result:

    print(
        f'{track["number"]:02d} - '
        f'{track["title"]:<25} '
        f'{track["detected"]:>5}s '
        f'{track["status"]:<10} '
        f'{track["correction"]:+d}s '
        f'⭐{track["score"]}'
    )


print()
print("=" * 60)
print(" ALTERNATIVES")
print("=" * 60)
print()


for track in result:

    if track.get("alternatives"):

        print(track["title"])

        for alt in track["alternatives"]:

            print(
                "   ",
                alt
            )

        print()
