#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Test AUTO Builder
"""


from core.builders.auto_builder import (
    AutoBuilder
)


def main():

    print("=" * 60)
    print(" AUTO BUILDER TEST ")
    print("=" * 60)


    fake_auto_output = {

        "tracks": [

            {
                "number": 1,
                "title": "Tipping Point",
                "start": 0,
                "end": 270,
                "duration": 270,
                "confidence": 100,
                "source": "fusion"
            },

            {
                "number": 2,
                "title": "Hangar 18",
                "start": 270,
                "end": 598,
                "duration": 328,
                "confidence": 92,
                "source": "fusion"
            },

            {
                "number": 3,
                "title": "Take No Prisoners",
                "start": 598,
                "end": 803,
                "duration": 205,
                "confidence": 95,
                "source": "fusion"
            },

            {
                "number": 4,
                "title": "Holy Wars",
                "start": 3810,
                "end": 4200,
                "duration": 390,
                "confidence": 96,
                "source": "fusion"
            }

        ]

    }


    builder = AutoBuilder()


    result = builder.build(
        fake_auto_output
    )


    print()

    print(
        "MODE :",
        result.mode
    )

    print(
        "TRACKS :",
        result.count()
    )

    print()


    for track in result.tracks:

        print(

            f"{track.number:02d} - "
            f"{track.title:<25} "
            f"{track.start:>5}s -> "
            f"{track.end:>5}s "
            f"⭐{track.confidence} "
            f"[{track.source}]"

        )


if __name__ == "__main__":

    main()
