#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Test AS_IS Builder
"""


from core.builders.as_is_builder import (
    AsIsBuilder
)


def main():


    print("=" * 60)
    print(" AS_IS BUILDER TEST ")
    print("=" * 60)


    fake_generator_output = {

        "status": True,

        "mode": "as_is",

        "tracks": [

            {
                "number": 1,
                "title": "Tipping Point",
                "timestamp": "00:00"
            },

            {
                "number": 2,
                "title": "Hangar 18",
                "timestamp": "04:31"
            },

            {
                "number": 3,
                "title": "Take No Prisoners",
                "timestamp": "09:52"
            },

            {
                "number": 4,
                "title": "Holy Wars",
                "timestamp": "1:03:54"
            }

        ]

    }


    builder = AsIsBuilder()


    result = builder.build(
        fake_generator_output
    )


    print()

    print(
        "MODE :",
        result.mode
    )

    print(
        "TRACKS :",
        result.count()
    )


    print()


    for track in result.tracks:

        print(

            f"{track.number:02d} - "
            f"{track.title:<25} "
            f"{track.start:>5}s -> "
            f"{track.end:>5}s "
            f"⭐{track.confidence} "
            f"[{track.source}]"

        )


if __name__ == "__main__":

    main()
