#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.1
Hybrid Engine
FULL CONCERT ROBUSTNESS TEST
"""

from core.generators.hybrid import HybridGenerator


print("=" * 60)
print("HYBRID ENGINE TEST - FULL CONCERT")
print("=" * 60)


# Setlist théorique
setlist = []

titles = [
    "Intro",
    "Song A",
    "Song B",
    "Song C",
    "Song D",
    "Song E",
    "Song F",
    "Song G",
    "Song H",
    "Song I",
    "Song J",
    "Song K",
    "Song L",
    "Song M",
    "Final Song"
]


times = [
    0,
    300,
    620,
    930,
    1250,
    1580,
    1900,
    2220,
    2550,
    2860,
    3180,
    3500,
    3820,
    4140,
    4460
]


for i, title in enumerate(titles):

    setlist.append(
        {
            "number": i + 1,
            "title": title,
            "time": times[i]
        }
    )


# Transitions détectées
transitions = [

    {"time": 304, "score": 92, "source": "silence"},

    # cluster
    {"time": 617, "score": 75, "source": "energy"},
    {"time": 622, "score": 94, "source": "silence"},
    {"time": 628, "score": 60, "source": "energy"},


    {"time": 928, "score": 91, "source": "silence"},


    # transition manquante Song D -> Song E


    {"time": 1585, "score": 89, "source": "silence"},


    # bruit parasite
    {"time": 1850, "score": 25, "source": "noise"},


    {"time": 1905, "score": 90, "source": "silence"},


    {"time": 2215, "score": 87, "source": "silence"},


    # cluster moyen
    {"time": 2540, "score": 70, "source": "energy"},
    {"time": 2554, "score": 95, "source": "silence"},


    {"time": 2865, "score": 93, "source": "silence"},


    {"time": 3188, "score": 88, "source": "silence"},


    {"time": 3498, "score": 91, "source": "silence"},


    {"time": 3825, "score": 90, "source": "silence"},


    {"time": 4145, "score": 92, "source": "silence"},


    {"time": 4465, "score": 96, "source": "silence"}

]


engine = HybridGenerator(
    window=60,
    cluster_time=30,
    match_threshold=70
)


result = engine.generate(
    setlist,
    transitions
)


for track in result:

    print(
        f'{track.number:02d} - '
        f'{track.title:<20} '
        f'{track.detected:>4}s '
        f'{track.status:<10} '
        f'{track.correction:+4d}s '
        f'⭐{track.score}'
    )


    if track.alternatives:

        print(
            "   Alternatives:"
        )

        for alt in track.alternatives:

            print(
                "    ",
                alt
            )


print("=" * 60)
print("STATS")
print("=" * 60)

print("MATCHED :", engine.stats.matched)
print("FALLBACK :", engine.stats.fallback)
print("CLUSTERS :", engine.stats.clusters)
print("AVG SCORE :", engine.stats.average_score)
print(
    "AVG CORRECTION :",
    engine.stats.average_correction
)
