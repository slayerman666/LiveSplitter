#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V5
Splitter Standard Setlist Contract Test

Vérifie que Splitter accepte :
AS_IS / AUTO / HYBRID

via NormalizedSetlist.
"""

import os
import shutil

from core.models.setlist import (
    Track,
    NormalizedSetlist
)

from core.splitter import Splitter


PROJECT = "tests/data/splitter_project"


def build_setlist(mode):

    return NormalizedSetlist(
        mode=mode,
        tracks=[
            Track(
                number=1,
                title="Tipping Point",
                start=0,
                end=270,
                confidence=100,
                source=mode
            ),

            Track(
                number=2,
                title="Hangar 18",
                start=270,
                end=598,
                confidence=92,
                source=mode
            ),

            Track(
                number=3,
                title="Take No Prisoners",
                start=598,
                end=803,
                confidence=95,
                source=mode
            ),

            Track(
                number=4,
                title="Holy Wars",
                start=3810,
                end=4200,
                confidence=96,
                source=mode
            )
        ]
    )


def run_test(mode):

    print()
    print("=" * 60)
    print(
        f" SPLITTER STANDARD SETLIST TEST - {mode.upper()}"
    )
    print("=" * 60)


    setlist = build_setlist(mode)


    print(
        "[SETLIST]",
        setlist.to_dict()
    )


    splitter = Splitter(PROJECT)

    splitter.run(
        setlist
    )


    print()

    tracks_dir = splitter.paths["tracks"]

    files = sorted(
        os.listdir(tracks_dir)
    )


    print(
        "[GENERATED]"
    )

    for f in files:
        print(
            f
        )


    assert len(files) == 4

    print()

    print(
        "[OK]",
        mode
    )


def main():

    for mode in [
        "as_is",
        "auto",
        "hybrid"
    ]:

        run_test(mode)


if __name__ == "__main__":
    main()
