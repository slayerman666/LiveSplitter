#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Test HYBRID Builder
"""


from core.builders.hybrid_builder import (
    HybridBuilder
)

from core.generators.hybrid import (
    TrackDecision
)


def main():

    print("=" * 60)
    print(" HYBRID BUILDER TEST ")
    print("=" * 60)


    decisions = [

        TrackDecision(

            number=1,
            title="Tipping Point",
            expected=0,
            detected=0,
            correction=0,
            status="START",
            score=100

        ),


        TrackDecision(

            number=2,
            title="Hangar 18",
            expected=266,
            detected=270,
            correction=4,
            status="MATCHED",
            score=92,

            alternatives=[

                {
                    "time":270,
                    "score":92,
                    "delta":4
                }

            ]

        ),


        TrackDecision(

            number=3,
            title="Take No Prisoners",
            expected=598,
            detected=598,
            correction=0,
            status="MATCHED",
            score=97

        ),


        TrackDecision(

            number=4,
            title="Holy Wars",
            expected=3812,
            detected=3810,
            correction=-2,
            status="MATCHED",
            score=95

        )

    ]


    builder = HybridBuilder()


    result = builder.build(
        decisions
    )


    print()

    print(
        "MODE :",
        result.mode
    )

    print(
        "TRACKS :",
        result.count()
    )


    print()


    for track in result.tracks:

        print(

            f"{track.number:02d} - "
            f"{track.title:<25} "
            f"{track.start:>5}s -> "
            f"{track.end:>5}s "
            f"⭐{track.confidence} "
            f"[{track.source}]"

        )


if __name__ == "__main__":

    main()
