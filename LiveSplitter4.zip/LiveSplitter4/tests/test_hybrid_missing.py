#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Hybrid Engine Test

Cas :
- une transition absente
- mélange MATCHED / FALLBACK
"""

from core.generators.hybrid import HybridGenerator


print("=" * 60)
print("HYBRID ENGINE TEST - MISSING TRANSITION")
print("=" * 60)


# =========================
# SETLIST THEORIQUE
# =========================

setlist = [

    {
        "number": 1,
        "title": "Intro",
        "time": 0
    },

    {
        "number": 2,
        "title": "Song A",
        "time": 300
    },

    {
        "number": 3,
        "title": "Song B",
        "time": 600
    },

    {
        "number": 4,
        "title": "Song C",
        "time": 900
    }

]


# =========================
# TRANSITIONS DETECTEES
# =========================

# Song B volontairement absente

transitions = [

    {
        "time": 302,
        "score": 90,
        "source": "silence"
    },

    {
        "time": 898,
        "score": 94,
        "source": "energy"
    }

]


# =========================
# EXECUTION
# =========================

engine = HybridGenerator(
    window=30
)


result = engine.generate(
    setlist,
    transitions
)


# =========================
# REPORT
# =========================

for track in result:

    print(
        f'{track.number:02d} - '
        f'{track.title:<20} '
        f'{track.detected:>4}s '
        f'{track.status:<10} '
        f'{track.correction:+d}s '
        f'⭐{track.score}'
    )


print()

print("=" * 60)
print("STATS")
print("=" * 60)

print(
    "MATCHED :",
    engine.stats.matched
)

print(
    "FALLBACK :",
    engine.stats.fallback
)

print(
    "AVG SCORE :",
    round(
        engine.stats.average_score,
        2
    )
)
