#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.1
Hybrid Engine Test
CLUSTER TRANSITIONS
"""

from core.generators.hybrid import HybridGenerator


print("=" * 60)
print("HYBRID ENGINE TEST - CLUSTER TRANSITIONS")
print("=" * 60)


setlist = [
    {
        "number": 1,
        "title": "Intro",
        "time": 0
    },
    {
        "number": 2,
        "title": "Hangar 18",
        "time": 300
    },
    {
        "number": 3,
        "title": "Holy Wars",
        "time": 900
    }
]


transitions = [

    # Faux groupe autour de Hangar 18
    {
        "time": 298,
        "score": 70,
        "source": "silence"
    },

    {
        "time": 301,
        "score": 88,
        "source": "silence"
    },

    {
        "time": 304,
        "score": 96,
        "source": "energy"
    },

    {
        "time": 310,
        "score": 55,
        "source": "silence"
    },


    # vraie transition Holy Wars
    {
        "time": 905,
        "score": 92,
        "source": "silence"
    }

]


engine = HybridGenerator(
    window=60,
    cluster_time=30,
    match_threshold=70
)


result = engine.generate(
    setlist,
    transitions
)


for track in result:

    print(
        f'{track.number:02d} - '
        f'{track.title:<20} '
        f'{track.detected:>4}s '
        f'{track.status:<10} '
        f'{track.correction:+d}s '
        f'⭐{track.score}'
    )


    if track.alternatives:

        print(
            "   Alternatives:"
        )

        for alt in track.alternatives:

            print(
                "   ",
                alt
            )


print("=" * 60)
print("STATS")
print("=" * 60)

print(
    "MATCHED :",
    engine.stats.matched
)

print(
    "FALLBACK :",
    engine.stats.fallback
)

print(
    "CLUSTERS :",
    engine.stats.clusters
)

print(
    "AVG SCORE :",
    engine.stats.average_score
)
