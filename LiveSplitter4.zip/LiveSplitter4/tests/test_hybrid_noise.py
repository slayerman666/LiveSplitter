#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Hybrid Engine Test

Cas :
- faux positifs
- bruit scène
- plusieurs candidats proches
"""

from core.generators.hybrid import HybridGenerator


print("=" * 60)
print("HYBRID ENGINE TEST - NOISE / FALSE POSITIVES")
print("=" * 60)


# =========================
# SETLIST THEORIQUE
# =========================

setlist = [

    {
        "number": 1,
        "title": "Intro",
        "time": 0
    },

    {
        "number": 2,
        "title": "Hangar 18",
        "time": 300
    },

    {
        "number": 3,
        "title": "Holy Wars",
        "time": 900
    }

]


# =========================
# TRANSITIONS DETECTEES
# =========================

# Plusieurs candidats autour du vrai marqueur

transitions = [

    {
        "time": 295,
        "score": 70,
        "source": "silence"
    },

    {
        "time": 302,
        "score": 90,
        "source": "energy"
    },

    {
        "time": 345,
        "score": 99,
        "source": "noise"
    },


    {
        "time": 897,
        "score": 85,
        "source": "silence"
    },

    {
        "time": 905,
        "score": 92,
        "source": "energy"
    }

]


# =========================
# EXECUTION
# =========================

engine = HybridGenerator(
    window=60
)


result = engine.generate(
    setlist,
    transitions
)


# =========================
# REPORT
# =========================

for track in result:

    print(
        f'{track.number:02d} - '
        f'{track.title:<20} '
        f'{track.detected:>4}s '
        f'{track.status:<10} '
        f'{track.correction:+d}s '
        f'⭐{track.score}'
    )


    if track.alternatives:

        print(
            "   Alternatives:"
        )

        for alt in track.alternatives:

            print(
                "   ",
                alt
            )


print()

print("=" * 60)
print("STATS")
print("=" * 60)

print(
    "MATCHED :",
    engine.stats.matched
)

print(
    "FALLBACK :",
    engine.stats.fallback
)

print(
    "AVG SCORE :",
    round(
        engine.stats.average_score,
        2
    )
)
