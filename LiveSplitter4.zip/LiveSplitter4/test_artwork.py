# -*- coding: utf-8 -*-

"""
Test Artwork Manager
"""

from core.project import Project
from core.artwork import ArtworkManager


project = Project(
    "projects/Test_Project"
)

project.load()


manager = ArtworkManager(
    project
)


artwork = manager.import_artwork(
    "projects/Test_Project/Metadata/Artwork/cover.jpg"
)


print("\nArtwork:")
print(
    artwork
)


print("\nProject metadata:")
print(
    project.data["metadata"]
)


print("\nProject recap:")
print(
    project.recap()
)
