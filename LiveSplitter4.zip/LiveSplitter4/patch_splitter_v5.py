from pathlib import Path

p = Path("core/splitter.py")

txt = p.read_text(encoding="utf-8")

# -------------------------------------------------
# __init__
# -------------------------------------------------

old = """        self.source_file = None
        self.tracks = []
        self.generated_tracks = []
"""

new = """        self.source_file = None
        self.tracks = []
        self.generated_tracks = []
        self.setlist = None
"""

txt = txt.replace(old, new)

# -------------------------------------------------
# cut_track()
# -------------------------------------------------

old = """        number = track.get(
            "number",
            0
        )

        title = clean_filename(
            track.get(
                "title",
                f"Track {number:02d}"
            )
        )

        start = track.get(
            "start",
            0
        )

        end = track.get(
            "end",
            0
        )
"""

new = """        if hasattr(track, "number"):

            number = track.number
            title = clean_filename(track.title)
            start = track.start
            end = track.end

        else:

            number = track.get(
                "number",
                0
            )

            title = clean_filename(
                track.get(
                    "title",
                    f"Track {number:02d}"
                )
            )

            start = track.get(
                "start",
                0
            )

            end = track.get(
                "end",
                0
            )
"""

txt = txt.replace(old, new)

# -------------------------------------------------
# run()
# -------------------------------------------------

txt = txt.replace(

    "    def run(self):",

    "    def run(self, setlist=None):"

)

old = """        self.load_mapping()

        os.makedirs(
"""

new = """        if setlist is None:

            self.load_mapping()

        else:

            self.tracks = setlist.tracks

        os.makedirs(
"""

txt = txt.replace(old, new)

p.write_text(txt, encoding="utf-8")

print("[OK] Splitter V5 patch applied")
