#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch Splitter V5
Utilisation NormalizedSetlist
"""

filename = "core/splitter.py"


with open(filename, "r", encoding="utf-8") as f:
    data = f.read()


old = """        self.load_mapping()
"""


new = """        if setlist is not None:
            print("[LOAD] NormalizedSetlist")
            self.tracks = [
                vars(track)
                for track in setlist.tracks
            ]
        else:
            self.load_mapping()
"""


if old not in data:
    print("[WARN] Bloc load_mapping introuvable")
else:
    data = data.replace(old, new, 1)

    with open(filename, "w", encoding="utf-8") as f:
        f.write(data)

    print("[OK] Splitter V5 setlist support applied")
