#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.1
Menu Projet
"""

import os

from core.project import detect


def show_header():

    print()
    print("==============================")
    print(" LiveSplitter V4.1")
    print(" Bootleg Builder")
    print("==============================")
    print()



def select_project():

    data = detect()

    audio_files = data.get(
        "audio",
        []
    )


    if not audio_files:

        print(
            "❌ Aucun fichier MP3 trouvé"
        )

        return None



    print()
    print("=== PROJETS DÉTECTÉS ===")
    print()


    for index, audio in enumerate(
        audio_files,
        start=1
    ):

        print(
            f"[{index}] {os.path.basename(audio)}"
        )


    print()

    choice = input("> ").strip()


    try:

        index = int(choice) - 1

        return audio_files[index]


    except:

        print(
            "Choix invalide"
        )

        return None



def main_menu():

    show_header()


    project = select_project()


    if not project:

        return "0", None



    print()

    print(
        "Projet sélectionné :"
    )

    print(
        os.path.basename(project)
    )


    print()

    print(
        "1 - Construire un bootleg complet"
    )

    print(
        "0 - Quitter"
    )

    print()


    choice = input("> ").strip()


    return choice, project
