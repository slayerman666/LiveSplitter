from pathlib import Path

p = Path("core/tags.py")

txt = p.read_text(encoding="utf-8")


old = '''        artwork = metadata.get(
            "artwork",
            ""
        )


        if artwork and os.path.exists(artwork):

            with open(
                artwork,
                "rb"
            ) as image:
'''


new = '''        artwork = metadata.get(
            "artwork",
            ""
        )


        # Résolution chemin relatif -> absolu

        if artwork and not os.path.isabs(artwork):

            artwork = os.path.join(
                os.getcwd(),
                artwork
            )


        if artwork and os.path.exists(artwork):

            with open(
                artwork,
                "rb"
            ) as image:
'''


if old not in txt:
    print("Bloc artwork introuvable.")
    raise SystemExit(1)


txt = txt.replace(old, new, 1)

p.write_text(
    txt,
    encoding="utf-8"
)

print("Patch artwork appliqué.")
