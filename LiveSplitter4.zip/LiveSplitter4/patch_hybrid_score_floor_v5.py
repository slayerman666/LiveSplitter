#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

FILE = Path("core/generators/hybrid.py")

lines = FILE.read_text(encoding="utf-8").splitlines()

backup = FILE.with_suffix(".score_floor_v5.bak")
backup.write_text("\n".join(lines) + "\n", encoding="utf-8")

patched = False

for i, line in enumerate(lines):

    if "distance_score = int(" in line:
        if i + 1 < len(lines) and "100 - ((delta - 60) * 0.12)" in lines[i + 1]:

            indent = line[:len(line) - len(line.lstrip())]

            lines[i] = indent + "distance_score = max("
            lines[i + 1] = indent + "    60,"
            lines.insert(i + 2, indent + "    int(")
            lines.insert(i + 3, indent + "        100 - ((delta - 60) * 0.12)")
            lines.insert(i + 4, indent + "    )")
            lines.insert(i + 5, indent + ")")

            patched = True
            break

if not patched:
    print("[ERROR] distance formula not found")
    raise SystemExit(1)

# remplacer le else minimum si présent
for i, line in enumerate(lines):
    if line.strip() == "distance_score = 20":
        indent = line[:len(line) - len(line.lstrip())]
        lines[i] = indent + "distance_score = 60"
        break

FILE.write_text("\n".join(lines) + "\n", encoding="utf-8")

print("[OK] score floor patched")
print("[OK] backup:", backup)
