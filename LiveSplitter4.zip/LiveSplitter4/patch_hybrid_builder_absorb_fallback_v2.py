#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil

target = Path("core/builders/hybrid_builder.py")

backup = Path("core/builders/hybrid_builder.absorb_fallback_v2.bak")

if not target.exists():
    print("[ERROR] file not found")
    exit(1)

shutil.copy2(target, backup)

text = target.read_text(encoding="utf-8")

anchor = "# Normalisation robuste des timelines"

if anchor not in text:
    print("[ERROR] anchor not found")
    exit(1)

insert = r'''
        # Absorption FALLBACK intermédiaires
        # Évite de créer des pistes artificielles
        # quand aucune transition audio n'existe.

        cleaned = []

        i = 0
        while i < len(result.tracks):

            track = result.tracks[i]

            if (
                track.metadata.get("status") == "FALLBACK"
                and i + 1 < len(result.tracks)
                and result.tracks[i + 1].metadata.get("status") == "MATCHED"
            ):
                i += 1
                continue

            cleaned.append(track)
            i += 1

        result.tracks = cleaned

'''

text = text.replace(
    anchor,
    insert + anchor,
    1
)

target.write_text(text, encoding="utf-8")

print("[OK] patch applied")
print("[OK] backup:", backup)
