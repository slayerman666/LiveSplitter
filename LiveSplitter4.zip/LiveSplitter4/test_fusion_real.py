# -*- coding: utf-8 -*-

"""
LiveSplitter V4

Test Fusion avec formats réels détecteurs
"""


from core.fusion import fuse_markers



markers = [

    {
        "time": 5500,
        "score": 100,
        "quality": 100,
        "type": "silence"
    },

    {
        "time": 5501,
        "score": 85,
        "quality": 80,
        "type": "energy"
    },

    {
        "time": 5500.5,
        "score": 90,
        "quality": 90,
        "type": "onset"
    }

]



print("Input markers:")

for marker in markers:

    print(marker)



clusters = fuse_markers(
    markers
)



print("\nFused clusters:")


for cluster in clusters:

    print(cluster)
