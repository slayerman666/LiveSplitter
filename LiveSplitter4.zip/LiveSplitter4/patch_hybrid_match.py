from pathlib import Path

path = Path("core/generators/hybrid.py")

text = path.read_text()

start = """            best = None
            best_score = -1

            while transition_index < len(transitions):"""

end = """            if best is not None:"""

if start not in text:
    print("[ERROR] start block not found")
    exit(1)

if end not in text:
    print("[ERROR] end block not found")
    exit(1)

old = text[text.index(start):text.index(end)]

new = """            best = None
            best_score = -1

            search_window = max(
                self.window,
                180
            )

            for candidate in transitions[transition_index:]:

                if candidate.time <= last_detected:
                    continue

                if candidate.time > expected + search_window:
                    break

                score = self.calculate_score(
                    candidate,
                    expected
                )

                if score > best_score:
                    best_score = score
                    best = candidate

"""

text = text.replace(old, new)

path.write_text(text)

print("[OK] hybrid.py patched")
