#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re

FILE = "core/setlist_generator.py"

with open(FILE, "r", encoding="utf-8") as f:
    text = f.read()


old = '''from core.mode import ModeManager
from core.generators.as_is import AsIsGenerator
from core.generators.auto import AutoGenerator
'''


new = '''from core.mode import ModeManager
from core.generators.as_is import AsIsGenerator
from core.generators.auto import AutoGenerator
from core.generators.hybrid import HybridGenerator
from core.builders.hybrid_builder import HybridBuilder
'''


text = text.replace(old, new)


old_hybrid = '''    def generate_hybrid(self):
        """
        Mode HYBRID

        Placeholder pour la fusion :
        setlist existante + analyse audio.
        """
        raise NotImplementedError(
            "HYBRID mode not implemented yet"
        )
'''


new_hybrid = '''    def generate_hybrid(self):
        """
        Mode HYBRID

        Réutilise le moteur HybridGenerator
        déjà validé par les tests.
        """

        print(
            "[SETLIST GENERATOR] HYBRID ENGINE"
        )

        setlist_file = (
            self.project.data
            .get("setlist", {})
            .get("file", "")
        )

        if not setlist_file:
            raise FileNotFoundError(
                "No theoretical setlist found"
            )


        import json

        with open(
            setlist_file,
            "r",
            encoding="utf-8"
        ) as f:
            theoretical = json.load(f)


        mapping_file = (
            self.project.paths["analysis_results"]
            + "/auto_mapping.json"
        )


        with open(
            mapping_file,
            "r",
            encoding="utf-8"
        ) as f:
            transitions_data = json.load(f)


        engine = HybridGenerator()


        decisions = engine.generate(
            theoretical.get(
                "tracks",
                []
            ),
            transitions_data.get(
                "tracks",
                []
            )
        )


        result = HybridBuilder().build(
            decisions
        )


        return result
'''


if old_hybrid not in text:
    print("[ERROR] Hybrid block not found")
    exit(1)


text = text.replace(
    old_hybrid,
    new_hybrid
)


with open(FILE, "w", encoding="utf-8") as f:
    f.write(text)


print("[OK] core/setlist_generator.py patched")
