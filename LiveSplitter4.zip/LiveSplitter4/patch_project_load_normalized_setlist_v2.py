#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re


FILE = "core/project.py"


def patch():

    with open(
        FILE,
        "r",
        encoding="utf-8"
    ) as f:
        content = f.read()


    if "NormalizedSetlist.from_dict" in content:
        print("[INFO] Patch déjà appliqué")
        return


    pattern = r"(    def load_normalized_setlist\(self\):).*?(?=\n    def recap\(self\):)"


    replacement = r'''    def load_normalized_setlist(self):

        filename = self.paths["normalized_setlist"]

        if not os.path.exists(filename):

            log(
                "NORMALIZED SETLIST NOT FOUND",
                self
            )

            return None


        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)


        from core.models.setlist import NormalizedSetlist


        normalized = NormalizedSetlist.from_dict(
            data
        )


        log(
            "NORMALIZED SETLIST LOADED",
            self
        )


        return normalized

'''


    new_content, count = re.subn(
        pattern,
        replacement,
        content,
        flags=re.S
    )


    if count == 0:
        raise Exception(
            "Fonction load_normalized_setlist introuvable"
        )


    with open(
        FILE,
        "w",
        encoding="utf-8"
    ) as f:
        f.write(new_content)


    print(
        "[OK] project.py patché"
    )


if __name__ == "__main__":
    patch()
