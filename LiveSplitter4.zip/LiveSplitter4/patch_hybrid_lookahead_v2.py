#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil

target = Path("core/generators/hybrid.py")

if not target.exists():
    print("[ERROR] hybrid.py not found")
    exit(1)

lines = target.read_text(encoding="utf-8").splitlines()

backup = Path("core/generators/hybrid.lookahead_v2.bak")
shutil.copy2(target, backup)

start = None
end = None

for i, line in enumerate(lines):
    if "best_score >= self.match_threshold" in line:
        start = i
        break

if start is None:
    print("[ERROR] match condition not found")
    exit(1)

for i in range(start, min(start + 8, len(lines))):
    if "detected = best.time" in lines[i]:
        end = i + 1
        break

if end is None:
    print("[ERROR] detected line not found")
    exit(1)

replacement = [
"            if (",
"                best is not None",
"                and best_score >= self.match_threshold",
"            ):",
"",
"                keep_current = True",
"",
"                if index + 1 < len(setlist):",
"                    next_expected = setlist[index + 1].get(",
"                        \"time\",",
"                        expected",
"                    )",
"",
"                    current_delta = abs(best.time - expected)",
"                    next_delta = abs(best.time - next_expected)",
"",
"                    if next_delta + 120 < current_delta:",
"                        keep_current = False",
"",
"                if keep_current:",
"                    detected = best.time",
]

new_lines = lines[:start-3] + replacement + lines[end:]

target.write_text(
    "\n".join(new_lines) + "\n",
    encoding="utf-8"
)

print("[OK] lookahead v2 applied")
print("[OK] backup:", backup)
