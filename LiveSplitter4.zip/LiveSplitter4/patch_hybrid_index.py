from pathlib import Path

path = Path("core/generators/hybrid.py")

text = path.read_text()

text = text.replace(
"""            best = None
            best_score = -1

            search_window = max(
                self.window,
                180
            )

            for candidate in transitions[transition_index:]:
""",
"""            best = None
            best_index = None
            best_score = -1

            search_window = max(
                self.window,
                180
            )

            for idx in range(
                transition_index,
                len(transitions)
            ):

                candidate = transitions[idx]
"""
)

text = text.replace(
"""                if score > best_score:
                    best_score = score
                    best = candidate
""",
"""                if score > best_score:
                    best_score = score
                    best = candidate
                    best_index = idx
"""
)

text = text.replace(
"""                detected = best.time
                transition_index += 1
""",
"""                detected = best.time
                transition_index = best_index + 1
"""
)

path.write_text(text)

print("[OK] hybrid.py index patch applied")
