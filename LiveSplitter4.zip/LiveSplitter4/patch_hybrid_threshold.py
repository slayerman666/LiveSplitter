#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch LiveSplitter V4
Ajout seuil de confiance Hybrid Engine
"""

from pathlib import Path
import shutil


FILE = Path("core/generators/hybrid.py")


if not FILE.exists():
    raise SystemExit(
        "Fichier hybrid.py introuvable"
    )


# Sauvegarde

backup = FILE.with_suffix(".py.bak")

shutil.copy(
    FILE,
    backup
)

print(
    f"[OK] Backup créé : {backup}"
)


content = FILE.read_text(
    encoding="utf-8"
)


# 1 - ajout paramètre init

old = """def __init__(
        self,
        window=30,
        cluster_time=180,
        ignore_before=60
    ):"""


new = """def __init__(
        self,
        window=30,
        cluster_time=180,
        ignore_before=60,
        match_threshold=70
    ):"""


if old in content:

    content = content.replace(
        old,
        new
    )

else:

    print(
        "[WARN] Signature init déjà modifiée"
    )


# 2 - ajout variable

old = """self.ignore_before = ignore_before"""


new = """self.ignore_before = ignore_before
        self.match_threshold = match_threshold"""


if old in content:

    content = content.replace(
        old,
        new
    )

else:

    print(
        "[WARN] Variable déjà présente"
    )


# 3 - remplacement condition match

old = """if best:"""


new = """if best and best[1].score >= self.match_threshold:"""


if old in content:

    content = content.replace(
        old,
        new,
        1
    )

else:

    print(
        "[WARN] Condition match non trouvée"
    )


FILE.write_text(
    content,
    encoding="utf-8"
)


print(
    "[OK] Patch Hybrid appliqué"
)
