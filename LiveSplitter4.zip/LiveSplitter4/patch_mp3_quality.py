#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil
import re


FILE = Path("core/youtube.py")


if not FILE.exists():
    print("[ERROR] core/youtube.py introuvable")
    exit(1)


backup = FILE.with_suffix(".py.bak2")

shutil.copy2(FILE, backup)

print("[OK] Backup :", backup)


text = FILE.read_text(
    encoding="utf-8"
)


pattern = r'("preferredquality"\s*:\s*)"[^"]*"'

replacement = r'\g<1>"320"'


new_text, count = re.subn(
    pattern,
    replacement,
    text
)


if count:

    FILE.write_text(
        new_text,
        encoding="utf-8"
    )

    print("[OK] preferredquality remplacé par 320")

else:

    print("[WARN] preferredquality introuvable")
