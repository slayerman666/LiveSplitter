# -*- coding: utf-8 -*-

"""
Test Setlist Manager
"""

from core.project import Project
from core.setlist import SetlistManager


project = Project(
    "projects/Test_Project"
)

project.load()


manager = SetlistManager(
    project
)


tracks = manager.import_setlist(
    "projects/Test_Project/Setlist/source_setlist.txt"
)


print("\nTracks:")

for track in tracks:

    print(track)


print("\nProject recap:")

print(
    project.recap()
)
