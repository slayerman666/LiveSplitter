#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

file = Path("core/menus/setlist_menu.py")

text = file.read_text(encoding="utf-8")

old = '''if choice == "0":
        print("[DEBUG] Leaving create_generate_menu")
                                                             pause()
                                                             return'''

new = '''if choice == "0":
        return'''

if old not in text:
    raise SystemExit("[ERROR] Bloc debug introuvable")

text = text.replace(old, new, 1)

file.write_text(text, encoding="utf-8")

print("[OK] Indentation restored")
