# -*- coding: utf-8 -*-

"""
Test Playlist Manager
"""

from core.project import Project
from core.playlist import PlaylistManager



project = Project(
    "projects/Test_Project"
)

project.load()


manager = PlaylistManager(
    project
)


playlist = manager.create_playlist()


print("\nPlaylist:")
print(
    playlist
)


print("\nProject output:")
print(
    project.data["output"]
)


print("\nProject recap:")
print(
    project.recap()
)
