#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil

target = Path("core/builders/hybrid_builder.py")

backup = Path("core/builders/hybrid_builder.absorb_fallback.bak")

shutil.copy2(target, backup)

text = target.read_text(encoding="utf-8")

old = """        # Normalisation robuste des timelines
        previous_end = 0
"""

new = """        # Absorption des FALLBACK intermédiaires
        # Un fallback sans transition réelle ne doit pas créer
        # une piste artificielle si une transition claire arrive après.

        cleaned = []

        i = 0
        while i < len(result.tracks):

            track = result.tracks[i]

            if (
                track.metadata.get("status") == "FALLBACK"
                and i + 1 < len(result.tracks)
            ):

                next_track = result.tracks[i + 1]

                if next_track.metadata.get("status") == "MATCHED":

                    i += 1
                    continue

            cleaned.append(track)
            i += 1

        result.tracks = cleaned


        # Normalisation robuste des timelines
        previous_end = 0
"""

if old not in text:
    print("[ERROR] block not found")
    exit(1)

text = text.replace(old, new, 1)

target.write_text(text, encoding="utf-8")

print("[OK] patch applied")
print("[OK] backup:", backup)
