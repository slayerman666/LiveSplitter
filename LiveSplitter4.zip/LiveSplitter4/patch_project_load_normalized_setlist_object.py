#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch LiveSplitter V4

Project.load_normalized_setlist()
Retourne maintenant un objet NormalizedSetlist
au lieu d'un dictionnaire brut.
"""

import os


FILE = "core/project.py"


OLD = """        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as f:
            data = json.load(f)

        log(
            "NORMALIZED SETLIST LOADED",
            self
        )

        return data
"""


NEW = """        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as f:
            data = json.load(f)

        from core.models.setlist import NormalizedSetlist

        normalized = NormalizedSetlist.from_dict(
            data
        )

        log(
            "NORMALIZED SETLIST LOADED",
            self
        )

        return normalized
"""


def patch():

    if not os.path.exists(FILE):
        raise FileNotFoundError(FILE)

    with open(
        FILE,
        "r",
        encoding="utf-8"
    ) as f:
        content = f.read()


    if "NormalizedSetlist.from_dict" in content:
        print(
            "[INFO] Patch déjà appliqué"
        )
        return


    if OLD not in content:
        raise Exception(
            "Bloc load_normalized_setlist introuvable - aucun changement effectué"
        )


    content = content.replace(
        OLD,
        NEW,
        1
    )


    with open(
        FILE,
        "w",
        encoding="utf-8"
    ) as f:
        f.write(content)


    print(
        "[OK] project.py patché"
    )


if __name__ == "__main__":
    patch()
