#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import re


FILE = Path("core/setlist_generator.py")


NEW_BLOCK = '''        raw = self.load_as_is()


        mapping_file = os.path.join(
            self.project.paths["analysis_results"],
            "auto_mapping.json"
        )

        mapping = self.load_json_file(
            mapping_file
        )


        detected_tracks = mapping.get(
            "tracks",
            []
        )


        hybrid_tracks = []


        for index, track in enumerate(
            raw.get(
                "tracks",
                []
            )
        ):

            detected_time = 0


            if index < len(detected_tracks):

                detected_time = detected_tracks[index].get(
                    "start",
                    0
                )


            hybrid_tracks.append(
                {
                    "number": track.get(
                        "number",
                        index + 1
                    ),

                    "title": track.get(
                        "title",
                        ""
                    ),

                    "time": detected_time
                }
            )


'''


def main():

    if not FILE.exists():
        print("[ERROR] File not found")
        return


    content = FILE.read_text(
        encoding="utf-8"
    )


    pattern = r"        raw = self\.load_as_is\(\).*?        mapping_file = os\.path\.join\(\n            self\.project\.paths\[\"analysis_results\"\],\n            \"auto_mapping\.json\"\n        \).*?        hybrid_tracks\.append\(.*?\n            \)\n"


    result, count = re.subn(
        pattern,
        NEW_BLOCK,
        content,
        flags=re.S
    )


    if count != 1:
        print("[ERROR] Hybrid block not found")
        print("Matches:", count)
        return


    backup = FILE.with_suffix(
        ".py.bak3"
    )


    backup.write_text(
        content,
        encoding="utf-8"
    )


    FILE.write_text(
        result,
        encoding="utf-8"
    )


    print("[OK] Hybrid alignment patched")
    print("[OK] Backup:", backup)


if __name__ == "__main__":
    main()
