from pathlib import Path

path = Path("core/generators/hybrid.py")

text = path.read_text()

start = text.index("    def match(")
end = text.index("    # ==================================================\n    # STATS", start)

new_block = '''    def match(
            self,
            setlist,
            transitions
    ):

        result = []

        if not setlist:
            return result

        transition_index = 0
        last_detected = 0

        for index, track in enumerate(setlist):

            number = track.get(
                "number",
                index + 1
            )

            title = track.get(
                "title",
                f"Track {index+1}"
            )

            expected = track.get(
                "time",
                last_detected
            )

            if index == 0:
                result.append(
                    TrackDecision(
                        number=number,
                        title=title,
                        expected=0,
                        detected=0,
                        correction=0,
                        status="START",
                        score=100
                    )
                )
                continue

            best = None
            best_score = -1

            while transition_index < len(transitions):

                candidate = transitions[transition_index]

                if candidate.time <= last_detected:
                    transition_index += 1
                    continue

                score = self.calculate_score(
                    candidate,
                    expected
                )

                if score > best_score:
                    best_score = score
                    best = candidate

                break

            if best is not None:

                detected = best.time
                transition_index += 1

                result.append(
                    TrackDecision(
                        number=number,
                        title=title,
                        expected=expected,
                        detected=detected,
                        correction=detected - expected,
                        status="MATCHED",
                        score=best_score
                    )
                )

                last_detected = detected

            else:

                result.append(
                    TrackDecision(
                        number=number,
                        title=title,
                        expected=expected,
                        detected=max(expected, last_detected),
                        correction=0,
                        status="FALLBACK",
                        score=0
                    )
                )

        return result


'''

text = text[:start] + new_block + text[end:]

path.write_text(text)

print("[OK] hybrid.match patched")
