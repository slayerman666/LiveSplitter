#!/usr/bin/env python3
from pathlib import Path
import shutil

FILE = Path("core/youtube.py")

if not FILE.exists():
    print("[ERROR] core/youtube.py introuvable")
    exit(1)

backup = FILE.with_suffix(".py.bak")
shutil.copy2(FILE, backup)

text = FILE.read_text(encoding="utf-8")


# Correction chemin cookie
text = text.replace(
    '"/storage/emulated/0/LiveSplitter4/cookies.txt"',
    '"/storage/emulated/0/LiveSplitter4/cookies_netscape.txt"'
)


# Remplacement get_info
old = '''{
                "quiet": True,
                "js_runtimes": {
                    "deno": {}
                }
            }'''

new = '''{
                "quiet": True,
                "cookiefile":
                    "/storage/emulated/0/LiveSplitter4/cookies_netscape.txt",
                "js_runtimes": {
                    "deno": {}
                },
                "extractor_args": {
                    "youtube": {
                        "player_client": [
                            "web"
                        ]
                    }
                }
            }'''


if old in text:
    text = text.replace(old, new, 1)
    print("[OK] get_info patché")
else:
    print("[WARN] Bloc get_info non trouvé")


FILE.write_text(text, encoding="utf-8")

print("[OK] Patch terminé")
print("[OK] Backup :", backup)
