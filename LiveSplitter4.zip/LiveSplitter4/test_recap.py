# -*- coding: utf-8 -*-

"""
Test Recap Manager
"""


from core.project import Project
from core.recap import RecapManager



project = Project(
    "projects/Test_Project"
)


project.load()



manager = RecapManager(
    project
)



print(
    manager.get_recap()
)
