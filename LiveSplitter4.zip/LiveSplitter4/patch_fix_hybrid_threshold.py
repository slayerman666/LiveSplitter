#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Fix HybridGenerator match_threshold
LiveSplitter V4
"""

from pathlib import Path
import shutil


FILE = Path("core/generators/hybrid.py")


if not FILE.exists():
    raise SystemExit("hybrid.py introuvable")


backup = FILE.with_suffix(".py.fixbak")

shutil.copy(FILE, backup)

print(f"[OK] Backup : {backup}")


content = FILE.read_text(
    encoding="utf-8"
)


# Ajouter le paramètre si absent

if "match_threshold=70" not in content:

    old = """        ignore_before=60
    ):"""

    new = """        ignore_before=60,
        match_threshold=70
    ):"""

    if old in content:
        content = content.replace(
            old,
            new,
            1
        )
        print("[OK] Paramètre ajouté")
    else:
        print("[WARN] Signature non trouvée")


# Vérifier la variable

if "self.match_threshold = match_threshold" not in content:

    old = """        self.ignore_before = ignore_before"""

    new = """        self.ignore_before = ignore_before
        self.match_threshold = match_threshold"""

    if old in content:
        content = content.replace(
            old,
            new,
            1
        )
        print("[OK] Variable ajoutée")

else:

    print("[OK] Variable déjà présente")


FILE.write_text(
    content,
    encoding="utf-8"
)

print("[OK] Fix terminé")
