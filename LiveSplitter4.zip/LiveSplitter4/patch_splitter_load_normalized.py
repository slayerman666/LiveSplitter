#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch LiveSplitter V4.7

Splitter:
- Charge normalized_setlist.json depuis le projet
- Garde compatibilité auto_mapping.json
- Ajoute log de chargement
"""

import os
import re


FILE = "core/splitter.py"


def patch():

    if not os.path.exists(FILE):
        raise FileNotFoundError(FILE)


    with open(FILE, "r", encoding="utf-8") as f:
        content = f.read()


    old = r'''    def load_mapping\(self\):.*?        self\.tracks = data\.get\(
            "tracks",
            \[\]
        \)
'''


    new = '''    def load_mapping(self):

        normalized_file = os.path.join(
            self.project_dir,
            "Analysis",
            "Results",
            "normalized_setlist.json"
        )

        if os.path.exists(normalized_file):

            log(
                "NORMALIZED SETLIST LOADED FOR SPLIT",
                self
            )

            data = load_json(
                normalized_file
            )

            self.tracks = data.get(
                "tracks",
                []
            )

            return


        print(
            f"[LOAD] {self.paths['mapping']}"
        )

        data = load_json(
            self.paths["mapping"]
        )

        self.tracks = data.get(
            "tracks",
            []
        )
'''


    new_content, count = re.subn(
        old,
        new,
        content,
        flags=re.S
    )


    if count != 1:
        raise Exception(
            "Bloc load_mapping introuvable - aucun changement effectué"
        )


    with open(FILE, "w", encoding="utf-8") as f:
        f.write(new_content)


    print(
        "PATCH OK : splitter.py modifié"
    )


if __name__ == "__main__":
    patch()
