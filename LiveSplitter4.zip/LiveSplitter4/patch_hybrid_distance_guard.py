#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch HybridGenerator:
Ajoute une protection contre les matchs trop éloignés.
"""

from pathlib import Path

file = Path("core/generators/hybrid.py")

text = file.read_text(encoding="utf-8")

old = """        if (
                best is not None
                and best_score >= self.match_threshold
        ):
            keep_current = True
"""

new = """        if (
                best is not None
                and best_score >= self.match_threshold
        ):

            # Protection contre les faux matchs très éloignés
            max_drift = 900

            if abs(best.time - expected) > max_drift:
                best = None
                best_score = -1

            if best is not None:
                keep_current = True
"""

if old not in text:
    print("[ERROR] target block not found")
    exit(1)

text = text.replace(old, new, 1)

backup = file.with_suffix(".py.distance_guard.bak")
backup.write_text(file.read_text(encoding="utf-8"), encoding="utf-8")

file.write_text(text, encoding="utf-8")

print("[OK] hybrid.py patched")
print("[OK] backup:", backup)
