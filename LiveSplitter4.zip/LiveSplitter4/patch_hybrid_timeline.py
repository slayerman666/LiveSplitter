#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

target = Path("core/builders/hybrid_builder.py")

text = target.read_text(encoding="utf-8")

start = text.find("        # Calcul des fins sécurisé")

end = text.find("        return result", start)

if start == -1:
    print("[ERROR] Start marker not found")
    exit(1)

if end == -1:
    print("[ERROR] End marker not found")
    exit(1)

new_block = '''        # Normalisation robuste des timelines

        previous_end = 0

        for track in result.tracks:

            if track.start < previous_end:
                track.start = previous_end

            previous_end = track.start


        # Calcul des fins

        for i in range(len(result.tracks) - 1):

            current = result.tracks[i]
            nxt = result.tracks[i + 1]

            current.end = nxt.start

            if current.end <= current.start:
                current.end = current.start + 1


        # Dernière piste

        if result.tracks:

            last = result.tracks[-1]

            if last.end <= last.start:
                last.end = last.start + 1

'''

text = text[:start] + new_block + text[end:]

target.write_text(text, encoding="utf-8")

print("[OK] Hybrid timeline normalization patched")
