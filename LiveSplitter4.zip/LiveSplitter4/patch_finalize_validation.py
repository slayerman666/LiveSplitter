from pathlib import Path

file = Path("core/setlist_generator.py")

text = file.read_text(encoding="utf-8")

start = text.find("        if normalized.tracks and duration:")
end = text.find("        self.project.save_normalized_setlist")

if start == -1:
    print("[ERROR] Start marker not found")
    exit(1)

if end == -1:
    print("[ERROR] End marker not found")
    exit(1)


new_block = '''        # Correction commune des incohérences temporelles
        # Ne modifie jamais les starts détectés

        for i in range(len(normalized.tracks) - 1):

            current = normalized.tracks[i]
            nxt = normalized.tracks[i + 1]

            if current.end > nxt.start:
                current.end = nxt.start

            if current.end <= current.start:
                current.end = current.start + 1


        # Dernière piste = durée réelle du fichier source

        if normalized.tracks and duration:

            last = normalized.tracks[-1]

            if duration > last.start:
                last.end = int(duration)

            elif last.end <= last.start:
                last.end = last.start + 1


'''

text = text[:start] + new_block + text[end:]

file.write_text(text, encoding="utf-8")

print("[OK] finalize_setlist patched")
