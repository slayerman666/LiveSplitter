#!/usr/bin/env python3
# -*- coding: utf-8 -*-

filename = "core/menus/splitter_menu.py"

with open(filename, "r", encoding="utf-8") as f:
    data = f.read()


start = data.find("elif choice == \"2\":")

end = data.find("elif choice == \"3\":", start)


if start == -1 or end == -1:
    print("[WARN] Zone menu split introuvable")
    exit(1)


new_block = '''elif choice == "2":
        try:

            from core.builders.as_is_builder import AsIsBuilder
            from core.builders.auto_builder import AutoBuilder
            from core.builders.hybrid_builder import HybridBuilder

            print()
            print("=== SETLIST MODE ===")
            print("1) AS_IS")
            print("2) AUTO")
            print("3) HYBRID")

            mode = input("Choice : ").strip()

            if mode == "1":
                builder = AsIsBuilder(project)

            elif mode == "2":
                builder = AutoBuilder(project)

            elif mode == "3":
                builder = HybridBuilder(project)

            else:
                print("[WARN] Invalid mode")
                input("ENTER...")
                continue

            setlist = builder.generate()

            print()
            print("[SETLIST READY]")
            print("Mode :", setlist.mode)
            print("Tracks :", setlist.count())

            splitter = Splitter(
                project.path
            )

            splitter.run(
                setlist
            )

        except Exception as error:
            print()
            print(
                f"[ERROR] {error}"
            )

        input("ENTER...")

    '''


data = data[:start] + new_block + data[end:]


with open(filename, "w", encoding="utf-8") as f:
    f.write(data)


print("[OK] splitter_menu.py V5 patched")
