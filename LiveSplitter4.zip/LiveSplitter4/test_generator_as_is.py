# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Test AS IS Generator
"""


from core.project import Project
from core.generators.as_is import AsIsGenerator



project = Project(
    "projects/Test_Project"
)


project.load()



generator = AsIsGenerator(
    project
)



result = generator.generate()



print(
    "Generated setlist:"
)


print(
    result
)
