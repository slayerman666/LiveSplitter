#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import shutil
from pathlib import Path


FILE = Path("core/youtube.py")

COOKIE_LINE = '''            "cookiefile":
                "/storage/emulated/0/LiveSplitter4/cookies_netscape.txt",

'''


if not FILE.exists():
    print("[ERROR] core/youtube.py introuvable")
    exit(1)


text = FILE.read_text(
    encoding="utf-8"
)


backup = FILE.with_suffix(".py.bak")

shutil.copy2(
    FILE,
    backup
)

print("[OK] Backup créé :", backup)


changed = False


# Ajout cookiefile si absent
if '"cookiefile"' not in text:

    marker = '''            "outtmpl":
                output,
'''

    if marker in text:

        text = text.replace(
            marker,
            marker + "\n\n" + COOKIE_LINE,
            1
        )

        changed = True

    else:
        print("[WARN] Bloc outtmpl introuvable")


# Passage android -> web
old = '''"player_client":
                    [
                        "android"
                    ]'''

new = '''"player_client":
                    [
                        "web"
                    ]'''


if old in text:

    text = text.replace(
        old,
        new,
        1
    )

    changed = True

else:
    print("[WARN] Bloc android introuvable")


if changed:

    FILE.write_text(
        text,
        encoding="utf-8"
    )

    print("[OK] Patch appliqué")

else:

    print("[WARN] Aucun changement effectué")
