# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Test Detector Manager
"""


from core.project import Project
from core.detector_manager import DetectorManager



project = Project(
    "projects/Test_Project"
)


project.load()



manager = DetectorManager(
    project
)



print(
    "Available detectors:"
)


print(
    manager.available()
)
