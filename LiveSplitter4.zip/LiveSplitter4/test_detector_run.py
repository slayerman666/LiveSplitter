# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Test Detector Manager Run
"""


from core.project import Project
from core.detector_manager import DetectorManager



project = Project(
    "projects/Test_Project"
)


project.load()



manager = DetectorManager(
    project
)



audio_file = (
    project.data["source"]["file"]
)



print("Running silence detector...")


result = manager.run(
    "silence",
    audio_file
)



print(
    "Result:"
)


print(result)
