from core.project import Project
from core.splitter import Splitter


project = Project(
    "projects/Test_Project"
)

project.load()


splitter = Splitter(
    project
)


tracks = splitter.split_as_is()


print("\nGenerated tracks:")

for track in tracks:
    print(track)


print("\nProject recap:")

print(
    project.recap()
)
