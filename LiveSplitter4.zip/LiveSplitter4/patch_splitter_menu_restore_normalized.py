#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch LiveSplitter V5

Restaure automatiquement la NormalizedSetlist
depuis le projet avant lancement du Splitter.
"""

import re


FILE = "core/menus/splitter_menu.py"


def patch():

    with open(
        FILE,
        "r",
        encoding="utf-8"
    ) as f:
        content = f.read()


    # Ajout imports
    if "from core.utils import log" not in content:

        content = content.replace(
            "from core.playlist import Playlist",
            "from core.playlist import Playlist\n"
            "from core.utils import log\n"
            "from core.models.setlist import NormalizedSetlist"
        )

    elif "from core.models.setlist import NormalizedSetlist" not in content:

        content = content.replace(
            "from core.utils import log",
            "from core.utils import log\n"
            "from core.models.setlist import NormalizedSetlist"
        )


    old = r'''if not hasattr\(
\s*project,
\s*"normalized_setlist"
\s*\):
\s*raise ValueError\(
\s*"No normalized setlist available\. "
\s*"Generate setlist first\."
\s*\)

\s*splitter = Splitter\(
\s*project\.path
\s*\)

\s*splitter\.run\(
\s*project\.normalized_setlist
\s*\)'''


    new = '''if not hasattr(
                    project,
                    "normalized_setlist"
                ):

                    normalized_data = (
                        project.load_normalized_setlist()
                    )

                    if normalized_data is None:
                        raise ValueError(
                            "No normalized setlist available. "
                            "Generate setlist first."
                        )

                    project.normalized_setlist = (
                        NormalizedSetlist.from_dict(
                            normalized_data
                        )
                    )

                    log(
                        "NORMALIZED SETLIST RESTORED FROM PROJECT",
                        project
                    )


                splitter = Splitter(
                    project.path
                )


                splitter.run(
                    project.normalized_setlist
                )'''


    content, count = re.subn(
        old,
        new,
        content,
        flags=re.MULTILINE
    )


    if count == 0:
        raise Exception(
            "Bloc Splitter introuvable - aucun changement effectué"
        )


    with open(
        FILE,
        "w",
        encoding="utf-8"
    ) as f:
        f.write(content)


    print(
        "[OK] splitter_menu.py patched"
    )


if __name__ == "__main__":
    patch()
