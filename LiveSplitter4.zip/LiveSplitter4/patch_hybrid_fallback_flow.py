#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil
import re

target = Path("core/generators/hybrid.py")

if not target.exists():
    print("[ERROR] hybrid.py not found")
    exit(1)

text = target.read_text(encoding="utf-8")

backup = target.with_name("hybrid.py.fallback_flow.bak")
shutil.copy2(target, backup)

old = """            if (
                best is not None
                and best_score >= self.match_threshold
            ):
                detected = best.time
"""

new = """            if best is not None:
                # Une transition forte ne doit pas être perdue
                # au profit d'une piste théorique trop courte.
                strong_transition = (
                    best.score >= 90
                    and best.time > last_detected
                )

                if best_score >= self.match_threshold or strong_transition:
                    detected = best.time
"""

if old not in text:
    print("[ERROR] match block not found")
    exit(1)

text = text.replace(old, new)

target.write_text(text, encoding="utf-8")

print("[OK] hybrid.py patched")
print("[OK] backup:", backup)
