#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.1
Bootleg Builder

Pipeline complet :
Analyzer
Transition
Optimizer
Splitter
Tagger
Playlist

Compatible Termux / Android
"""

import os
import sys
import glob
import subprocess


from core.menu import main_menu


VERSION = "4.1"


BASE_DIR = os.path.dirname(
    os.path.abspath(__file__)
)


INPUT_DIR = os.path.join(
    BASE_DIR,
    "Input"
)


SETLIST_DIR = os.path.join(
    BASE_DIR,
    "Setlist"
)


ANALYSIS_DIR = os.path.join(
    BASE_DIR,
    "analysis"
)


OUTPUT_DIR = os.path.join(
    BASE_DIR,
    "Output"
)



def run(command):

    print()
    print("[EXEC]")
    print(" ".join(command))
    print()

    env = os.environ.copy()

    env["PYTHONPATH"] = BASE_DIR


    result = subprocess.run(
        command,
        cwd=BASE_DIR,
        env=env
    )


    if result.returncode != 0:

        raise RuntimeError(
            "Erreur pendant : "
            + " ".join(command)
        )



def find_file(folder, extension):

    files = glob.glob(
        os.path.join(
            folder,
            extension
        )
    )

    if files:
        return files[0]

    return None



def find_matching_setlist(audio_file):

    """
    Recherche la setlist correspondant
    au nom du concert.
    """

    if not audio_file:
        return None


    audio_name = os.path.basename(
        audio_file
    )


    audio_name = os.path.splitext(
        audio_name
    )[0].lower()


    words = [
        word
        for word in audio_name.replace("-", " ").split()
        if len(word) > 3
    ]


    candidates = glob.glob(
        os.path.join(
            SETLIST_DIR,
            "*.txt"
        )
    )


    if not candidates:
        return None


    best = None
    best_score = 0


    for file in candidates:

        name = os.path.basename(
            file
        ).lower()


        score = 0


        for word in words:

            if word in name:
                score += 1


        if score > best_score:

            best_score = score
            best = file


    return best



def build_bootleg(audio_file):

    print()
    print(
        "=== LiveSplitter V4.1 Bootleg Builder ==="
    )
    print()


    audio = audio_file


    setlist = find_matching_setlist(
        audio
    )

    if not audio:

        print(
            "❌ Aucun MP3 sélectionné"
        )

        return


    if not setlist:

        print(
            "❌ Aucune setlist correspondante trouvée"
        )

        return


    print(
        "Audio :",
        os.path.basename(audio)
    )


    print(
        "Setlist :",
        os.path.basename(setlist)
    )


    # =====================
    # ANALYSE
    # =====================

    print()
    print("[1/5] Analyse audio")


    run(
        [
            sys.executable,
            "core/analyzer.py",
            audio
        ]
    )


    analysis_files = glob.glob(
        os.path.join(
            ANALYSIS_DIR,
            "*_analysis.json"
        )
    )


    if not analysis_files:

        print(
            "❌ Rapport analyse absent"
        )

        return


    # prend le rapport correspondant au fichier audio
    analysis = max(
        analysis_files,
        key=os.path.getmtime
    )



    # =====================
    # OPTIMIZER
    # =====================

    print()
    print("[2/5] Optimisation setlist")


    run(
        [
            sys.executable,
            "core/run_optimizer.py",
            analysis,
            setlist
        ]
    )


    optimized_files = glob.glob(
        os.path.join(
            ANALYSIS_DIR,
            "*_optimized.json"
        )
    )


    if not optimized_files:

        print(
            "❌ Rapport optimisé absent"
        )

        return


    optimized = max(
        optimized_files,
        key=os.path.getmtime
    )

    # =====================
    # SPLITTER
    # =====================

    print()
    print("[3/5] Découpage audio")


    run(
        [
            sys.executable,
            "core/splitter.py",
            audio,
            optimized
        ]
    )



    # =====================
    # TAGGER
    # =====================

    print()
    print("[4/5] Tags ID3")


    output_folders = glob.glob(
        os.path.join(
            OUTPUT_DIR,
            "*"
        )
    )


    if not output_folders:

        print(
            "❌ Dossier Output introuvable"
        )

        return


    output_folder = max(
        output_folders,
        key=os.path.getmtime
    )


    run(
        [
            sys.executable,
            "core/tagger.py",
            output_folder,
            optimized
        ]
    )



    # =====================
    # PLAYLIST
    # =====================

    print()
    print("[5/5] Playlist")


    run(
        [
            sys.executable,
            "core/playlist.py",
            output_folder
        ]
    )



    print()
    print(
        "=============================="
    )
    print(
        " BOOTLEG TERMINÉ ✅"
    )
    print(
        "=============================="
    )



def menu():

    while True:

        choice, project = main_menu()


        if choice == "1":

            build_bootleg(
                project
            )


        elif choice == "0":

            print(
                "Au revoir"
            )

            break


        else:

            print(
                "Choix invalide"
            )



if __name__ == "__main__":

    menu()
