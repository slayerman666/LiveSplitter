# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Test Tag Manager
"""

from core.project import Project
from core.tags import TagManager


project = Project(
    "projects/Test_Project"
)

project.load()


manager = TagManager(
    project
)


manager.tag_tracks()


print("\nTags applied")


print("\nProject recap:")


print(
    project.recap()
)
