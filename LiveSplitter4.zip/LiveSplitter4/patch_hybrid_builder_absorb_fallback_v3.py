#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil

target = Path("core/builders/hybrid_builder.py")
backup = Path("core/builders/hybrid_builder.absorb_fallback_v3.bak")

shutil.copy2(target, backup)

text = target.read_text(encoding="utf-8")

anchor = "# Normalisation robuste des timelines"

if anchor not in text:
    print("[ERROR] anchor not found")
    exit(1)

patch = r'''
        # Absorption des groupes FALLBACK intermédiaires
        cleaned = []

        i = 0

        while i < len(result.tracks):

            track = result.tracks[i]

            if track.metadata.get("status") == "FALLBACK":

                j = i

                while (
                    j < len(result.tracks)
                    and result.tracks[j].metadata.get("status") == "FALLBACK"
                ):
                    j += 1

                # Si une vraie transition arrive après le groupe,
                # on absorbe les fallback.
                if (
                    j < len(result.tracks)
                    and result.tracks[j].metadata.get("status") == "MATCHED"
                ):
                    i = j
                    continue

            cleaned.append(track)
            i += 1

        result.tracks = cleaned

'''

text = text.replace(
    anchor,
    patch + anchor,
    1
)

target.write_text(text, encoding="utf-8")

print("[OK] patch v3 applied")
print("[OK] backup:", backup)
