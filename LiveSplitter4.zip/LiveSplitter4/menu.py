#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V1.4

Menu principal avec gestion du projet actif.

Règle :
- Un projet doit être chargé avant accès aux modules métier.
- La sauvegarde est automatique.
"""

import os

from core.project import Project
from core.menus.metadata_menu import metadata_menu as metadata_v4
from core.menus.splitter_menu import splitter_menu as splitter_v4
from core.menus.setlist_menu import setlist_menu
from core.menus.log_menu import log_menu
from core.menus.settings_menu import settings_menu as settings_v4


VERSION = "1.4"

PROJECT_ROOT = "projects"

CURRENT_PROJECT = None



def header(title="LiveSplitter"):

    print()
    print("=" * 50)
    print(f"=== {title} ===")
    print("=" * 50)
    print()



def pause():

    input("\nPress ENTER to continue...")



def choose(title, options):

    while True:

        header(title)

        for key, value in options.items():

            print(f"{key}) {value}")

        print()

        choice = input("Choice : ").strip()

        if choice in options:

            return choice

        print("[ERROR] Invalid choice")



def require_project():

    if CURRENT_PROJECT is None:

        print()
        print("[WARN] No active project")
        print("Open or create a project first.")

        pause()

        return False

    return True



def get_project_path(name):

    return os.path.join(
        PROJECT_ROOT,
        name
    )



# ==================================================
# PROJECT
# ==================================================


def new_project():

    global CURRENT_PROJECT


    name = input(
        "Project name : "
    ).strip()


    if not name:

        print(
            "[ERROR] Empty project name"
        )

        pause()

        return



    path = get_project_path(
        name
    )


    if os.path.exists(path):

        print(
            "[ERROR] Project already exists"
        )

        pause()

        return



    CURRENT_PROJECT = Project(
        path
    )


    CURRENT_PROJECT.create(
        name
    )


    print()
    print(
        f"[OK] Project created : {name}"
    )

    pause()



def list_projects():

    if not os.path.exists(
        PROJECT_ROOT
    ):

        return []


    projects = []


    for name in os.listdir(
        PROJECT_ROOT
    ):

        path = os.path.join(
            PROJECT_ROOT,
            name
        )


        if (
            os.path.isdir(path)
            and os.path.exists(
                os.path.join(
                    path,
                    "project.json"
                )
            )
        ):

            projects.append(name)


    return sorted(projects)



def open_existing_project():

    global CURRENT_PROJECT


    projects = list_projects()


    if not projects:

        print(
            "[WARN] No existing project"
        )

        pause()

        return



    options = {}

    for index, name in enumerate(
        projects,
        start=1
    ):

        options[str(index)] = name


    options["0"] = "Back"



    choice = choose(
        "OPEN PROJECT",
        options
    )


    if choice == "0":

        return



    name = options[choice]


    CURRENT_PROJECT = Project(
        get_project_path(name)
    )


    CURRENT_PROJECT.load()


    print()
    print(
        f"[OK] Project loaded : {name}"
    )

    pause()



def recap_project():

    if not require_project():

        return


    header(
        "PROJECT RECAP"
    )


    recap = CURRENT_PROJECT.recap()


    for key, value in recap.items():

        print(
            f"{key}: {value}"
        )


    pause()



def project_information():

    if not require_project():

        return


    header(
        "PROJECT INFORMATION"
    )


    print(
        f"Name    : {CURRENT_PROJECT.data.get('name','')}"
    )

    print(
        f"Path    : {CURRENT_PROJECT.path}"
    )

    print(
        f"Created : {CURRENT_PROJECT.data.get('created','')}"
    )

    print(
        f"Updated : {CURRENT_PROJECT.data.get('updated','')}"
    )


    pause()



def project_menu():

    while True:

        choice = choose(
            "PROJECT",
            {
                "1": "New Project",
                "2": "Open Existing Project",
                "3": "Recap So Far",
                "4": "Project Information",
                "0": "Back"
            }
        )


        if choice == "0":

            return


        elif choice == "1":

            new_project()


        elif choice == "2":

            open_existing_project()


        elif choice == "3":

            recap_project()


        elif choice == "4":

            project_information()



# ==================================================
# MODULES
# ==================================================


def source_manager_menu():

    if not require_project():

        return


    print(
        "[INFO] Source Manager"
    )

    pause()



def metadata_manager_menu():

    if not require_project():

        return

    metadata_v4(
        CURRENT_PROJECT
    )


def setlist_manager_menu():

    if not require_project():

        return


    setlist_menu(
        CURRENT_PROJECT
    )


def splitter_menu():

    if not require_project():

        return

    splitter_v4(
        CURRENT_PROJECT
    )


def output_manager_menu():

    if not require_project():

        return

    from core.menus.output_menu import output_menu

    output_menu(
        CURRENT_PROJECT
    )


def log_manager_menu():

    if not require_project():

        return

    log_menu(
        CURRENT_PROJECT
    )


def settings_menu():

    if not require_project():

        return

    settings_v4(
        CURRENT_PROJECT
    )


# ==================================================
# MAIN MENU
# ==================================================


def main_menu():

    os.makedirs(
        PROJECT_ROOT,
        exist_ok=True
    )


    while True:

        choice = choose(
            f"LiveSplitter V{VERSION}",
            {
                "1": "PROJECT",
                "2": "SOURCE MANAGER",
                "3": "METADATA MANAGER",
                "4": "SETLIST MANAGER",
                "5": "SPLITTER",
                "6": "OUTPUT MANAGER",
                "7": "LOG MANAGER",
                "8": "SETTINGS",
                "0": "Exit"
            }
        )


        if choice == "0":

            print(
                "Bye"
            )

            return



        actions = {

            "1": project_menu,
            "2": source_manager_menu,
            "3": metadata_manager_menu,
            "4": setlist_manager_menu,
            "5": splitter_menu,
            "6": output_manager_menu,
            "7": log_manager_menu,
            "8": settings_menu

        }


        actions[choice]()



if __name__ == "__main__":

    main_menu()
