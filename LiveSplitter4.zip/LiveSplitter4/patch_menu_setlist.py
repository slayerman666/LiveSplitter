#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter patch
Connecte menu.py -> core/menus/setlist_menu.py
"""

import shutil
import re


FILE = "menu.py"


def main():

    print("[PATCH] Loading", FILE)

    with open(FILE, "r", encoding="utf-8") as f:
        data = f.read()


    # Backup

    backup = FILE + ".bak"

    shutil.copy2(
        FILE,
        backup
    )

    print("[OK] Backup:", backup)



    # Add import

    import_line = "from core.menus.setlist_menu import setlist_menu"

    if import_line not in data:

        target = "from core.project import Project"

        if target not in data:
            raise Exception(
                "Import target not found"
            )

        data = data.replace(
            target,
            target + "\n" + import_line
        )

        print("[OK] Import added")

    else:

        print("[OK] Import already present")



    # Replace function

    pattern = r"def setlist_manager_menu\(\):.*?(?=\n\ndef |\n\n# ==================================================)"

    replacement = """def setlist_manager_menu():

    if not require_project():

        return


    setlist_menu(
        CURRENT_PROJECT
    )
"""


    new_data, count = re.subn(
        pattern,
        replacement,
        data,
        flags=re.S
    )


    if count == 0:

        raise Exception(
            "setlist_manager_menu function not found"
        )


    print("[OK] Function replaced")



    with open(FILE, "w", encoding="utf-8") as f:
        f.write(new_data)


    print()
    print("[DONE] menu.py patched")
    print("Run:")
    print("rm -rf __pycache__ core/__pycache__ core/menus/__pycache__")
    print("PYTHONPATH=. python menu.py")



if __name__ == "__main__":
    main()
