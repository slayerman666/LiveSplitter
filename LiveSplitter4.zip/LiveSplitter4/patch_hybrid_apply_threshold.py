#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Patch Hybrid threshold application
"""

from pathlib import Path
import shutil


FILE = Path("core/generators/hybrid.py")


if not FILE.exists():
    raise SystemExit("hybrid.py introuvable")


backup = FILE.with_suffix(".py.thresholdbak")

shutil.copy(FILE, backup)

print(f"[OK] Backup : {backup}")


content = FILE.read_text(
    encoding="utf-8"
)


old = """        if best:

            index, candidate = best

            used.add(
                index
            )
"""


new = """        if best and best[1].score >= self.match_threshold:

            index, candidate = best

            used.add(
                index
            )
"""


if old in content:

    content = content.replace(
        old,
        new,
        1
    )

    print(
        "[OK] Seuil appliqué dans match()"
    )

else:

    print(
        "[WARN] Bloc match non trouvé"
    )


FILE.write_text(
    content,
    encoding="utf-8"
)


print(
    "[OK] Patch terminé"
)
