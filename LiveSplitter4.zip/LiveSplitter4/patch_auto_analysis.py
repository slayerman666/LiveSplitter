#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch LiveSplitter V4.10
Fix:
Project object has no attribute 'analysis'

Remplace:
self.project.analysis.save_result(...)

par:
Analysis(self.project).save_result(...)
"""

from pathlib import Path


FILE = Path("core/generators/auto.py")


OLD = """        self.project.analysis.save_result(
            "fusion_transitions",
            fusion_result
        )
"""


NEW = """        from core.analysis import Analysis

        analysis = Analysis(
            self.project
        )

        analysis.save_result(
            "fusion_transitions",
            fusion_result
        )
"""


def main():

    if not FILE.exists():
        print("[ERROR] File not found:", FILE)
        return

    text = FILE.read_text(
        encoding="utf-8"
    )

    if OLD not in text:
        print("[ERROR] Target code not found")
        print("Le fichier semble déjà patché ou différent.")
        return


    text = text.replace(
        OLD,
        NEW
    )


    FILE.write_text(
        text,
        encoding="utf-8"
    )


    print("[OK] Patch applied:", FILE)


if __name__ == "__main__":
    main()
