from pathlib import Path

p = Path("core/menus/settings_menu.py")

p.write_text("""#!/usr/bin/env python3
# -*- coding: utf-8 -*-

\"\"\"
LiveSplitter V4
Settings Menu
\"\"\"

from core.settings import Settings
from core.utils import log


def header(title):

    print()
    print("=" * 50)
    print(f"=== {title} ===")
    print("=" * 50)
    print()


def pause():
    input("\\nENTER to continue...")


def view_analysis_settings():

    settings = Settings()

    data = settings.get_analysis()

    log(
        "SETTINGS VIEW ANALYSIS",
        "Logs"
    )

    header(
        "ANALYSIS SETTINGS"
    )

    print(f"Mode              : {data['mode']}")
    print(f"Silence threshold : {data['silence_threshold']} dB")
    print(f"Silence duration  : {data['silence_duration']} sec")
    print(f"Hybrid window     : {data['hybrid_window']} sec")

    pause()


def update_analysis_settings():

    settings = Settings()

    header(
        "UPDATE ANALYSIS SETTINGS"
    )

    print("1) Mode")
    print("2) Silence threshold")
    print("3) Silence duration")
    print("4) Hybrid window")
    print("0) Back")

    choice = input("\\nChoice : ").strip()


    if choice == "0":
        return


    if choice == "1":

        value = input("New mode : ").strip()

        settings.set(
            "mode",
            value
        )


    elif choice == "2":

        value = float(
            input("New silence threshold : ")
        )

        settings.set(
            "silence_threshold",
            value
        )


    elif choice == "3":

        value = float(
            input("New silence duration : ")
        )

        settings.set(
            "silence_duration",
            value
        )


    elif choice == "4":

        value = int(
            input("New hybrid window : ")
        )

        settings.set(
            "hybrid_window",
            value
        )


def settings_menu(project):

    log(
        "SETTINGS MENU OPENED",
        "Logs"
    )


    while True:

        header(
            "SETTINGS"
        )

        print(
            "1) View Analysis Settings"
        )

        print(
            "2) Update Analysis Settings"
        )

        print(
            "0) Back"
        )


        choice = input(
            "Choice : "
        ).strip()


        if choice == "0":

            return


        elif choice == "1":

            view_analysis_settings()


        elif choice == "2":

            update_analysis_settings()


        else:

            print(
                "[ERROR] Invalid choice"
            )
""", encoding="utf-8")

print("settings_menu.py updated")
