#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Hybrid threshold patch v2
"""

from pathlib import Path
import shutil
import re


FILE = Path("core/generators/hybrid.py")


if not FILE.exists():
    raise SystemExit("hybrid.py introuvable")


backup = FILE.with_suffix(".py.threshold_v2.bak")

shutil.copy(FILE, backup)

print(f"[OK] Backup : {backup}")


content = FILE.read_text(
    encoding="utf-8"
)


pattern = re.compile(
    r'if best:\s*\n\s*index, candidate = best',
    re.MULTILINE
)


replacement = """if best and best[1].score >= self.match_threshold:

            index, candidate = best"""


if pattern.search(content):

    content = pattern.sub(
        replacement,
        content,
        count=1
    )

    print(
        "[OK] Condition MATCH remplacée"
    )

else:

    print(
        "[WARN] Condition MATCH introuvable"
    )


FILE.write_text(
    content,
    encoding="utf-8"
)


print(
    "[OK] Patch terminé"
)
