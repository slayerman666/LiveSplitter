#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

FILE = Path("core/generators/hybrid.py")

text = FILE.read_text(encoding="utf-8")

old = """elif delta <= 600:
            distance_score = int(                                    100 - ((delta - 60) * 0.12)
            )
                                                             else:
            distance_score = 20"""

new = """elif delta <= 600:
            distance_score = max(
                60,
                int(
                    100 - ((delta - 60) * 0.12)
                )
            )
                                                             else:
            distance_score = 60"""

if old not in text:
    print("[ERROR] exact score block not found")
    raise SystemExit(1)

backup = FILE.with_suffix(".score_floor_v4.bak")
backup.write_text(text, encoding="utf-8")

text = text.replace(old, new, 1)

FILE.write_text(text, encoding="utf-8")

print("[OK] score floor patched")
print(f"[OK] Backup: {backup}")
