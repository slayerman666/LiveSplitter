#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import re

FILE = "core/menus/splitter_menu.py"

with open(FILE, "r", encoding="utf-8") as f:
    content = f.read()

pattern = re.compile(
    r'''normalized_data\s*=\s*\(\s*
\s*project\.load_normalized_setlist\(\)\s*
\s*\)\s*

\s*if\s+normalized_data\s+is\s+None:\s*
\s*raise\s+ValueError\(
.*?
project\.normalized_setlist\s*=\s*\(
\s*NormalizedSetlist\.from_dict\(
\s*normalized_data
\s*\)
\s*\)

\s*log\(
\s*"NORMALIZED SETLIST RESTORED FROM PROJECT",
\s*project
\s*\)''',
    re.S | re.X,
)

replacement = '''normalized_data = (
                        project.load_normalized_setlist()
                    )

                    if normalized_data is None:
                        raise ValueError(
                            "No normalized setlist available. "
                            "Generate setlist first."
                        )

                    project.normalized_setlist = normalized_data

                    log(
                        "NORMALIZED SETLIST RESTORED FROM PROJECT",
                        project
                    )'''

new_content, count = pattern.subn(replacement, content)

if count != 1:
    raise Exception(
        f"Patch impossible : {count} bloc(s) trouvé(s)."
    )

with open(FILE, "w", encoding="utf-8") as f:
    f.write(new_content)

print("✔ splitter_menu.py patché")
