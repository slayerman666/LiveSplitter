#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch LiveSplitter V4.10

Modification :
- display_setlist() utilise uniquement NormalizedSetlist
- edit_setlist() édite NormalizedSetlist
"""

from pathlib import Path


FILE = Path("core/menus/setlist_menu.py")


OLD_DISPLAY_START = "def display_setlist(project):"
OLD_EDIT_START = "def edit_setlist(project):"


NEW_FUNCTIONS = r'''
def display_setlist(project):

    normalized = getattr(
        project,
        "normalized_setlist",
        None
    )

    if normalized is None:
        normalized = project.load_normalized_setlist()

    if normalized is None:
        print(
            "[INFO] No normalized setlist available"
        )
        return None

    print()

    for track in normalized.tracks:

        minutes = track.start // 60
        seconds = track.start % 60

        print(
            f"{track.number:02d} | "
            f"{track.title} | "
            f"{minutes:02d}:{seconds:02d}"
        )

    return normalized



def edit_setlist(project):

    header(
        "EDIT SETLIST"
    )

    normalized = display_setlist(
        project
    )

    if normalized is None:
        pause()
        return


    print()

    choice = input(
        "Track number (0 back) : "
    ).strip()


    if choice == "0":
        return


    try:
        number = int(choice)

    except ValueError:
        print(
            "[ERROR] Invalid number"
        )
        pause()
        return


    track = None

    for item in normalized.tracks:

        if item.number == number:
            track = item
            break


    if track is None:
        print(
            "[ERROR] Track not found"
        )
        pause()
        return


    print()

    print(
        "Current title:",
        track.title
    )


    title = input(
        "New title (ENTER keep) : "
    ).strip()


    if title:
        track.title = title


    project.save_normalized_setlist(
        normalized.to_dict()
    )


    project.normalized_setlist = normalized


    print()

    print(
        "[OK] Normalized setlist updated"
    )

    pause()
'''


def replace_functions(content):

    start = content.index(OLD_DISPLAY_START)

    end = content.index(
        "def export_setlist(project):",
        start
    )

    return (
        content[:start]
        + NEW_FUNCTIONS
        + "\n\n"
        + content[end:]
    )


def main():

    if not FILE.exists():
        print(
            "[ERROR] File not found:",
            FILE
        )
        return


    content = FILE.read_text(
        encoding="utf-8"
    )


    if "def display_setlist(project):" not in content:
        print(
            "[ERROR] display_setlist not found"
        )
        return


    backup = FILE.with_suffix(
        ".py.bak"
    )

    backup.write_text(
        content,
        encoding="utf-8"
    )


    patched = replace_functions(
        content
    )


    FILE.write_text(
        patched,
        encoding="utf-8"
    )


    print(
        "[OK] Patch applied"
    )

    print(
        "[OK] Backup:",
        backup
    )


if __name__ == "__main__":
    main()
