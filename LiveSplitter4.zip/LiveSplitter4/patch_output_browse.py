from pathlib import Path

p = Path("core/menus/output_menu.py")

txt = p.read_text(encoding="utf-8")


old = '''        print("[INFO] Function TODO")
        input("ENTER...")
'''


new = '''        elif choice == "1":

            print()
            print("=== OUTPUT BROWSER ===")
            print()

            tracks = project.paths.get(
                "tracks"
            )

            if tracks and os.path.exists(tracks):

                files = sorted(
                    [
                        f for f in os.listdir(tracks)
                        if f.lower().endswith(".mp3")
                    ]
                )

                print(
                    f"Tracks : {len(files)}"
                )

                for f in files:
                    print(
                        " -",
                        f
                    )

            else:

                print(
                    "[EMPTY] No tracks"
                )


            playlist = os.path.join(
                project.paths["playlist"],
                "playlist.m3u"
            )

            print()

            if os.path.exists(playlist):

                print(
                    "[OK] Playlist :",
                    playlist
                )

            else:

                print(
                    "[MISSING] Playlist"
                )


            input("\\nENTER...")


        else:

            print("[INFO] Function TODO")
            input("ENTER...")
'''


if old not in txt:
    print("Bloc TODO introuvable.")
    raise SystemExit(1)


txt = txt.replace(
    old,
    new,
    1
)


p.write_text(
    txt,
    encoding="utf-8"
)

print("Patch Browse Output appliqué.")
