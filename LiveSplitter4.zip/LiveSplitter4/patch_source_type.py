#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

p = Path("core/source.py")

txt = p.read_text(
    encoding="utf-8"
)

txt = txt.replace(
    "def import_source(self, source_file):",
    "def import_source(self, source_file, source_type=\"local\"):"
)

txt = txt.replace(
    '"type": "local",',
    '"type": source_type,'
)

p.write_text(
    txt,
    encoding="utf-8"
)

print("[OK] SourceManager source type updated")
