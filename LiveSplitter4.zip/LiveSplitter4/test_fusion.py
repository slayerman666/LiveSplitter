# -*- coding: utf-8 -*-

"""
LiveSplitter V4

Test Marker Fusion Engine
"""


from core.fusion import fuse_markers



markers = [

    {
        "time": 100,
        "score": 80,
        "type": "silence"
    },

    {
        "time": 101,
        "score": 90,
        "type": "energy"
    },

    {
        "time": 300,
        "score": 70,
        "type": "onset"
    }

]



clusters = fuse_markers(
    markers
)


print(
    "Input markers:"
)

for marker in markers:

    print(marker)



print(
    "\nFused clusters:"
)

for cluster in clusters:

    print(cluster)
