#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Patch Hybrid -> shared decision models
"""

from pathlib import Path
import shutil


FILE = Path(
    "core/generators/hybrid.py"
)


if not FILE.exists():
    raise SystemExit(
        "hybrid.py introuvable"
    )


BACKUP = FILE.with_suffix(
    ".py.models.bak"
)


shutil.copy(
    FILE,
    BACKUP
)


print(
    f"[OK] Backup : {BACKUP}"
)


content = FILE.read_text(
    encoding="utf-8"
)


# Ajout import modèle commun

old_import = """
from typing import List
"""


new_import = """
from typing import List

from core.models.decision import (
    TrackDecision,
    TransitionCandidate
)
"""


if "core.models.decision import" not in content:

    content = content.replace(
        old_import,
        new_import,
        1
    )

    print(
        "[OK] Import modèle ajouté"
    )

else:

    print(
        "[WARN] Import déjà présent"
    )


# Suppression des anciens modèles locaux

start = content.find(
    "@dataclass\nclass TransitionCandidate"
)

end = content.find(
    "@dataclass\nclass HybridStats"
)


if start != -1 and end != -1:

    content = (
        content[:start]
        +
        content[end:]
    )

    print(
        "[OK] Modèles locaux supprimés"
    )

else:

    print(
        "[WARN] Bloc dataclass non trouvé"
    )


FILE.write_text(
    content,
    encoding="utf-8"
)


print(
    "[OK] Patch terminé"
)
