#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import re

file = Path("core/generators/hybrid.py")

text = file.read_text(encoding="utf-8")

pattern = r"""(\s*if \(\s*
\s*best is not None\s*
\s*and best_score >= self\.match_threshold\s*
\s*\):\s*
)"""

match = re.search(pattern, text)

if not match:
    print("[ERROR] match condition not found")
    exit(1)

insert = r"""\1
            # Protection contre les faux matchs très éloignés
            max_drift = 900

            if abs(best.time - expected) > max_drift:
                best = None
                best_score = -1

"""

new_text = re.sub(pattern, insert, text, count=1)

backup = Path("core/generators/hybrid.py.distance_guard.bak")
backup.write_text(text, encoding="utf-8")

file.write_text(new_text, encoding="utf-8")

print("[OK] patch applied")
print("[OK] backup:", backup)
