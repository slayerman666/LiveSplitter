from pathlib import Path

path = Path("core/generators/hybrid.py")

text = path.read_text()

start = text.find("    def calculate_score(")
end = text.find("    # ==================================================\n    # MATCH", start)

if start == -1:
    raise SystemExit("[ERROR] calculate_score start not found")

if end == -1:
    raise SystemExit("[ERROR] calculate_score end not found")

new_function = """    def calculate_score(
            self,
            candidate,
            expected
    ):

        delta = abs(
            candidate.time - expected
        )

        # Tolérance live :
        # les timings théoriques peuvent dériver
        # fortement (intro, jams, solos, discours)

        if delta <= 60:
            distance_score = 100

        elif delta <= 600:
            distance_score = int(
                100 - ((delta - 60) * 0.12)
            )

        else:
            distance_score = 20

        final = int(
            (distance_score * 0.6)
            +
            (candidate.score * 0.4)
        )

        return final


"""

text = text[:start] + new_function + text[end:]

path.write_text(text)

print("[OK] calculate_score patched")
