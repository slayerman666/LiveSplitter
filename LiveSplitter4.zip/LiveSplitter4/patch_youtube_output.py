from pathlib import Path

p = Path("core/youtube.py")

txt = p.read_text(encoding="utf-8")


old = '''            "noprogress":
                True,
'''

new = '''            "noprogress":
                True,

            "no_warnings":
                True,

            "logger":
                None,
'''

if old not in txt:
    print("[WARN] target not found")
else:
    txt = txt.replace(
        old,
        new,
        1
    )

    p.write_text(
        txt,
        encoding="utf-8"
    )

    print("[OK] yt-dlp output silenced")
