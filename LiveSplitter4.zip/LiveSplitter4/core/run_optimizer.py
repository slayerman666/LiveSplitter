#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import json
import sys

from core.optimizer import optimize
from legacy import setlist


def load_analysis(filename):

    with open(filename, "r", encoding="utf-8") as f:
        return json.load(f)


def main():

    if len(sys.argv) < 3:
        print(
            "Usage: python core/run_optimizer.py analysis.json setlist.txt"
        )
        return


    analysis_file = sys.argv[1]
    setlist_file = sys.argv[2]


    data = load_analysis(
        analysis_file
    )


    transitions = data.get(
        "transitions",
        []
    )


    tracks = setlist.load_setlist(
        setlist_file
    )


    if not tracks:
        print("Setlist vide")
        return


    result = optimize(
        tracks,
        transitions
    )


    output = analysis_file.replace(
        "_analysis.json",
        "_optimized.json"
    )


    with open(
        output,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            result,
            f,
            indent=4,
            ensure_ascii=False
        )


    print()
    print("[OPTIMIZED]")
    print(output)


    for item in result:
        print(
            f'{item["number"]:02d} - '
            f'{item["title"]:<30} '
            f'{item["time"]:.1f}s '
            f'⭐{item["score"]}'
        )


if __name__ == "__main__":
    main()
