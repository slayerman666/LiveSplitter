#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V5.0

AutoMapper

Rôle :
- Charger les transitions Fusion
- Charger la setlist projet
- Associer transitions et titres
- Générer auto_mapping.json
- Générer playlist.m3u

Compatible Termux / Android
"""


import os


from core.utils import (
    get_project_paths,
    load_json,
    save_json,
    ensure_dir,
    clean_filename
)



VERSION = "5.0"



class AutoMapper:


    def __init__(
        self,
        project_dir
    ):

        self.project_dir = project_dir

        self.paths = get_project_paths(
            project_dir
        )

        self.transitions = []

        self.setlist = []

        self.mapping = []



    def load_transitions(self):

        filename = os.path.join(
            self.paths["results"],
            "fusion_transitions.json"
        )


        if not os.path.exists(filename):

            raise FileNotFoundError(
                "fusion_transitions.json introuvable"
            )


        print(
            "[LOAD]",
            filename
        )


        data = load_json(
            filename
        )


        self.transitions = data.get(
            "transitions",
            []
        )



    def load_setlist(self):

        filename = os.path.join(
            self.paths["setlist"],
            "setlist.txt"
        )


        if not os.path.exists(filename):

            raise FileNotFoundError(
                "setlist.txt introuvable"
            )


        print(
            "[LOAD]",
            filename
        )


        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as file:


            for line in file:


                line = line.strip()


                if not line:

                    continue


                if line.startswith("#"):

                    continue


                if "|" not in line:

                    continue



                parts = line.split("|")



                if len(parts) < 2:

                    continue



                try:

                    number = int(
                        parts[0]
                    )

                except:

                    continue



                title = clean_filename(
                    parts[1]
                )



                self.setlist.append(
                    {

                        "number":
                            number,

                        "title":
                            title

                    }
                )



    def build_mapping(self):


        self.mapping = []



        if len(self.transitions) < 2:

            return



        for index in range(
            len(self.transitions) - 1
        ):



            start = self.transitions[index].get(
                "time",
                0
            )


            end = self.transitions[index + 1].get(
                "time",
                start
            )



            if end <= start:

                continue



            if index < len(
                self.setlist
            ):


                title_data = self.setlist[index]


                number = title_data["number"]

                title = title_data["title"]


            else:

                number = index + 1

                title = (
                    f"Track {number:02d}"
                )



            self.mapping.append(
                {

                    "number":
                        number,

                    "title":
                        title,

                    "start":
                        start,

                    "end":
                        end,

                    "duration":
                        end - start,

                    "confidence":
                        self.calculate_confidence(
                            index
                        ),

                    "source":
                        "fusion"

                }
            )



    def calculate_confidence(
        self,
        index
    ):

        if index >= len(
            self.transitions
        ):

            return 0



        transition = self.transitions[index]


        score = transition.get(
            "score",
            0
        )


        if score > 100:

            score = 100


        return int(
            score
        )



    def save_mapping(self):


        ensure_dir(
            self.paths["results"]
        )


        output = os.path.join(
            self.paths["results"],
            "auto_mapping.json"
        )


        save_json(
            output,
            {

                "version":
                    VERSION,

                "count":
                    len(self.mapping),

                "tracks":
                    self.mapping

            }
        )


        print(
            "[OK]",
            output
        )



    def generate_playlist(self):


        ensure_dir(
            self.paths["playlist"]
        )


        output = os.path.join(
            self.paths["playlist"],
            "playlist.m3u"
        )


        with open(
            output,
            "w",
            encoding="utf-8"
        ) as file:


            file.write(
                "#EXTM3U\n"
            )


            for track in self.mapping:


                filename = (

                    f"{track['number']:02d} - "
                    f"{track['title']}.mp3"

                )


                file.write(
                    "../Tracks/"
                    + filename
                    + "\n"
                )



        print(
            "[OK]",
            output
        )



    def run(self):


        print()

        print(
            f"=== LiveSplitter AutoMapper V{VERSION} ==="
        )


        print()


        self.load_transitions()

        self.load_setlist()

        self.build_mapping()

        self.save_mapping()

        self.generate_playlist()



        print()

        print(
            f"[TRACKS] {len(self.mapping)}"
        )


        for track in self.mapping:


            print(

                f"{track['number']:02d} "
                f"{track['title']} "
                f"{track['start']} -> "
                f"{track['end']} "
                f"({track['confidence']}%)"

            )


        return {

            "tracks":
                self.mapping

        }
