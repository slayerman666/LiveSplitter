#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.2

Source Manager

Gestion des sources audio.

Architecture :

Import/Source
    |
    | sélection utilisateur
    v
Projects/<Project>/Source

Après import :
le projet devient la référence de travail.
"""

import os
import shutil

from core.audio_info import get_audio_info
from core.project import IMPORT_ROOT


AUDIO_EXTENSIONS = (
    ".mp3",
    ".flac",
    ".wav",
    ".m4a"
)


class SourceManager:


    def __init__(self, project):

        self.project = project



    def get_import_source_path(self):

        return os.path.join(
            IMPORT_ROOT,
            "Source"
        )



    def list_import_sources(self):

        """
        Liste les fichiers disponibles
        dans Import/Source.
        """


        folder = self.get_import_source_path()


        os.makedirs(
            folder,
            exist_ok=True
        )


        files = []


        for filename in sorted(
            os.listdir(folder)
        ):

            path = os.path.join(
                folder,
                filename
            )


            if (
                os.path.isfile(path)
                and filename.lower().endswith(
                    AUDIO_EXTENSIONS
                )
            ):

                files.append(path)


        return files



    def import_source(self, source_file, source_type="local"):

        """
        Copie une source sélectionnée
        vers le projet actif.
        """


        if not os.path.exists(source_file):

            raise FileNotFoundError(
                source_file
            )


        destination_folder = (
            self.project.paths["source"]
        )


        os.makedirs(
            destination_folder,
            exist_ok=True
        )


        destination = os.path.join(
            destination_folder,
            os.path.basename(source_file)
        )


        shutil.copy2(
            source_file,
            destination
        )


        info = get_audio_info(
            destination
        )


        self.project.data["source"] = {

            "status": True,

            "type": source_type,

            "file": destination,

            "import_file": source_file,

            "info": info
        }


        self.project.save()


        return info



    def get_source(self):

        """
        Retourne la source du projet actif.
        """


        return self.project.data.get(
            "source",
            {}
        )
