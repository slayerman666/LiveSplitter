# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Output Manager

Gestion des fichiers générés.
"""

import os
import json
from core.utils import log



class OutputManager:


    def __init__(self, project):

        self.project = project



    def initialize(self):

        """
        Initialise les dossiers de sortie.
        """

        os.makedirs(
            self.project.paths["tracks"],
            exist_ok=True
        )


        os.makedirs(
            self.project.paths["playlist"],
            exist_ok=True
        )


        self.project.data["output"] = {

            "status": True,

            "tracks": [],

            "playlist": ""
        }


        self.project.save()

        log(
            "OUTPUT INITIALIZED",
            self.project
        )



    def add_track(
        self,
        filename
    ):

        """
        Enregistre un fichier généré.
        """

        if not os.path.exists(filename):

            raise FileNotFoundError(
                filename
            )


        self.project.data["output"]["tracks"].append(
            filename
        )


        self.project.save()



    def set_playlist(
        self,
        filename
    ):

        """
        Enregistre la playlist générée.
        """

        self.project.data["output"]["playlist"] = (
            filename
        )


        self.project.save()



    def get_output(self):

        return (
            self.project.data
            .get(
                "output",
                {}
            )
        )
