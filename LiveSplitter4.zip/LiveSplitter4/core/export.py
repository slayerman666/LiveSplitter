#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V5
Export Manager

Création du package ZIP final.
"""

import os
import zipfile

from core.utils import get_project_paths, ensure_dir, log


VERSION = "1.0"


class ExportManager:


    def __init__(self, project_dir):

        self.project_dir = project_dir
        self.paths = get_project_paths(project_dir)

        self.export_root = os.path.join(
            os.path.dirname(
                os.path.dirname(project_dir)
            ),
            "Export"
        )


    def validate(self):

        tracks = self.paths["tracks"]

        if not os.path.exists(tracks):
            return False

        files = [
            f for f in os.listdir(tracks)
            if f.lower().endswith(".mp3")
        ]

        if not files:
            return False


        playlist = os.path.join(
            self.paths["playlist"],
            "playlist.m3u"
        )

        if not os.path.exists(playlist):
            return False


        return True



    def create_zip(self):

        log(
            "EXPORT START",
            self.project_dir
        )

        if not self.validate():

            raise RuntimeError(
                "Projet incomplet"
            )


        ensure_dir(
            self.export_root
        )


        name = os.path.basename(
            self.project_dir.rstrip("/")
        )


        zip_file = os.path.join(
            self.export_root,
            name + ".zip"
        )


        if os.path.exists(zip_file):
            os.remove(zip_file)



        with zipfile.ZipFile(
            zip_file,
            "w",
            zipfile.ZIP_DEFLATED
        ) as archive:


            for folder in [
                "Output/Tracks",
                "Output/Playlist"
            ]:

                base = os.path.join(
                    self.project_dir,
                    folder
                )


                for root, dirs, files in os.walk(base):

                    for file in files:

                        full = os.path.join(
                            root,
                            file
                        )


                        relative = os.path.join(
                            name,
                            os.path.relpath(
                                full,
                                self.project_dir
                            )
                        )


                        archive.write(
                            full,
                            relative
                        )


        log(
            f"EXPORT COMPLETE : {os.path.basename(zip_file)}",
            self.project_dir
        )

        return zip_file



def main():

    import sys

    if len(sys.argv) < 2:

        print(
            "Usage: python export.py Projects/Project"
        )

        return


    exporter = ExportManager(
        sys.argv[1]
    )


    print(
        f"=== LiveSplitter Export V{VERSION} ==="
    )


    result = exporter.create_zip()


    print(
        "[OK]",
        result
    )



if __name__ == "__main__":

    main()
