#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4

HYBRID Builder

Convertit les décisions Hybrid
en NormalizedSetlist commune.
"""


from core.models.setlist import (
    Track,
    NormalizedSetlist
)


class HybridBuilder:


    def build(self, decisions):

        result = NormalizedSetlist(
            mode="hybrid"
        )


        for index, item in enumerate(decisions):

            # Support objet TrackDecision
            # ou dictionnaire

            if hasattr(item, "__dict__"):

                data = vars(item)

            else:

                data = item


            result.add(

                Track(

                    number=data.get(
                        "number",
                        index + 1
                    ),

                    title=data.get(
                        "title",
                        f"Track {index+1}"
                    ),

                    start=data.get(
                        "detected",
                        data.get(
                            "expected",
                            0
                        )
                    ),

                    end=0,

                    confidence=data.get(
                        "score",
                        0
                    ),

                    source="hybrid",

                    metadata={

                        "expected":
                            data.get(
                                "expected",
                                0
                            ),

                        "correction":
                            data.get(
                                "correction",
                                0
                            ),

                        "status":
                            data.get(
                                "status",
                                "unknown"
                            ),

                        "alternatives":
                            data.get(
                                "alternatives",
                                []
                            )

                    }

                )

            )


        
        # Absorption des groupes FALLBACK intermédiaires
        cleaned = []

        i = 0

        while i < len(result.tracks):

            track = result.tracks[i]

            if track.metadata.get("status") == "FALLBACK":

                j = i

                while (
                    j < len(result.tracks)
                    and result.tracks[j].metadata.get("status") == "FALLBACK"
                ):
                    j += 1

                if (
                    j < len(result.tracks)
                    and result.tracks[j].metadata.get("status") == "MATCHED"
                ):
                    i = j
                    continue

            cleaned.append(track)
            i += 1

        result.tracks = cleaned


        # Reconstruction timeline après suppression

        for idx, track in enumerate(result.tracks):

            track.number = idx + 1

            if idx < len(result.tracks) - 1:
                track.end = result.tracks[idx + 1].start


# Normalisation robuste des timelines

        previous_end = 0

        for track in result.tracks:

            if track.start < previous_end:
                track.start = previous_end

            previous_end = track.start


        # Calcul des fins

        for i in range(len(result.tracks) - 1):

            current = result.tracks[i]
            nxt = result.tracks[i + 1]

            current.end = nxt.start

            if current.end <= current.start:
                current.end = current.start + 1


        # Dernière piste

        if result.tracks:

            last = result.tracks[-1]

            if last.end <= last.start:
                last.end = last.start + 1

        return result
