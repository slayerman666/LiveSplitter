#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4

AUTO Builder

Convertit la sortie AutoMapper
en NormalizedSetlist commune.
"""


from core.models.setlist import (
    Track,
    NormalizedSetlist
)



class AutoBuilder:


    def build(self, data):

        result = NormalizedSetlist(
            mode="auto"
        )


        tracks = data.get(
            "tracks",
            []
        )


        for index, item in enumerate(tracks):

            result.add(

                Track(

                    number=item.get(
                        "number",
                        index + 1
                    ),

                    title=item.get(
                        "title",
                        f"Track {index+1}"
                    ),

                    start=item.get(
                        "start",
                        0
                    ),

                    end=item.get(
                        "end",
                        0
                    ),

                    confidence=item.get(
                        "confidence",
                        0
                    ),

                    source="auto",

                    metadata={
                        "original_source":
                            item.get(
                                "source",
                                "unknown"
                            ),

                        "duration":
                            item.get(
                                "duration",
                                0
                            )
                    }

                )

            )


        return result
