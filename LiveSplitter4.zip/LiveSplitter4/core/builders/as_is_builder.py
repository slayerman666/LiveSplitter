#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4

AS_IS Builder

Convertit une setlist utilisateur
en NormalizedSetlist exploitable
par le Splitter.
"""

from core.models.setlist import (
    Track,
    NormalizedSetlist
)


def timestamp_to_seconds(value):
    if not value:
        return 0

    parts = value.split(":")

    try:
        if len(parts) == 2:
            return (
                int(parts[0]) * 60
                +
                int(parts[1])
            )

        if len(parts) == 3:
            return (
                int(parts[0]) * 3600
                +
                int(parts[1]) * 60
                +
                int(parts[2])
            )

    except ValueError:
        return 0

    return 0


class AsIsBuilder:

    def build(self, data):

        result = NormalizedSetlist(
            mode="as_is"
        )

        tracks = data.get(
            "tracks",
            []
        )

        for index, item in enumerate(tracks):

            start = timestamp_to_seconds(
                item.get(
                    "timestamp",
                    "0"
                )
            )

            result.add(
                Track(
                    number=item.get(
                        "number",
                        index + 1
                    ),

                    title=item.get(
                        "title",
                        f"Track {index+1}"
                    ),

                    start=start,

                    end=0,

                    confidence=100,

                    source="as_is"
                )
            )

        # Calcul des fins intermédiaires
        for i in range(
            len(result.tracks) - 1
        ):
            result.tracks[i].end = (
                result.tracks[i + 1].start
            )

        # Dernier morceau = fin du fichier source
        duration = (
            data
            .get(
                "source",
                {}
            )
            .get(
                "info",
                {}
            )
            .get(
                "duration",
                0
            )
        )

        if result.tracks and duration:
            result.tracks[-1].end = int(duration)

        return result
