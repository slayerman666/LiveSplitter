#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V5.2

Setlist Generator Router

AS_IS / AUTO / HYBRID

Sortie commune :
NormalizedSetlist
"""

import os
import json

from core.mode import ModeManager

from core.builders.as_is_builder import AsIsBuilder
from core.builders.auto_builder import AutoBuilder
from core.builders.hybrid_builder import HybridBuilder

from core.generators.hybrid import HybridGenerator


VERSION = "5.2"


class SetlistGenerator:

    def __init__(
        self,
        project,
        mode="as_is"
    ):
        self.project = project
        self.mode = mode

        self.mode_manager = ModeManager(
            mode
        )


    def load_json_file(self, filename):

        if not os.path.exists(filename):
            return {}

        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as f:
            return json.load(f)



    def load_as_is(self):

        setlist_file = (
            self.project.data
            .get(
                "setlist",
                {}
            )
            .get(
                "file",
                ""
            )
        )


        if not setlist_file:
            return {
                "tracks": []
            }


        manager_data = {
            "tracks": []
        }


        from core.setlist import SetlistManager

        manager = SetlistManager(
            self.project
        )

        manager_data["tracks"] = manager.parse(
            setlist_file
        )


        return manager_data



    def load_auto(self):

        filename = os.path.join(
            self.project.paths["analysis_results"],
            "auto_mapping.json"
        )

        return self.load_json_file(
            filename
        )



    def load_hybrid(self):

        """
        Prépare les données HybridGenerator.

        Sources :
        - setlist importée (titres + timestamps)
        - auto_mapping.json (détections audio)
        """

        def timestamp_to_seconds(value):

            if not value:
                return 0

            parts = value.split(":")

            try:
                if len(parts) == 2:
                    return (
                        int(parts[0]) * 60
                        + int(parts[1])
                    )

                if len(parts) == 3:
                    return (
                        int(parts[0]) * 3600
                        + int(parts[1]) * 60
                        + int(parts[2])
                    )

            except ValueError:
                pass

            return 0


        raw = self.load_as_is()

        setlist = []

        for track in raw.get("tracks", []):

            setlist.append(
                {
                    "number": track.get("number", 0),
                    "title": track.get("title", ""),
                    "time": timestamp_to_seconds(
                        track.get("timestamp", "0")
                    )
                }
            )


        mapping_file = os.path.join(
            self.project.paths["analysis_results"],
            "auto_mapping.json"
        )

        mapping = self.load_json_file(
            mapping_file
        )


        transitions = []

        for track in mapping.get("tracks", []):

            transitions.append(
                {
                    "time": track.get("start", 0),
                    "score": 100,
                    "source": "auto_mapping"
                }
            )


        return (
            {
                "tracks": setlist
            },
            transitions
        )


    def finalize_setlist(
        self,
        normalized
    ):

        """
        Finalisation commune.

        La dernière piste se termine
        à la durée réelle du fichier source.
        """

        duration = (
            self.project.data
            .get(
                "source",
                {}
            )
            .get(
                "info",
                {}
            )
            .get(
                "duration",
                0
            )
        )


        # Correction commune des incohérences temporelles
        # Ne modifie jamais les starts détectés

        for i in range(len(normalized.tracks) - 1):

            current = normalized.tracks[i]
            nxt = normalized.tracks[i + 1]

            if current.end > nxt.start:
                current.end = nxt.start

            if current.end <= current.start:
                current.end = current.start + 1


        # Dernière piste = durée réelle du fichier source

        if normalized.tracks and duration:

            last = normalized.tracks[-1]

            if duration > last.start:
                last.end = int(duration)

            elif last.end <= last.start:
                last.end = last.start + 1


        self.project.save_normalized_setlist(
            normalized.to_dict()
        )

        return normalized



    def generate(self):

        print(
            f"[SETLIST GENERATOR V{VERSION}] MODE : {self.mode}"
        )


        if not self.mode_manager.validate():

            raise ValueError(
                "Invalid setlist mode"
            )



        if self.mode_manager.is_as_is():

            builder = AsIsBuilder()

            data = self.load_as_is()

            return self.finalize_setlist(
                builder.build(
                    data
                )
            )



        elif self.mode_manager.is_auto():

            builder = AutoBuilder()

            data = self.load_auto()

            return self.finalize_setlist(
                builder.build(
                    data
                )
            )



        elif self.mode_manager.is_hybrid():

            builder = HybridBuilder()


            setlist, transitions = (
                self.load_hybrid()
            )


            engine = HybridGenerator()


            decisions = engine.generate(
                setlist.get(
                    "tracks",
                    []
                ),
                transitions
            )


            return self.finalize_setlist(
                builder.build(
                    decisions
                )
            )



        raise ValueError(
            "Unsupported mode"
        )
