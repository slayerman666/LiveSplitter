#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Settings Manager

Gestion des paramètres globaux.
Version initiale :
- Lecture / écriture de config.json
- Paramètres Analysis uniquement
"""

import os
import json

from core.utils import log


BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

CONFIG_FILE = os.path.join(
    BASE_DIR,
    "config.json"
)


DEFAULTS = {

    "mode": "hybrid",

    "silence_threshold": -35,

    "silence_duration": 2.0,

    "hybrid_window": 30

}


class Settings:


    def __init__(self):

        self.file = CONFIG_FILE

        self.data = {}

        self.load()



    def load(self):

        if not os.path.exists(
            self.file
        ):

            self.data = DEFAULTS.copy()

            log(
                "SETTINGS CREATED : config.json",
                BASE_DIR
            )

            self.save()

            return


        with open(
            self.file,
            "r",
            encoding="utf-8"
        ) as f:

            self.data = json.load(f)

        log(
            "SETTINGS LOADED",
            BASE_DIR
        )



    def save(self):

        with open(
            self.file,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                self.data,
                f,
                indent=4,
                ensure_ascii=False
            )

        log(
            "SETTINGS SAVED",
            BASE_DIR
        )


    def get(
        self,
        key,
        default=None
    ):

        return self.data.get(
            key,
            default
        )



    def set(
        self,
        key,
        value
    ):

        self.data[key] = value

        log(
            f"ANALYSIS SETTINGS UPDATED : {key}={value}",
            BASE_DIR
        )

        self.save()



    def get_analysis(self):

        return {

            "mode":
                self.get(
                    "mode",
                    DEFAULTS["mode"]
                ),

            "silence_threshold":
                self.get(
                    "silence_threshold",
                    DEFAULTS["silence_threshold"]
                ),

            "silence_duration":
                self.get(
                    "silence_duration",
                    DEFAULTS["silence_duration"]
                ),

            "hybrid_window":
                self.get(
                    "hybrid_window",
                    DEFAULTS["hybrid_window"]
                )
        }



if __name__ == "__main__":

    settings = Settings()

    print(
        "=== Analysis Settings ==="
    )

    for key, value in settings.get_analysis().items():

        print(
            f"{key} : {value}"
        )
