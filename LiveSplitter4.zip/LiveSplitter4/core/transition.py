#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.2
Transition Engine

Pipeline :

Detectors
    ↓
Fusion
    ↓
Confidence
    ↓
Transitions finales

Compatible Python 3 / Termux Android
"""

import json
import os
import sys

from core.fusion import fuse_markers
from core.confidence import analyze_clusters



def load_json(filename):

    with open(
        filename,
        "r",
        encoding="utf-8"
    ) as f:
        return json.load(f)



def save_json(filename, data):

    with open(
        filename,
        "w",
        encoding="utf-8"
    ) as f:
        json.dump(
            data,
            f,
            indent=4,
            ensure_ascii=False
        )



def normalize_markers(data):
    """
    Convertit les sorties des détecteurs
    vers un format commun.
    """

    markers = []


    # Cas :
    # {
    #   detector:"silence",
    #   markers:[]
    # }

    if isinstance(data, dict):

        detector = data.get(
            "detector",
            "unknown"
        )


        for marker in data.get(
            "markers",
            []
        ):

            markers.append(
                {
                    "detector": detector,

                    "time": marker.get(
                        "time",
                        0
                    ),

                    "score": marker.get(
                        "score",
                        0
                    )
                }
            )


    # Cas :
    # liste directe

    elif isinstance(data, list):

        for marker in data:

            markers.append(
                {
                    "detector": marker.get(
                        "detector",
                        "unknown"
                    ),

                    "time": marker.get(
                        "time",
                        0
                    ),

                    "score": marker.get(
                        "score",
                        0
                    )
                }
            )


    return markers



def build_transitions(detector_files):

    all_markers = []


    for filename in detector_files:

        try:

            data = load_json(
                filename
            )

            all_markers.extend(
                normalize_markers(data)
            )

        except Exception as e:

            print(
                "Erreur lecture",
                filename,
                e
            )



    fused = fuse_markers(
        all_markers
    )


    transitions = analyze_clusters(
        fused
    )


    return transitions



def run(input_files, output):

    transitions = build_transitions(
        input_files
    )


    save_json(
        output,
        transitions
    )


    return transitions



def main():

    if len(sys.argv) < 3:

        print(
            "Usage : python transition.py output.json detector1.json detector2.json ..."
        )

        return


    output = sys.argv[1]

    detectors = sys.argv[2:]


    transitions = run(
        detectors,
        output
    )


    print()
    print(
        "[TRANSITION ENGINE OK]"
    )

    print(
        "Transitions :",
        len(transitions)
    )

    print(
        output
    )



if __name__ == "__main__":

    main()
