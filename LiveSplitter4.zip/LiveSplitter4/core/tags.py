# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Tag Manager v2

Gestion des tags ID3 + artwork + suivi projet.
"""

import os

from mutagen.id3 import (
    ID3,
    TIT2,
    TPE1,
    TALB,
    TRCK,
    TDRC,
    TCON,
    APIC
)


class TagManager:


    def __init__(self, project):

        self.project = project



    def tag_tracks(self):

        metadata = (
            self.project.data
            .get(
                "metadata",
                {}
            )
        )


        setlist = (
            self.project.data
            .get(
                "setlist",
                {}
            )
        )


        tracks = setlist.get(
            "tracks",
            []
        )


        output = (
            self.project.data
            .get(
                "output",
                {}
            )
        )


        files = output.get(
            "tracks",
            []
        )


        tagged = 0


        for track, filename in zip(
            tracks,
            files
        ):

            self.apply_tags(
                filename,
                track,
                metadata
            )

            tagged += 1



        # Mise à jour du statut projet

        self.project.data["output"]["tags"] = True


        self.project.data["output"]["artwork_embedded"] = bool(
            metadata.get(
                "artwork",
                ""
            )
        )


        self.project.data["output"]["tagged_tracks"] = tagged


        self.project.save()



        return True



    def apply_tags(
        self,
        filename,
        track,
        metadata
    ):

        if not os.path.exists(filename):

            raise FileNotFoundError(
                filename
            )


        try:

            tags = ID3(filename)

        except:

            tags = ID3()



        tags["TPE1"] = TPE1(
            encoding=3,
            text=metadata.get(
                "artist",
                ""
            )
        )


        tags["TALB"] = TALB(
            encoding=3,
            text=metadata.get(
                "album",
                ""
            )
        )


        tags["TIT2"] = TIT2(
            encoding=3,
            text=track["title"]
        )


        tags["TRCK"] = TRCK(
            encoding=3,
            text=str(
                track["number"]
            )
        )


        tags["TDRC"] = TDRC(
            encoding=3,
            text=metadata.get(
                "date",
                ""
            )
        )


        tags["TCON"] = TCON(
            encoding=3,
            text=metadata.get(
                "genre",
                ""
            )
        )


        artwork = metadata.get(
            "artwork",
            ""
        )


        # Résolution chemin relatif -> absolu

        if artwork and not os.path.isabs(artwork):

            artwork = os.path.join(
                os.getcwd(),
                artwork
            )


        if artwork and os.path.exists(artwork):

            with open(
                artwork,
                "rb"
            ) as image:

                tags["APIC"] = APIC(
                    encoding=3,
                    mime="image/jpeg",
                    type=3,
                    desc="Cover",
                    data=image.read()
                )


        tags.save(
            filename
        )



    def get_status(self):

        return (
            self.project.data
            .get(
                "output",
                {}
            )
            .get(
                "tags",
                False
            )
        )
