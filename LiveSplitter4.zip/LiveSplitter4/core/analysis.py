# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Analysis Manager

Gestion des résultats d'analyse.
"""

import os
import json
from datetime import datetime



class AnalysisManager:


    def __init__(self, project):

        self.project = project



    def create_analysis(self):

        """
        Initialise l'espace analyse du projet.
        """

        analysis_path = (
            self.project.paths["analysis_results"]
        )


        os.makedirs(
            analysis_path,
            exist_ok=True
        )


        self.project.data["analysis"] = {

            "status": True,

            "created":
                datetime.now()
                .isoformat(),

            "results": {}
        }


        self.project.save()



    def save_result(
        self,
        name,
        data
    ):

        """
        Sauvegarde un résultat d'analyse.
        """

        result_file = os.path.join(
            self.project.paths["analysis_results"],
            name + ".json"
        )


        with open(
            result_file,
            "w",
            encoding="utf-8"
        ) as file:

            json.dump(
                data,
                file,
                indent=4,
                ensure_ascii=False
            )


        self.project.data["analysis"]["results"][name] = (
            result_file
        )


        self.project.save()



    def get_analysis(self):

        return (
            self.project.data
            .get(
                "analysis",
                {}
            )
        )
