#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.5

Silence Detector

Détection des pauses entre morceaux
pour concerts live.

Optimisé :
- public
- applaudissements
- bruit de scène
- transitions longues
"""

import subprocess
import re
import json
import sys



DEFAULT_NOISE = "-30dB"
DEFAULT_DURATION = 2.5
DEFAULT_GAP = 20



def detect_silences(
    audio_file,
    noise=DEFAULT_NOISE,
    duration=DEFAULT_DURATION,
    minimum_gap=DEFAULT_GAP
):


    cmd = [

        "ffmpeg",

        "-hide_banner",

        "-i",

        audio_file,

        "-af",

        f"silencedetect=noise={noise}:d={duration}",

        "-f",

        "null",

        "-"

    ]



    try:


        proc = subprocess.run(

            cmd,

            stdout=subprocess.PIPE,

            stderr=subprocess.PIPE,

            text=True

        )



        output = proc.stderr



        starts = re.findall(

            r"silence_start:\s*([0-9.]+)",

            output

        )


        ends = re.findall(

            r"silence_end:\s*([0-9.]+)",

            output

        )



        print()

        print(
            "[SILENCE DEBUG]"
        )


        print(
            "Noise threshold :",
            noise
        )


        print(
            "Minimum duration :",
            duration
        )


        print(
            "Raw silence starts :",
            len(starts)
        )


        print(
            "Raw silence ends   :",
            len(ends)
        )



        markers = []



        for index, start in enumerate(starts):


            if index >= len(ends):

                continue



            start = float(start)

            end = float(
                ends[index]
            )


            length = end - start



            if length < duration:

                continue



            # Score transition

            score = int(

                min(

                    100,

                    60 + length * 8

                )

            )



            markers.append(

                {

                    "time":
                        round(
                            start + length / 2,
                            3
                        ),

                    "score":
                        score,

                    "quality":
                        score,

                    "type":
                        "silence",

                    "detector":
                        "silence",

                    "duration":
                        round(
                            length,
                            2
                        )

                }

            )



        #
        # Suppression des doublons proches
        #

        filtered = []

        last_time = -9999



        for marker in markers:


            if (

                marker["time"]
                -
                last_time

                <

                minimum_gap

            ):

                continue



            filtered.append(
                marker
            )


            last_time = marker["time"]



        print(
            "After minimum_gap filter :",
            len(filtered)
        )


        print()

        for i, marker in enumerate(
            filtered,
            1
        ):

            print(

                f"{i:02d} "

                f"{marker['time']}s "

                f"score={marker['score']} "

                f"silence={marker['duration']}s"

            )


        print(
            "[/SILENCE DEBUG]"
        )



        return {

            "detector":
                "silence",

            "count":
                len(filtered),

            "markers":
                filtered

        }



    except Exception as error:


        print(
            "[SILENCE ERROR]",
            error
        )


        return {

            "detector":
                "silence",

            "count":
                0,

            "markers":
                []

        }




def analyze(audio_file):

    return detect_silences(
        audio_file
    )



def detect(audio_file):

    return analyze(
        audio_file
    )



def detect_silences_legacy(
    audio_file
):

    return detect_silences(
        audio_file
    )



if __name__ == "__main__":


    if len(sys.argv) < 2:

        print(
            "Usage : python silence.py file.mp3"
        )

        sys.exit(1)



    result = analyze(
        sys.argv[1]
    )


    print(

        json.dumps(

            result,

            indent=4,

            ensure_ascii=False

        )

    )
