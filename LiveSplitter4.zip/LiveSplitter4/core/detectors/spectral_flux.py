# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Spectral Flux Detector

Analyse PCM directe.
Sans numpy.
Compatible setlist.py V4
"""

import subprocess
import json
import struct


MIN_GAP = 90
THRESHOLD = 65

SAMPLE_RATE = 48000
CHANNELS = 2
WINDOW = 4096


def extract_pcm(audio_file):

    cmd = [
        "ffmpeg",
        "-i",
        audio_file,
        "-f",
        "s16le",
        "-ac",
        "1",
        "-ar",
        str(SAMPLE_RATE),
        "-"
    ]

    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL
    )

    return process.stdout



def calculate_energy(samples):

    if not samples:
        return 0

    total = 0

    for s in samples:
        total += abs(s)

    return total / len(samples)



def analyze_windows(stream):

    data = []

    time = 0

    while True:

        raw = stream.read(WINDOW * 2)

        if not raw:
            break

        samples = struct.unpack(
            "<" + "h" * (len(raw)//2),
            raw
        )

        energy = calculate_energy(samples)

        data.append(
            {
                "time": int(time),
                "energy": energy
            }
        )

        time += WINDOW / SAMPLE_RATE


    return data



def detect_changes(data):

    if len(data) < 3:
        return []


    differences = []

    previous = data[0]["energy"]

    for item in data[1:]:

        differences.append(
            abs(item["energy"] - previous)
        )

        previous = item["energy"]


    maximum = max(differences) if differences else 1


    markers = []


    for i, diff in enumerate(differences):

        score = int((diff / maximum) * 100)

        if score >= THRESHOLD:

            t = data[i+1]["time"]

            if (
                not markers
                or t - markers[-1]["time"] >= MIN_GAP
            ):

                markers.append(
                    {
                        "time": t,
                        "score": score,
                        "quality": score,
                        "type": "spectral",
                        "detector": "spectral_flux"
                    }
                )


    return markers



def analyze(audio_file):

    pcm = extract_pcm(audio_file)

    data = analyze_windows(pcm)

    markers = detect_changes(data)

    return {
        "detector": "spectral_flux",
        "count": len(markers),
        "markers": markers
    }



if __name__ == "__main__":

    import sys

    if len(sys.argv) < 2:

        print(
            json.dumps(
                {
                    "error": "missing audio file"
                }
            )
        )

        sys.exit(1)


    result = analyze(sys.argv[1])

    print(
        json.dumps(
            result,
            indent=2
        )
    )
