# -*- coding: utf-8 -*-

"""
LiveSplitter V4

Detectors package
"""

from . import silence
from . import energy
from . import onset
from . import spectral_flux
