# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Spectral Flux Detector

Détection des changements spectraux
Optimisé concerts live / bootlegs.

Sortie compatible setlist.py V4
"""

import sys
import json
import subprocess
import numpy as np


# paramètres concert
MIN_GAP = 90          # secondes minimum entre marqueurs
WINDOW = 2048
HOP = 1024


def load_audio(filename):
    """
    Extraction PCM mono 16 bits via ffmpeg
    """

    cmd = [
        "ffmpeg",
        "-i",
        filename,
        "-ac",
        "1",
        "-ar",
        "44100",
        "-f",
        "s16le",
        "-"
    ]

    process = subprocess.Popen(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.DEVNULL
    )

    raw = process.stdout.read()

    audio = np.frombuffer(
        raw,
        dtype=np.int16
    )

    return audio.astype(float)


def spectral_flux(audio):

    if len(audio) < WINDOW:
        return []

    previous = None
    flux = []

    for i in range(0, len(audio)-WINDOW, HOP):

        frame = audio[i:i+WINDOW]

        # fenêtre Hann
        frame = frame * np.hanning(WINDOW)

        spectrum = np.abs(
            np.fft.rfft(frame)
        )

        spectrum /= np.sum(spectrum) + 1e-9

        if previous is not None:

            diff = spectrum - previous
            diff[diff < 0] = 0

            value = np.sum(diff)

            flux.append(
                {
                    "time": int(i / 44100),
                    "value": float(value)
                }
            )

        previous = spectrum

    return flux


def detect_peaks(values):

    if not values:
        return []

    maximum = max(
        x["value"] for x in values
    )

    markers = []

    last = -MIN_GAP

    for item in values:

        score = int(
            (item["value"] / maximum) * 100
        )

        # seuil confiance
        if score >= 65:

            if item["time"] - last >= MIN_GAP:

                markers.append(
                    {
                        "time": item["time"],
                        "score": score,
                        "quality": score,
                        "type": "spectral",
                        "detector": "spectral_flux"
                    }
                )

                last = item["time"]

    return markers


def analyze(filename):

    audio = load_audio(filename)

    flux = spectral_flux(audio)

    markers = detect_peaks(flux)

    return {
        "detector": "spectral_flux",
        "count": len(markers),
        "markers": markers
    }


if __name__ == "__main__":

    if len(sys.argv) < 2:
        print(
            json.dumps(
                {
                    "error": "missing audio file"
                }
            )
        )
        sys.exit(1)

    result = analyze(sys.argv[1])

    print(
        json.dumps(
            result,
            indent=2
        )
    )
