# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Energy Detector

Extraction RMS FFmpeg + détection générique de transitions.
"""

import subprocess
import math


def extract_rms(audio_file, window=2):

    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-i",
        audio_file,
        "-af",
        (
            f"asetnsamples=n={48000*window},"
            "astats=metadata=1:reset=1,"
            "ametadata=print:key=lavfi.astats.Overall.RMS_level"
        ),
        "-f",
        "null",
        "-"
    ]

    proc = subprocess.run(
        cmd,
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        text=True
    )

    values = []

    current_time = 0

    for line in proc.stdout.splitlines():

        if "lavfi.astats.Overall.RMS_level" not in line:
            continue

        try:
            rms = float(
                line.split("=")[-1].strip()
            )

            if math.isnan(rms) or math.isinf(rms):
                continue

            values.append(
                {
                    "time": current_time,
                    "rms": round(rms, 2)
                }
            )

            current_time += window

        except Exception:
            pass

    return values



def detect_energy_transitions(
    audio_file,
    window=2,
    minimum_gap=45,
    merge_distance=60,
    drop_threshold=5,
    recovery_window=10
):

    rms_data = extract_rms(
        audio_file,
        window
    )

    if len(rms_data) < 10:
        return []


    candidates = []


    for i in range(3, len(rms_data)-recovery_window):

        before = rms_data[i-3]["rms"]
        current = rms_data[i]["rms"]

        drop = before - current


        if drop < drop_threshold:
            continue


        recovery_values = [
            x["rms"]
            for x in rms_data[i:i+recovery_window]
        ]


        if not recovery_values:
            continue


        recovery = max(recovery_values) - current


        score = int(
            min(
                100,
                drop * 8 + recovery * 4
            )
        )


        candidates.append(
            {
                "time": rms_data[i]["time"],
                "score": score,
                "quality": score
            }
        )


    merged = []


    for item in candidates:

        if not merged:
            merged.append(item)
            continue


        previous = merged[-1]


        if item["time"] - previous["time"] < merge_distance:

            if item["score"] > previous["score"]:
                merged[-1] = item

        else:
            merged.append(item)



    results = []

    last_time = -minimum_gap


    for item in merged:

        if item["time"] - last_time >= minimum_gap:

            results.append(item)

            last_time = item["time"]


    return results
