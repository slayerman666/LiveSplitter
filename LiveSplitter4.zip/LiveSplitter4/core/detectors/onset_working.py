#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Onset Detector V5 PCM

Détection des attaques audio à partir du flux PCM FFmpeg.
Compatible Termux Android.
Sortie compatible setlist.py V4
"""

import subprocess
import math
import json
import sys


def analyze(
    audio_file,
    window_ms=500,
    threshold=1.8,
    minimum_gap=20
):

    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel",
        "error",
        "-i",
        audio_file,
        "-f",
        "s16le",
        "-ac",
        "1",
        "-ar",
        "44100",
        "-"
    ]


    try:

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE
        )


        sample_rate = 44100
        bytes_per_sample = 2


        window_samples = int(
            sample_rate * window_ms / 1000
        )


        window_bytes = (
            window_samples *
            bytes_per_sample
        )


        energies = []


        while True:

            data = proc.stdout.read(
                window_bytes
            )

            if not data:
                break


            samples = []


            for i in range(
                0,
                len(data),
                2
            ):

                value = int.from_bytes(
                    data[i:i+2],
                    byteorder="little",
                    signed=True
                )

                samples.append(value)



            if not samples:
                continue



            rms = math.sqrt(
                sum(
                    x*x
                    for x in samples
                )
                /
                len(samples)
            )


            energies.append(rms)



        results = []

        previous = None


        for i, energy in enumerate(energies):


            if previous is not None:

                ratio = (
                    energy /
                    max(previous, 1)
                )


                if ratio >= threshold:

                    score = int(
                        min(
                            100,
                            (ratio - 1) * 100
                        )
                    )


                    item = {
                        "time": round(
                            i * window_ms / 1000
                        ),
                        "score": score,
                        "quality": score,
                        "type": "onset",
                        "detector": "onset"
                    }


                    if (
                        not results
                        or
                        item["time"]
                        -
                        results[-1]["time"]
                        >= minimum_gap
                    ):

                        results.append(item)



            previous = energy



        return results



    except Exception:

        return []



def detect(audio_file):

    return analyze(audio_file)



def detect_onsets(audio_file):

    return analyze(audio_file)



if __name__ == "__main__":


    if len(sys.argv) < 2:

        print(
            json.dumps(
                {
                    "error": "missing audio file"
                }
            )
        )

        sys.exit(1)



    result = analyze(sys.argv[1])


    print(
        json.dumps(
            {
                "detector": "onset",
                "count": len(result),
                "markers": result
            },
            indent=2
        )
    )
