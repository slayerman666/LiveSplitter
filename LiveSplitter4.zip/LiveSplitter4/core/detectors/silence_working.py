#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Silence Detector

Détection des pauses dans les concerts live.
FFmpeg silencedetect compatible Termux Android.

Sortie compatible setlist.py V4
"""

import subprocess
import re
import json
import sys


def detect_silences(
    audio_file,
    noise="-45dB",
    duration=1.5,
    minimum_gap=20
):

    """
    Retourne des candidats de coupure liés aux silences.

    Format V4:
    [
        {
            "time": secondes,
            "score": 0-100,
            "quality": 0-100,
            "type": "silence",
            "detector": "silence"
        }
    ]
    """

    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-i",
        audio_file,
        "-af",
        f"silencedetect=noise={noise}:d={duration}",
        "-f",
        "null",
        "-"
    ]


    try:

        proc = subprocess.run(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )


        output = proc.stderr


        starts = re.findall(
            r"silence_start:\s*([0-9.]+)",
            output
        )


        ends = re.findall(
            r"silence_end:\s*([0-9.]+)",
            output
        )


        results = []


        for i, start in enumerate(starts):

            start = float(start)


            if i < len(ends):

                end = float(ends[i])
                length = end - start

            else:

                length = duration



            if length < duration:
                continue



            score = int(
                min(
                    100,
                    50 + (length * 10)
                )
            )


            cut_time = start + (length / 2)


            results.append(
                {
                    "time": round(cut_time),
                    "score": score,
                    "quality": score,
                    "type": "silence",
                    "detector": "silence"
                }
            )



        filtered = []


        for item in results:

            if not filtered:

                filtered.append(item)
                continue


            if (
                item["time"]
                -
                filtered[-1]["time"]
                >= minimum_gap
            ):

                filtered.append(item)



        return filtered



    except Exception:

        return []



# API V4 standard

def analyze(audio_file):

    return detect_silences(audio_file)



# Compatibilité ancienne API

def detect(audio_file):

    return analyze(audio_file)



if __name__ == "__main__":


    if len(sys.argv) < 2:

        print(
            json.dumps(
                {
                    "error": "missing audio file"
                }
            )
        )

        sys.exit(1)



    result = analyze(sys.argv[1])


    print(
        json.dumps(
            {
                "detector": "silence",
                "count": len(result),
                "markers": result
            },
            indent=2
        )
    )
