#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.2
Fusion Detector

Fusionne :
- silence detector
- onset detector
- spectral flux detector

Format sortie V4 :
{
    "detector": "fusion",
    "count": X,
    "markers": [
        {
            "time": secondes,
            "score": 0-100,
            "quality": 0-100,
            "sources": [],
            "detector": "fusion",
            "type": "fusion"
        }
    ]
}

Compatible Termux Android
"""

import sys
import json


from core.detectors import silence
from core.detectors import onset
from core.detectors import spectral_flux


VERSION = "4.2"


def merge(audio_file, tolerance=5):

    # Chargement des détecteurs
    silence_result = silence.analyze(audio_file)
    onset_result = onset.analyze(audio_file)
    spectral_result = spectral_flux.analyze(audio_file)


    sources = [
        ("silence", silence_result),
        ("onset", onset_result),
        ("spectral_flux", spectral_result),
    ]


    markers = []


    # Extraction uniforme
    for detector_name, result in sources:

        if not isinstance(result, dict):
            continue


        for item in result.get("markers", []):

            markers.append(
                {
                    "time": item.get("time", 0),
                    "score": item.get("score", 0),
                    "quality": item.get(
                        "quality",
                        item.get("score", 0)
                    ),
                    "sources": [
                        detector_name
                    ]
                }
            )


    # Tri chronologique
    markers.sort(
        key=lambda x: x["time"]
    )


    # Fusion des événements proches
    fused = []


    for marker in markers:

        if not fused:

            fused.append(marker)
            continue


        previous = fused[-1]


        if abs(
            marker["time"]
            -
            previous["time"]
        ) <= tolerance:


            # fusion sources

            previous["sources"].extend(
                marker["sources"]
            )


            previous["sources"] = list(
                set(
                    previous["sources"]
                )
            )


            # meilleur score

            previous["score"] = max(
                previous["score"],
                marker["score"]
            )


            previous["quality"] = (
                previous["score"]
            )


            # position moyenne

            previous["time"] = round(
                (
                    previous["time"]
                    +
                    marker["time"]
                )
                /
                2
            )


        else:

            fused.append(marker)



    # Normalisation finale

    for marker in fused:

        marker["detector"] = "fusion"
        marker["type"] = "fusion"



    return {
        "version": VERSION,
        "detector": "fusion",
        "count": len(fused),
        "markers": fused
    }



def analyze(audio_file):

    return merge(audio_file)



def detect(audio_file):

    return analyze(audio_file)



if __name__ == "__main__":


    if len(sys.argv) < 2:

        print(
            "Usage: python fusion.py fichier.mp3"
        )

        sys.exit(1)


    result = analyze(
        sys.argv[1]
    )


    print(
        json.dumps(
            result,
            indent=4,
            ensure_ascii=False
        )
    )
