#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Onset Detector V5
"""

import subprocess
import math
import json
import sys


def detect_markers(
    audio_file,
    window_ms=500,
    threshold=1.8,
    minimum_gap=20
):

    cmd = [
        "ffmpeg",
        "-hide_banner",
        "-loglevel", "error",
        "-i", audio_file,
        "-f", "s16le",
        "-ac", "1",
        "-ar", "44100",
        "-"
    ]

    try:

        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE
        )

        sample_rate = 44100
        window_samples = int(sample_rate * window_ms / 1000)
        window_bytes = window_samples * 2

        energies = []

        while True:

            data = proc.stdout.read(window_bytes)

            if not data:
                break

            samples = []

            for i in range(0, len(data), 2):
                samples.append(
                    int.from_bytes(
                        data[i:i+2],
                        "little",
                        signed=True
                    )
                )

            if not samples:
                continue

            rms = math.sqrt(
                sum(x*x for x in samples) / len(samples)
            )

            energies.append(rms)

        results = []
        previous = None

        for i, energy in enumerate(energies):

            if previous is not None:

                ratio = energy / max(previous, 1)

                if ratio >= threshold:

                    score = min(
                        100,
                        int((ratio - 1) * 100)
                    )

                    marker = {
                        "time": round(i * window_ms / 1000),
                        "score": score,
                        "quality": score,
                        "type": "onset",
                        "detector": "onset"
                    }

                    if (
                        not results
                        or marker["time"] - results[-1]["time"] >= minimum_gap
                    ):
                        results.append(marker)

            previous = energy

        return results

    except Exception:
        return []


def analyze(audio_file):

    markers = detect_markers(audio_file)

    return {
        "detector": "onset",
        "count": len(markers),
        "markers": markers
    }


def detect(audio_file):
    return analyze(audio_file)


if __name__ == "__main__":

    if len(sys.argv) < 2:
        print(json.dumps({"error": "missing audio file"}))
        sys.exit(1)

    print(
        json.dumps(
            analyze(sys.argv[1]),
            indent=2
        )
    )
