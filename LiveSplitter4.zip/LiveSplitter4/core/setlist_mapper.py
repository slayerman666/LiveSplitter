#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.4
Setlist Mapper

Mapping automatique des transitions audio
vers une setlist concert.
"""

import os



def load_setlist(path):

    tracks = []

    if not os.path.exists(path):
        return tracks

    with open(path, "r", encoding="utf-8") as f:

        for line in f:

            line = line.strip()

            if line:
                tracks.append(line)

    return tracks



def get_confidence(t):

    return t.get(
        "confidence",
        t.get("score", 0)
    )



def grade(conf):

    if conf >= 95:
        return "A"

    elif conf >= 85:
        return "B"

    elif conf >= 70:
        return "C"

    return ""



def transition_score(t):

    score = get_confidence(t)

    sources = t.get(
        "sources",
        []
    )


    # Bonus modéré
    # mais pas au détriment
    # des vraies coupures

    if len(sources) >= 3:
        score += 10

    elif len(sources) == 2:
        score += 5


    return score



def select_transitions(
    transitions,
    needed,
    duration,
    total_tracks
):

    ranked = []


    for t in transitions:

        item = dict(t)

        item["_score"] = transition_score(
            item
        )

        ranked.append(item)



    # IMPORTANT :
    # on garde la chronologie
    # d'un concert live

    ranked.sort(
        key=lambda x: x["time"]
    )


    selected = []



    for t in ranked:


        duplicate = False


        for old in selected:

            # suppression doublons proches

            if abs(
                t["time"] - old["time"]
            ) < 90:

                duplicate = True
                break



        if not duplicate:

            selected.append(t)



        if len(selected) >= needed:

            break



    return selected



def map_setlist(
    setlist_file,
    transitions,
    audio_duration=0
):


    titles = load_setlist(
        setlist_file
    )


    if not titles:

        return []



    needed = len(titles) - 1



    selected = select_transitions(
        transitions,
        needed,
        audio_duration,
        len(titles)
    )



    starts = [0]


    for t in selected:

        starts.append(
            int(t["time"])
        )



    while len(starts) < len(titles):

        starts.append(
            audio_duration
        )



    results = []



    for i,title in enumerate(titles):


        start = starts[i]


        if i + 1 < len(starts):

            end = starts[i+1]

        else:

            end = audio_duration



        confidence = 0

        sources = []



        if i < len(selected):

            tr = selected[i]

            confidence = get_confidence(
                tr
            )

            sources = tr.get(
                "sources",
                []
            )



        results.append(
            {
                "track": i + 1,
                "title": title,
                "start": start,
                "end": end,
                "confidence": confidence,
                "grade": grade(confidence),
                "sources": sources
            }
        )


    return results
