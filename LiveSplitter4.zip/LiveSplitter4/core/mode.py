# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Mode Manager

Gestion des modes de génération de setlist.
"""


MODES = (
    "as_is",
    "auto",
    "hybrid"
)


class ModeManager:


    def __init__(self, mode="as_is"):

        self.mode = mode



    def validate(self):

        return self.mode in MODES



    def get_mode(self):

        return self.mode



    def is_as_is(self):

        return self.mode == "as_is"



    def is_auto(self):

        return self.mode == "auto"



    def is_hybrid(self):

        return self.mode == "hybrid"
