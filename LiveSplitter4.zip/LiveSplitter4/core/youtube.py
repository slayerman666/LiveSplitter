#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.2

YouTube Importer

- Récupération métadonnées YouTube
- Téléchargement audio AAC (format 140)
- Conversion MP3 320 kbps
- Import direct dans Projects/<Project>/Source
- Compatible SourceManager V4
- Optimisé Termux Android
"""

import os
import re

from glob import glob
from datetime import datetime

import yt_dlp
from tqdm import tqdm

from core.utils import log


# =========================
# CONFIGURATION
# =========================

COOKIE_FILE = (
    "/storage/emulated/0/LiveSplitter4/"
    "cookies_netscape.txt"
)


# =========================
# PROGRESSION
# =========================

class YoutubeProgress:

    def __init__(self):
        self.bar = None


    def hook(self, data):

        if data.get("status") == "downloading":

            total = (
                data.get("total_bytes")
                or data.get("total_bytes_estimate")
            )

            downloaded = data.get(
                "downloaded_bytes",
                0
            )

            if total:

                if self.bar is None:

                    self.bar = tqdm(
                        total=total,
                        unit="B",
                        unit_scale=True,
                        desc="Téléchargement YouTube",
                        dynamic_ncols=True
                    )

                self.bar.n = downloaded
                self.bar.refresh()


        elif data.get("status") == "finished":

            if self.bar:

                self.bar.close()
                self.bar = None



# =========================
# IMPORTER
# =========================

class YoutubeImporter:


    def __init__(self, project):

        self.project = project

        self.import_dir = (
            self.project.paths["source"]
        )

        os.makedirs(
            self.import_dir,
            exist_ok=True
        )


    # =========================
    # NETTOYAGE NOM
    # =========================

    def clean_filename(self, name):

        name = re.sub(
            r'[\\/:*?"<>|]',
            '',
            name
        )

        return name.strip()



    # =========================
    # OPTIONS YOUTUBE
    # =========================

    def base_options(self):

        opts = {

            "quiet": True,

            "js_runtimes": {
                "deno": {}
            },


            "extractor_args": {

                "youtube": {

                    # Client validé sur Android 16 / Termux
                    "player_client": [
                        "tv_embedded"
                    ]

                }

            },


            # Stabilité réseau Android
            "force_ipv4": True,


            # Évite les coupures sur gros concerts
            "http_chunk_size": 10485760,


            "concurrent_fragment_downloads": 1
        }


        if os.path.exists(COOKIE_FILE):

            opts["cookiefile"] = COOKIE_FILE


        return opts



    # =========================
    # INFOS VIDEO
    # =========================

    def get_info(self, url):

        with yt_dlp.YoutubeDL(
            self.base_options()
        ) as ydl:

            return ydl.extract_info(
                url,
                download=False
            )



    # =========================
    # DOWNLOAD AUDIO
    # =========================

    def download(self, url):

        log(
            "YOUTUBE IMPORT START",
            self.project
        )


        info = self.get_info(url)


        title = self.clean_filename(
            info.get(
                "title",
                "Concert"
            )
        )


        uploader = self.clean_filename(
            info.get(
                "uploader",
                ""
            )
        )


        output = os.path.join(
            self.import_dir,
            title
        )


        progress = YoutubeProgress()


        print()
        print(
            "Téléchargement YouTube..."
        )
        print()


        ydl_opts = self.base_options()


        ydl_opts.update({

            # Format validé :
            # YouTube 2026 → tv_embedded → 140 AAC
            "format":
                "140/bestaudio",


            "outtmpl":
                output + ".%(ext)s",


            "noplaylist":
                True,


            "progress_hooks":
                [
                    progress.hook
                ],


            "postprocessors":
                [

                    {

                        "key":
                            "FFmpegExtractAudio",


                        "preferredcodec":
                            "mp3",


                        "preferredquality":
                            "320"

                    }

                ]

        })


        try:

            with yt_dlp.YoutubeDL(
                ydl_opts
            ) as ydl:

                ydl.download(
                    [url]
                )


        except Exception as e:


            log(
                f"YOUTUBE IMPORT FAILED : {e}",
                self.project
            )


            raise RuntimeError(
                str(e)
            )



        log(
            f"YOUTUBE DOWNLOAD COMPLETE : {title}",
            self.project
        )



        # =========================
        # RECHERCHE MP3 FINAL
        # =========================

        mp3_files = glob(
            os.path.join(
                self.import_dir,
                "*.mp3"
            )
        )


        if not mp3_files:

            raise RuntimeError(
                "MP3 final introuvable après téléchargement"
            )



        real_file = max(
            mp3_files,
            key=os.path.getmtime
        )



        return {

            "file":
                real_file,


            "title":
                title,


            "uploader":
                uploader,


            "date":
                info.get(
                    "upload_date",
                    ""
                ),


            "url":
                url,


            "download_time":
                datetime.now()
                .strftime(
                    "%Y-%m-%d %H:%M:%S"
                )

        }
