# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Setlist Manager

Gestion des setlists projet.
Import et parsing uniquement.
"""

import os
import shutil
from core.utils import log



class SetlistManager:


    def __init__(self, project):

        self.project = project



    def import_setlist(self, filename):


        """
        Copie une setlist dans le projet
        puis la charge.
        """

        if not os.path.exists(filename):

            raise FileNotFoundError(
                filename
            )


        destination = os.path.join(
            self.project.paths["setlist"],
            "setlist.txt"
        )


        os.makedirs(
            self.project.paths["setlist"],
            exist_ok=True
        )


        shutil.copy2(
            filename,
            destination
        )


        tracks = self.parse(
            destination
        )


        self.project.data["setlist"] = {

            "status": True,

            "file": destination,

            "track_count": len(tracks),

            "tracks": tracks
        }


        self.project.save()


        log(
            f"SETLIST IMPORTED : {len(tracks)} tracks",
            self.project
        )


        return tracks



    def parse(self, filename):

        """
        Format :

        01|Titre|MM:SS
        """

        tracks = []


        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as file:


            for line in file:

                line = line.strip()


                if not line:
                    continue


                if line.startswith("#"):
                    continue


                parts = line.split("|")


                if len(parts) != 3:
                    continue


                number, title, timestamp = parts


                try:

                    number = int(number)

                except ValueError:

                    continue


                tracks.append({

                    "number": number,

                    "title":
                        title.strip(),

                    "timestamp":
                        timestamp.strip()
                })


        return tracks



    def get_setlist(self):

        """
        Retourne la setlist actuelle.
        """

        return (
            self.project.data
            .get(
                "setlist",
                {}
            )
        )
