# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Project Recap Manager

Résumé de l'état d'un projet.
"""


class RecapManager:


    def __init__(self, project):

        self.project = project



    def get_recap(self):

        data = self.project.data


        source = data.get(
            "source",
            {}
        )


        metadata = data.get(
            "metadata",
            {}
        )


        setlist = data.get(
            "setlist",
            {}
        )


        analysis = data.get(
            "analysis",
            {}
        )


        output = data.get(
            "output",
            {}
        )


        return {

            "project":
                data.get(
                    "name",
                    ""
                ),


            "source":
                source.get(
                    "status",
                    False
                ),


            "metadata":
                metadata.get(
                    "status",
                    False
                ),


            "setlist":
                setlist.get(
                    "status",
                    False
                ),


            "mode":
                setlist.get(
                    "mode",
                    ""
                ),


            "analysis":
                analysis.get(
                    "status",
                    False
                ),


            "tracks":
                len(
                    output.get(
                        "tracks",
                        []
                    )
                ),


            "tags":
                output.get(
                    "tags",
                    False
                ),


            "artwork":
                bool(
                    metadata.get(
                        "artwork",
                        ""
                    )
                ),


            "playlist":
                bool(
                    output.get(
                        "playlist",
                        ""
                    )
                )

        }
