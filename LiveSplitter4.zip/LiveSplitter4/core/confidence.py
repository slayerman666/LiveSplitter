#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.2
Transition Confidence Engine

Rôle :
- Analyse les clusters issus de fusion.py
- Calcule un score de confiance
- Produit des transitions classées

Compatible Python 3 / Termux Android
"""


import json
import sys


# Poids des détecteurs

DETECTOR_WEIGHTS = {

    "silence": 35,

    "energy": 20,

    "spectral_flux": 15,

    "onset": 10

}



def calculate_quality(cluster):
    """
    Calcule la qualité d'une transition.
    """

    markers = cluster.get(
        "markers",
        []
    )


    if not markers:

        return 0



    sources = set()


    score = 0



    for marker in markers:

        detector = marker.get(
            "detector",
            "unknown"
        )


        sources.add(
            detector
        )


        score += DETECTOR_WEIGHTS.get(
            detector,
            5
        )



    # Bonus diversité des détecteurs

    count = len(
        sources
    )


    if count >= 4:

        score += 20


    elif count == 3:

        score += 15


    elif count == 2:

        score += 10



    # Bonus si les détecteurs sont nombreux

    if len(markers) >= 5:

        score += 10



    return min(
        100,
        score
    )



def analyze_clusters(clusters):
    """
    Transforme les clusters fusionnés
    en transitions avec confiance.
    """

    transitions = []


    for cluster in clusters:

        sources = []


        for marker in cluster.get(
            "markers",
            []
        ):

            detector = marker.get(
                "detector",
                "unknown"
            )


            if detector not in sources:

                sources.append(
                    detector
                )



        transitions.append(

            {

                "time": cluster.get(
                    "time",
                    0
                ),

                "sources": sources,

                "count": len(
                    cluster.get(
                        "markers",
                        []
                    )
                ),

                "quality": calculate_quality(
                    cluster
                )

            }

        )


    # Tri par qualité décroissante

    transitions.sort(
        key=lambda x: x["quality"],
        reverse=True
    )


    return transitions



def load_json(filename):

    with open(
        filename,
        "r",
        encoding="utf-8"
    ) as f:

        return json.load(f)



def save_json(filename, data):

    with open(
        filename,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            data,
            f,
            indent=4,
            ensure_ascii=False
        )



def main():

    if len(sys.argv) < 2:

        print(
            "Usage : python confidence.py fused.json"
        )

        return



    input_file = sys.argv[1]


    clusters = load_json(
        input_file
    )


    transitions = analyze_clusters(
        clusters
    )


    output = input_file.replace(
        "_fused.json",
        "_transitions.json"
    )


    save_json(
        output,
        transitions
    )


    print(
        "[CONFIDENCE OK]"
    )


    print(
        "Transitions analysées :",
        len(transitions)
    )


    print(
        output
    )



if __name__ == "__main__":

    main()
