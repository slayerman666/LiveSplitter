# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Artwork Manager

Gestion des pochettes du projet.
"""

import os
import shutil


ARTWORK_EXTENSIONS = (
    ".jpg",
    ".jpeg",
    ".png"
)


class ArtworkManager:


    def __init__(self, project):

        self.project = project



    def import_artwork(self, filename):

        """
        Importe une pochette
        externe dans le projet.
        """

        if not os.path.exists(filename):

            raise FileNotFoundError(
                filename
            )


        extension = os.path.splitext(
            filename
        )[1].lower()


        if extension not in ARTWORK_EXTENSIONS:

            raise ValueError(
                "Unsupported artwork format"
            )


        destination = os.path.join(
            self.project.paths["artwork"],
            "cover" + extension
        )


        os.makedirs(
            self.project.paths["artwork"],
            exist_ok=True
        )


        # Le fichier est déjà au bon endroit
        if os.path.abspath(filename) != os.path.abspath(destination):

            shutil.copy2(
                filename,
                destination
            )


        self.project.data["metadata"]["artwork"] = (
            destination
        )


        self.project.save()


        return destination



    def get_artwork(self):

        return (
            self.project.data
            .get(
                "metadata",
                {}
            )
            .get(
                "artwork",
                ""
            )
        )
