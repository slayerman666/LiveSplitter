#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.7
Utils

Fonctions communes :
- chemins projet
- JSON
- dossiers
- nettoyage sortie
- temps
- logs

Compatible Termux / Android
"""

import os
import json
import time
import subprocess


VERSION = "4.7"



# ==================================================
# PATHS
# ==================================================

def get_project_paths(project_dir):

    return {

        "project": project_dir,

        "project_json": os.path.join(
            project_dir,
            "project.json"
        ),

        "source": os.path.join(
            project_dir,
            "Source"
        ),

        "analysis": os.path.join(
            project_dir,
            "Analysis"
        ),

        "results": os.path.join(
            project_dir,
            "Analysis",
            "Results"
        ),

        "mapping": os.path.join(
            project_dir,
            "Analysis",
            "Results",
            "auto_mapping.json"
        ),

        "metadata": os.path.join(
            project_dir,
            "Metadata"
        ),

        "artwork": os.path.join(
            project_dir,
            "Metadata",
            "Artwork"
        ),

        "setlist": os.path.join(
            project_dir,
            "Setlist"
        ),

        "output": os.path.join(
            project_dir,
            "Output"
        ),

        "tracks": os.path.join(
            project_dir,
            "Output",
            "Tracks"
        ),

        "playlist": os.path.join(
            project_dir,
            "Output",
            "Playlist"
        )

    }



# ==================================================
# DIRECTORY
# ==================================================

def ensure_dir(path):

    os.makedirs(
        path,
        exist_ok=True
    )

    return path



# ==================================================
# JSON
# ==================================================

def load_json(filename):

    with open(
        filename,
        "r",
        encoding="utf-8"
    ) as f:

        return json.load(f)



def save_json(filename, data):

    ensure_dir(
        os.path.dirname(filename)
    )

    with open(
        filename,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            data,
            f,
            indent=4,
            ensure_ascii=False
        )



# ==================================================
# CLEAN OUTPUT
# ==================================================

def clean_directory(path, extensions=None):

    if not os.path.exists(path):

        return 0


    removed = 0


    for filename in os.listdir(path):

        full = os.path.join(
            path,
            filename
        )


        if not os.path.isfile(full):

            continue


        if extensions:

            if not any(
                filename.lower().endswith(ext)
                for ext in extensions
            ):

                continue


        os.remove(full)

        removed += 1


    return removed



def clean_output(project_dir):

    paths = get_project_paths(
        project_dir
    )

    removed = {

        "tracks": clean_directory(
            paths["tracks"],
            [
                ".mp3",
                ".wav",
                ".flac"
            ]
        ),

        "playlist": clean_directory(
            paths["playlist"],
            [
                ".m3u",
                ".m3u8"
            ]
        )

    }


    return removed



# ==================================================
# FILENAME
# ==================================================

def clean_filename(name):

    chars = [
        "/",
        "\\",
        ":",
        "*",
        "?",
        "\"",
        "<",
        ">",
        "|"
    ]


    for c in chars:

        name = name.replace(
            c,
            "_"
        )


    return name.strip()



# ==================================================
# TIME
# ==================================================

def seconds_to_hms(seconds):

    seconds = int(seconds)

    h = seconds // 3600

    m = (
        seconds % 3600
    ) // 60

    s = (
        seconds % 60
    )

    if h:

        return f"{h:02d}:{m:02d}:{s:02d}"

    return f"{m:02d}:{s:02d}"



def hms_to_seconds(value):

    parts = value.split(":")

    parts = [
        int(x)
        for x in parts
    ]


    if len(parts) == 2:

        return (
            parts[0] * 60
            +
            parts[1]
        )


    if len(parts) == 3:

        return (
            parts[0] * 3600
            +
            parts[1] * 60
            +
            parts[2]
        )


    return 0



# ==================================================
# FFMPEG
# ==================================================

def check_ffmpeg():

    try:

        result = subprocess.run(
            [
                "ffmpeg",
                "-version"
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )

        return result.returncode == 0


    except Exception:

        return False



# ==================================================
# LOG
# ==================================================

def log(message, project=None):

    line = (
        f"[{time.strftime('%H:%M:%S')}] {message}"
    )

    print(line)


    if project:

        if hasattr(project, "paths"):

            logs_dir = project.paths.get(
                "logs"
            )

        else:

            logs_dir = os.path.join(
                project,
                "Logs"
            )


        if logs_dir:

            os.makedirs(
                logs_dir,
                exist_ok=True
            )


            logfile = os.path.join(
                logs_dir,
                "live_splitter.log"
            )


            with open(
                logfile,
                "a",
                encoding="utf-8"
            ) as f:

                f.write(
                    line + "\n"
                )
