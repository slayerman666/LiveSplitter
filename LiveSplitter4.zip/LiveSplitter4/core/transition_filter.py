#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V5.1

Transition Filter

Nettoyage des transitions Fusion.

Objectifs :
- supprimer faux départs
- supprimer silence fin de concert
- éviter trop de découpes
- conserver les vraies transitions chansons
"""



DEFAULT_MIN_GAP = 150
DEFAULT_START_IGNORE = 0
DEFAULT_END_IGNORE = 60



def filter_transitions(
    transitions,
    duration=None,
    min_gap=DEFAULT_MIN_GAP
):

    """
    Filtre les transitions candidates.

    Entrée :
    [
        {
            "time": 1234,
            "markers": [...]
        }
    ]

    Sortie :
    transitions propres.
    """


    if not transitions:

        return []



    result = []

    last_time = -99999



    for item in sorted(
        transitions,
        key=lambda x: x.get("time", 0)
    ):


        time = float(
            item.get(
                "time",
                0
            )
        )



        #
        # Ignore tout début trop proche de zéro
        #

        if time < DEFAULT_START_IGNORE:

            continue



        #
        # Ignore fin de concert
        #

        if duration:

            if time > duration - DEFAULT_END_IGNORE:

                continue



        markers = item.get(
            "markers",
            []
        )



        sources = [
            m.get(
                "detector",
                m.get(
                    "type",
                    "unknown"
                )
            )
            for m in markers
        ]



        #
        # Silence final détecté
        #

        if (
            "silence" in sources
            and duration
            and time > duration - 90
        ):

            continue



        #
        # Calcul score moyen
        #

        scores = [

            m.get(
                "score",
                0
            )

            for m in markers

        ]


        score = 0


        if scores:

            score = int(
                sum(scores)
                /
                len(scores)
            )



        #
        # Distance minimale entre transitions
        #

        if (
            time - last_time
            <
            min_gap
        ):

            continue



        result.append(

            {

                "time": round(
                    time,
                    3
                ),

                "score": score,

                "sources": sources,

                "markers": markers

            }

        )


        last_time = time



    return result
