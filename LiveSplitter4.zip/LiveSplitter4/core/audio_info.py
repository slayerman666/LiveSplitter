#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.2

Audio Information Reader

Extraction des informations audio via ffprobe.
"""

import subprocess
import json



def get_audio_info(filename):

    cmd = [
        "ffprobe",
        "-v",
        "quiet",
        "-print_format",
        "json",
        "-show_format",
        "-show_streams",
        filename
    ]


    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True
    )


    if result.returncode != 0:

        raise RuntimeError(
            result.stderr
        )


    data = json.loads(
        result.stdout
    )


    info = {

        "filename": filename,

        "duration": 0,

        "codec": "",

        "bitrate": "",

        "sample_rate": "",

        "channels": 0
    }



    if "format" in data:

        fmt = data["format"]


        info["duration"] = float(
            fmt.get(
                "duration",
                0
            )
        )


        bitrate = fmt.get(
            "bit_rate",
            ""
        )


        if bitrate:

            info["bitrate"] = (
                int(bitrate) // 1000
            )



    for stream in data.get(
        "streams",
        []
    ):


        if stream.get(
            "codec_type"
        ) == "audio":


            info["codec"] = (
                stream.get(
                    "codec_name",
                    ""
                )
            )


            info["sample_rate"] = (
                stream.get(
                    "sample_rate",
                    ""
                )
            )


            info["channels"] = (
                stream.get(
                    "channels",
                    0
                )
            )


            break



    return info
