#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Decision Models

Objets communs générateurs -> splitter
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class TransitionCandidate:

    time: int

    score: int = 0

    source: str = "unknown"

    used: bool = False



@dataclass
class TrackDecision:

    number: int

    title: str

    expected: int

    detected: int

    correction: int

    status: str

    score: int

    alternatives: List[dict] = field(
        default_factory=list
    )

    validated: bool = False

    manual_offset: int = 0
