#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Normalized Setlist Models

Sortie commune de tous les modes :
AS_IS / AUTO / HYBRID
"""

from dataclasses import dataclass, field
from typing import List


@dataclass
class Track:

    number: int

    title: str

    start: int

    end: int

    confidence: int = 100

    source: str = "unknown"

    metadata: dict = field(
        default_factory=dict
    )


@dataclass
class NormalizedSetlist:

    tracks: List[Track] = field(
        default_factory=list
    )

    mode: str = "unknown"


    def add(self, track: Track):

        self.tracks.append(track)


    def count(self):

        return len(self.tracks)


    def to_dict(self):

        return {
            "mode": self.mode,
            "count": len(self.tracks),
            "tracks": [
                vars(track)
                for track in self.tracks
            ]
        }


    @classmethod
    def from_dict(cls, data):

        result = cls(
            mode=data.get(
                "mode",
                "unknown"
            )
        )

        for item in data.get(
            "tracks",
            []
        ):

            result.add(
                Track(
                    number=item.get(
                        "number",
                        0
                    ),

                    title=item.get(
                        "title",
                        ""
                    ),

                    start=item.get(
                        "start",
                        0
                    ),

                    end=item.get(
                        "end",
                        0
                    ),

                    confidence=item.get(
                        "confidence",
                        0
                    ),

                    source=item.get(
                        "source",
                        "unknown"
                    ),

                    metadata=item.get(
                        "metadata",
                        {}
                    )
                )
            )

        return result
