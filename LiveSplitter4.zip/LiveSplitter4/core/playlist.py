#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.8
Playlist Generator

Rôle :
- Charger le projet
- Scanner Output/Tracks
- Trier les pistes
- Générer playlist.m3u

Compatible Termux / Android
"""

import os
import sys

from core.utils import log
from core.utils import (
    get_project_paths,
    ensure_dir,
    clean_directory
)


VERSION = "4.8"



class Playlist:


    def __init__(self, project_dir):

        self.project_dir = project_dir

        self.paths = get_project_paths(
            project_dir
        )

        self.tracks = []



    def scan_tracks(self):

        tracks_dir = self.paths["tracks"]


        if not os.path.exists(
            tracks_dir
        ):

            return


        for filename in os.listdir(
            tracks_dir
        ):

            if filename.lower().endswith(
                ".mp3"
            ):

                self.tracks.append(
                    filename
                )



    def sort_tracks(self):

        self.tracks.sort(
            key=lambda x:
            int(x.split("-")[0].strip())
            if x.split("-")[0].strip().isdigit()
            else 999
        )



    def generate(self):

        playlist_dir = self.paths["playlist"]


        ensure_dir(
            playlist_dir
        )


        playlist_file = os.path.join(
            playlist_dir,
            "playlist.m3u"
        )


        if os.path.exists(
            playlist_file
        ):

            os.remove(
                playlist_file
            )


        with open(
            playlist_file,
            "w",
            encoding="utf-8"
        ) as f:


            f.write(
                "#EXTM3U\n"
            )


            for track in self.tracks:

                path = os.path.join(
                    "..",
                    "Tracks",
                    track
                )


                f.write(
                    path + "\n"
                )


        return playlist_file



    def run(self):

        log(
            "PLAYLIST START",
            self.project_dir
        )

        print()

        print(
            f"=== LiveSplitter Playlist V{VERSION} ==="
        )

        print()


        print(
            "[SCAN] Output/Tracks"
        )


        self.scan_tracks()


        self.sort_tracks()


        print(
            f"[TRACKS] {len(self.tracks)}"
        )


        playlist = self.generate()

        log(
            f"PLAYLIST COMPLETE : {len(self.tracks)} tracks",
            self.project_dir
        )


        print(
            f"[OK] {playlist}"
        )



def main():

    if len(sys.argv) < 2:

        print(
            "Usage : python playlist.py projects/Project"
        )

        sys.exit(1)


    playlist = Playlist(
        sys.argv[1]
    )


    playlist.run()



if __name__ == "__main__":

    main()
