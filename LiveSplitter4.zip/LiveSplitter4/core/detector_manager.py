# -*- coding: utf-8 -*-

"""
LiveSplitter V4

Detector Manager

Interface centrale des détecteurs audio.
"""

from core.detectors import silence
from core.detectors import energy
from core.detectors import onset
from core.detectors import spectral_flux



class DetectorManager:


    def __init__(self, project):

        self.project = project


        self.detectors = {

            "silence": silence,

            "energy": energy,

            "onset": onset,

            "spectral_flux": spectral_flux

        }



    def available(self):

        return list(
            self.detectors.keys()
        )



    def get_detector(self, name):

        if name not in self.detectors:

            raise ValueError(
                f"Unknown detector: {name}"
            )


        return self.detectors[name]



    def run(self, name, audio_file):

        detector = self.get_detector(
            name
        )


        if name == "silence":

            result = detector.detect_silences(
                audio_file
            )

            return result.get(
                "markers",
                []
            )



        if name == "energy":

            return detector.detect_energy_transitions(
                audio_file
            )



        if name == "onset":

            if hasattr(
                detector,
                "detect_onsets"
            ):

                return detector.detect_onsets(
                    audio_file
                )


        if name == "spectral_flux":

            if hasattr(
                detector,
                "detect"
            ):

                return detector.detect(
                    audio_file
                )



        raise NotImplementedError(
            f"Detector interface not implemented: {name}"
        )



    def run_all(self, audio_file):

        markers = []


        for name in self.available():

            try:

                results = self.run(
                    name,
                    audio_file
                )


                for marker in results:

                    marker["detector"] = name

                    markers.append(
                        marker
                    )


            except Exception as error:

                print(
                    f"{name} detector error:",
                    error
                )


        return markers
