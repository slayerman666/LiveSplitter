#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.5

Marker Fusion Engine

Rôle :
- Fusionner les marqueurs de plusieurs détecteurs.
- Garder les transitions utiles.
- Ne pas écraser les transitions énergie espacées.
"""


import json
import sys



DEFAULT_TOLERANCE = 5.0



def fuse_markers(
    markers,
    tolerance=DEFAULT_TOLERANCE
):
    """
    Fusion des marqueurs proches uniquement.

    Deux événements sont fusionnés uniquement
    s'ils sont dans une fenêtre de quelques secondes.
    """


    if not markers:

        return []



    #
    # Nettoyage
    #

    cleaned = []


    for marker in markers:


        if "time" not in marker:

            continue


        try:

            marker["time"] = float(
                marker["time"]
            )

        except:

            continue



        if "score" not in marker:

            marker["score"] = 0



        if "detector" not in marker:

            marker["detector"] = marker.get(
                "type",
                "unknown"
            )


        cleaned.append(
            marker
        )



    #
    # Tri chronologique
    #

    cleaned.sort(
        key=lambda x: x["time"]
    )



    clusters = []

    current = []



    for marker in cleaned:


        if not current:

            current.append(
                marker
            )

            continue



        previous = current[-1]



        delta = (
            marker["time"]
            -
            previous["time"]
        )



        if delta <= tolerance:


            current.append(
                marker
            )


        else:


            clusters.append(
                build_transition(
                    current
                )
            )


            current = [
                marker
            ]



    if current:

        clusters.append(
            build_transition(
                current
            )
        )



    return clusters




def build_transition(
    markers
):


    if not markers:

        return None



    #
    # meilleur marqueur
    #

    best = max(
        markers,
        key=lambda x:
        x.get(
            "score",
            0
        )
    )



    sources = []



    for marker in markers:


        detector = marker.get(
            "detector",
            "unknown"
        )


        if detector not in sources:

            sources.append(
                detector
            )



    return {

        "time":
            round(
                best["time"],
                3
            ),


        "score":
            best.get(
                "score",
                0
            ),


        "sources":
            sources,


        "markers":
            markers

    }




def load_markers(
    filename
):


    with open(
        filename,
        "r",
        encoding="utf-8"
    ) as file:

        return json.load(
            file
        )




def save_clusters(
    filename,
    clusters
):


    with open(
        filename,
        "w",
        encoding="utf-8"
    ) as file:


        json.dump(
            {
                "version": "4.5",
                "count": len(clusters),
                "transitions": clusters
            },
            file,
            indent=4,
            ensure_ascii=False
        )




def main():


    if len(sys.argv) < 2:

        print(
            "Usage : python fusion.py markers.json"
        )

        return



    input_file = sys.argv[1]


    markers = load_markers(
        input_file
    )


    transitions = fuse_markers(
        markers
    )



    output = input_file.replace(
        ".json",
        "_fusion_transitions.json"
    )



    save_clusters(
        output,
        transitions
    )



    print(
        "[FUSION OK]"
    )


    print(
        "Transitions :",
        len(transitions)
    )


    print(
        output
    )




if __name__ == "__main__":

    main()
