#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.1

Project Manager

Gestion du projet et de son arborescence.
Architecture :
- Import = zone d'entrée globale
- Projects = espaces de travail autonomes
"""

import json
import os
from datetime import datetime
from core.utils import log


PROJECT_VERSION = "1.1"


# Racines globales
BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)


IMPORT_ROOT = os.path.join(
    BASE_DIR,
    "Import"
)


PROJECT_ROOT = os.path.join(
    BASE_DIR,
    "Projects"
)


EXPORT_ROOT = os.path.join(
    BASE_DIR,
    "Export"
)



class Project:


    def __init__(self, path):

        self.path = path

        self.file = os.path.join(
            path,
            "project.json"
        )


        self.paths = {

            "source":
                os.path.join(
                    path,
                    "Source"
                ),

            "metadata":
                os.path.join(
                    path,
                    "Metadata"
                ),

            "artwork":
                os.path.join(
                    path,
                    "Metadata",
                    "Artwork"
                ),

            "setlist":
                os.path.join(
                    path,
                    "Setlist"
                ),

            "analysis":
                os.path.join(
                    path,
                    "Analysis"
                ),

            "analysis_energy":
                os.path.join(
                    path,
                    "Analysis",
                    "Energy"
                ),

            "analysis_onset":
                os.path.join(
                    path,
                    "Analysis",
                    "Onset"
                ),

            "analysis_spectral":
                os.path.join(
                    path,
                    "Analysis",
                    "Spectral"
                ),

            "analysis_results":
                os.path.join(
                    path,
                    "Analysis",
                    "Results"
                ),

            "normalized_setlist":
                os.path.join(
                    path,
                    "Analysis",
                    "Results",
                    "normalized_setlist.json"
                ),

            "logs":
                os.path.join(
                    path,
                    "Logs"
                ),

            "output":
                os.path.join(
                    path,
                    "Output"
                ),

            "tracks":
                os.path.join(
                    path,
                    "Output",
                    "Tracks"
                ),

            "playlist":
                os.path.join(
                    path,
                    "Output",
                    "Playlist"
                )
        }


        self.data = {

            "version":
                PROJECT_VERSION,

            "created":
                "",

            "updated":
                "",

            "name":
                "",

            "source":
                {},

            "metadata":
                {},

            "setlist":
                {},

            "analysis":
                {},

            "output":
                {}
        }



    @staticmethod
    def init_import():

        folders = [

            IMPORT_ROOT,

            EXPORT_ROOT,

            os.path.join(
                IMPORT_ROOT,
                "Source"
            ),

            os.path.join(
                IMPORT_ROOT,
                "Artwork"
            ),

            os.path.join(
                IMPORT_ROOT,
                "Setlist"
            )
        ]


        for folder in folders:

            os.makedirs(
                folder,
                exist_ok=True
            )



    def create(self, name):

        self.init_import()


        now = datetime.now().isoformat()


        self.data["name"] = name

        self.data["created"] = now

        self.data["updated"] = now


        log(
            f"PROJECT CREATED : {name}",
            self
        )


        os.makedirs(
            self.path,
            exist_ok=True
        )


        for folder in self.paths.values():

            os.makedirs(
                folder,
                exist_ok=True
            )


        self.save()



    def save(self):

        self.data["updated"] = (
            datetime.now()
            .isoformat()
        )


        with open(
            self.file,
            "w",
            encoding="utf-8"
        ) as f:


            json.dump(
                self.data,
                f,
                indent=4,
                ensure_ascii=False
            )



    def load(self):

        with open(
            self.file,
            "r",
            encoding="utf-8"
        ) as f:

            self.data = json.load(f)


        log(
            f"PROJECT OPENED : {self.data.get('name', 'unknown')}",
            self
        )



    def save_normalized_setlist(self, data):

        filename = self.paths["normalized_setlist"]

        os.makedirs(
            os.path.dirname(filename),
            exist_ok=True
        )

        with open(
            filename,
            "w",
            encoding="utf-8"
        ) as f:

            json.dump(
                data,
                f,
                indent=4,
                ensure_ascii=False
            )

        log(
            "NORMALIZED SETLIST SAVED",
            self
        )


    def load_normalized_setlist(self):

        filename = self.paths["normalized_setlist"]

        if not os.path.exists(filename):

            log(
                "NORMALIZED SETLIST NOT FOUND",
                self
            )

            return None


        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as f:

            data = json.load(f)


        from core.models.setlist import NormalizedSetlist


        normalized = NormalizedSetlist.from_dict(
            data
        )


        log(
            "NORMALIZED SETLIST LOADED",
            self
        )


        return normalized


    def recap(self):

        return {

            "project":
                self.data.get(
                    "name",
                    ""
                ),

            "source":
                bool(
                    self.data.get(
                        "source"
                    )
                ),

            "metadata":
                bool(
                    self.data.get(
                        "metadata"
                    )
                ),

            "setlist":
                bool(
                    self.data.get(
                        "setlist"
                    )
                ),

            "analysis":
                bool(
                    self.data.get(
                        "analysis"
                    )
                ),

            "output":
                bool(
                    self.data.get(
                        "output"
                    )
                )
        }
