#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4

Main Menu Controller

Gestion du projet actif et navigation principale.
"""

import os

from core.project import Project

from core.menus.project_menu import project_menu
from core.menus.source_menu import source_menu
from core.menus.metadata_menu import metadata_menu
from core.menus.setlist_menu import setlist_menu
from core.menus.splitter_menu import splitter_menu
from core.menus.output_menu import output_menu
from core.menus.log_menu import log_menu
from core.menus.settings_menu import settings_menu


VERSION = "4"
PROJECT_ROOT = "projects"

CURRENT_PROJECT = None


def header(title):
    print()
    print("=" * 50)
    print(f"=== {title} ===")
    print("=" * 50)
    print()


def pause():
    input("\nENTER to continue...")


def choose(title, options):

    while True:
        header(title)

        for key, value in options.items():
            print(f"{key}) {value}")

        print()

        choice = input("Choice : ").strip()

        if choice in options:
            return choice

        print("[ERROR] Invalid choice")


def require_project():

    if CURRENT_PROJECT is None:
        print()
        print("[WARN] No active project")
        print("Open or create a project first.")
        pause()
        return False

    return True


def main_menu():

    global CURRENT_PROJECT

    os.makedirs(PROJECT_ROOT, exist_ok=True)

    while True:

        choice = choose(
            f"LiveSplitter V{VERSION}",
            {
                "1": "PROJECT",
                "2": "SOURCE MANAGER",
                "3": "METADATA MANAGER",
                "4": "SETLIST MANAGER",
                "5": "SPLITTER",
                "6": "OUTPUT MANAGER",
                "7": "LOG MANAGER",
                "8": "SETTINGS",
                "0": "EXIT",
            }
        )

        if choice == "0":
            print("Bye")
            return ("0", CURRENT_PROJECT)

        elif choice == "1":
            CURRENT_PROJECT = project_menu(
                CURRENT_PROJECT
            )

        elif choice == "2":
            source_menu(
                CURRENT_PROJECT
            )

        elif choice == "3":
            metadata_menu(
                CURRENT_PROJECT
            )

        elif choice == "4":
            setlist_menu(
                CURRENT_PROJECT
            )

        elif choice == "5":
            splitter_menu(
                CURRENT_PROJECT
            )

        elif choice == "6":
            output_menu(
                CURRENT_PROJECT
            )

        elif choice == "7":
            log_menu(
                CURRENT_PROJECT
            )

        elif choice == "8":
            settings_menu(
                CURRENT_PROJECT
            )


if __name__ == "__main__":
    main_menu()
