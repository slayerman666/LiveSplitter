#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.8
Core Analyzer

Gestion du pipeline audio.

Sorties :
projects/<Projet>/Analysis/Results/

Compatible Termux / Android
"""

import os
import sys
import time


BASE_DIR = os.path.dirname(
    os.path.dirname(
        os.path.abspath(__file__)
    )
)

if BASE_DIR not in sys.path:
    sys.path.insert(
        0,
        BASE_DIR
    )


from core.detectors import fusion
from core.project import Project

from core.utils import (
    get_project_paths,
    save_json,
    log
)


VERSION = "4.8"



class Analyzer:


    def __init__(self, audio_file):

        self.audio_file = audio_file

        self.name = os.path.splitext(
            os.path.basename(audio_file)
        )[0]


        self.project_dir = os.path.dirname(
            os.path.dirname(
                audio_file
            )
        )


        self.project = Project(
            self.project_dir
        )

        try:
            self.project.load()
        except Exception:
            pass

        self.paths = get_project_paths(
            self.project_dir
        )


        self.analysis_dir = self.paths[
            "results"
        ]


        self.results = {

            "version": VERSION,

            "file": audio_file,

            "timestamp":
                time.strftime(
                    "%Y-%m-%d %H:%M:%S"
                ),

            "detectors": {},

            "markers": []

        }



    def check_file(self):

        if not os.path.exists(
            self.audio_file
        ):

            raise FileNotFoundError(
                self.audio_file
            )

        return True



    def normalize_markers(
        self,
        detector_name,
        data
    ):

        markers = []


        if not isinstance(
            data,
            dict
        ):

            return markers



        for point in data.get(
            "markers",
            []
        ):

            markers.append(

                {

                    "detector":
                        detector_name,

                    "time":
                        point.get(
                            "time",
                            0
                        ),

                    "score":
                        point.get(
                            "score",
                            0
                        ),

                    "quality":
                        point.get(
                            "quality",
                            point.get(
                                "score",
                                0
                            )
                        ),

                    "sources":
                        point.get(
                            "sources",
                            []
                        )

                }

            )


        return markers



    def run_detector(
        self,
        name,
        detector
    ):

        print(
            f"[ANALYSE] {name}..."
        )


        try:

            result = detector.analyze(
                self.audio_file
            )


            self.results[
                "detectors"
            ][name] = result



            output = os.path.join(

                self.analysis_dir,

                f"{self.name}_{name}.json"

            )


            save_json(
                output,
                result
            )


            print(
                f"[OK] {name}"
            )


            return result



        except Exception as e:


            print(
                f"[ERREUR] {name}: {e}"
            )


            self.results[
                "detectors"
            ][name] = {

                "error": str(e),

                "markers": []

            }


            return None



    def build_markers(self):

        markers = []


        fusion_data = self.results[
            "detectors"
        ].get(

            "fusion",

            {}

        )


        markers.extend(

            self.normalize_markers(
                "fusion",
                fusion_data
            )

        )


        markers.sort(
            key=lambda x: x["time"]
        )


        self.results[
            "markers"
        ] = markers



        output = os.path.join(

            self.analysis_dir,

            f"{self.name}_markers.json"

        )


        save_json(
            output,
            markers
        )



    def save_report(self):

        report = os.path.join(

            self.analysis_dir,

            f"{self.name}_analysis.json"

        )


        save_json(
            report,
            self.results
        )


        print()

        print(
            "[RAPPORT]"
        )

        print(
            report
        )


        return report



    def analyze(self):

        self.check_file()

        log(
            "ANALYSIS START",
            self.project
        )


        print()

        print(
            f"=== LiveSplitter Analyzer V{VERSION} ==="
        )

        print()

        print(
            self.audio_file
        )

        print()


        self.run_detector(
            "fusion",
            fusion
        )


        self.build_markers()


        log(
            f"ANALYSIS COMPLETE : {len(self.results.get('markers', []))} markers",
            self.project
        )

        return self.results



def analyze_file(audio_file):

    analyzer = Analyzer(
        audio_file
    )


    analyzer.analyze()


    return analyzer.save_report()



if __name__ == "__main__":


    if len(sys.argv) < 2:

        print(
            "Usage : python analyzer.py fichier.mp3"
        )

        sys.exit(1)


    analyze_file(
        sys.argv[1]
    )
