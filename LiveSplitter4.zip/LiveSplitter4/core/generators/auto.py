#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.10
Auto Generator

Pipeline:
Project
 -> DetectorManager
 -> Fusion
 -> Transition Filter
 -> AutoMapper

Compatible Termux Android
"""

import os

from core.detector_manager import DetectorManager
from core.fusion import fuse_markers
from core.transition_filter import filter_transitions
from core.auto_mapper import AutoMapper


VERSION = "4.10"


class AutoGenerator:


    def __init__(self, project):

        self.project = project

        self.detectors = DetectorManager(
            project
        )

        self.mapping = []


    def get_audio_file(self):

        data = self.project.data


        source = data.get(
            "source",
            {}
        )


        audio = source.get(
            "file"
        )


        if not audio:

            raise ValueError(
                "Audio source unavailable"
            )


        return audio



    def generate(self):

        print()

        print(
            f"=== LiveSplitter AutoGenerator V{VERSION} ==="
        )

        print()


        audio_file = self.get_audio_file()


        print(
            "[DEBUG] Audio file:",
            audio_file
        )


        #
        # DETECTORS
        #

        print()

        print(
            "[AUTO] Running detectors..."
        )


        markers = self.detectors.run_all(
            audio_file
        )


        print(
            f"[AUTO] Markers detected: {len(markers)}"
        )


        #
        # FUSION
        #

        print()

        print(
            "[AUTO] Fusion markers..."
        )


        transitions = fuse_markers(
            markers
        )


        print(
            f"[AUTO] Raw transitions: {len(transitions)}"
        )


        #
        # FILTER
        #

        print()

        print(
            "[AUTO] Filtering transitions..."
        )


        duration = (
            self.project.data
            .get("source", {})
            .get("info", {})
            .get("duration")
        )


        transitions = filter_transitions(
            transitions,
            duration
        )


        print(
            f"[AUTO] Valid transitions: {len(transitions)}"
        )


        #
        # SAVE FUSION
        #

        fusion_result = {

            "version": "4.0",

            "raw_count": len(
                markers
            ),

            "filtered_count": len(
                transitions
            ),

            "transitions": transitions

        }


        import json
        results_dir = os.path.join(
            self.project.path,
            "Analysis",
            "Results"
        )
        os.makedirs(results_dir, exist_ok=True)

        with open(
            os.path.join(results_dir, "fusion_transitions.json"),
            "w",
            encoding="utf-8"
        ) as f:
            json.dump(
                fusion_result,
                f,
                indent=4,
                ensure_ascii=False
            )


        print(
            "[AUTO] Fusion saved"
        )



        #
        # AUTOMAPPER
        #

        print()

        print(
            "[AUTO] Running AutoMapper..."
        )


        project_path = getattr(
            self.project,
            "path",
            None
        )

        if not project_path:
            project_path = (
                self.project.paths.get("root")
                or self.project.paths.get("project")
            )

        if not project_path:
            raise ValueError(
                "Project path unavailable"
            )

        mapper = AutoMapper(
            project_path
        )

        mapper.run()


        self.mapping = mapper.mapping


        return self.mapping
