#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.1

Hybrid Generator Engine

Moteur hybride :
- Setlist théorique + transitions détectées
- Recherche meilleure correspondance
- Score distance + confiance
- Clustering transitions proches
- Lookahead anti faux match
- Fallback intelligent
- Compatible Logs V4/V5
"""

from dataclasses import dataclass

from core.models.decision import (
    TrackDecision,
    TransitionCandidate
)


# ==================================================
# MODELES
# ==================================================

@dataclass
class HybridStats:
    matched: int = 0
    fallback: int = 0
    ignored: int = 0
    clusters: int = 0
    average_score: float = 0
    average_correction: float = 0


# ==================================================
# GENERATOR
# ==================================================

class HybridGenerator:

    def __init__(
        self,
        window=30,
        cluster_time=180,
        ignore_before=60,
        match_threshold=70
    ):

        self.window = window
        self.cluster_time = cluster_time
        self.ignore_before = ignore_before
        self.match_threshold = match_threshold

        self.stats = HybridStats()


    # ==================================================
    # PUBLIC
    # ==================================================

    def generate(
        self,
        setlist,
        transitions
    ):

        candidates = self.cleanup(
            transitions
        )

        candidates = self.cluster(
            candidates
        )

        result = self.match(
            setlist,
            candidates
        )

        self.compute_stats(
            result
        )

        return result


    # ==================================================
    # CLEANUP
    # ==================================================

    def cleanup(
        self,
        transitions
    ):

        result = []

        seen = set()

        for item in transitions:

            t = item.get(
                "time",
                0
            )

            if t < self.ignore_before:
                self.stats.ignored += 1
                continue

            if t in seen:
                continue

            seen.add(t)

            result.append(
                TransitionCandidate(
                    time=t,
                    score=item.get(
                        "score",
                        0
                    ),
                    source=item.get(
                        "source",
                        "unknown"
                    )
                )
            )

        return result


    # ==================================================
    # CLUSTER
    # ==================================================

    def cluster(
        self,
        transitions
    ):

        if not transitions:
            return []

        transitions.sort(
            key=lambda x: x.time
        )

        clusters = []

        current = [
            transitions[0]
        ]

        for item in transitions[1:]:

            if (
                item.time -
                current[-1].time
                <
                self.cluster_time
            ):
                current.append(item)

            else:
                clusters.append(current)
                current = [item]


        clusters.append(current)

        self.stats.clusters = len(
            clusters
        )

        result = []

        for cluster in clusters:

            best = max(
                cluster,
                key=lambda x: x.score
            )

            result.append(best)

        return result

    # ==================================================
    # SCORE
    # ==================================================

    def calculate_score(
        self,
        candidate,
        expected
    ):

        delta = abs(
            candidate.time - expected
        )

        # Tolérance live :
        # intro, jams, solos, discours

        if delta <= 60:
            distance_score = 100

        elif delta <= 600:
            distance_score = int(
                100 - ((delta - 60) * 0.12)
            )

        else:
            distance_score = 20


        final = int(
            (distance_score * 0.6)
            +
            (candidate.score * 0.4)
        )

        return final


    # ==================================================
    # MATCH
    # ==================================================

    def match(
        self,
        setlist,
        transitions
    ):

        result = []

        if not setlist:
            return result


        transition_index = 0
        last_detected = 0


        for index, track in enumerate(setlist):

            number = track.get(
                "number",
                index + 1
            )

            title = track.get(
                "title",
                f"Track {index+1}"
            )

            expected = track.get(
                "time",
                last_detected
            )


            # Première piste

            if index == 0:

                result.append(
                    TrackDecision(
                        number=number,
                        title=title,
                        expected=0,
                        detected=0,
                        correction=0,
                        status="START",
                        score=100
                    )
                )

                continue


            best = None
            best_index = None
            best_score = -1


            for idx in range(
                transition_index,
                len(transitions)
            ):

                candidate = transitions[idx]


                if candidate.time <= last_detected:
                    continue


                score = self.calculate_score(
                    candidate,
                    expected
                )


                if score > best_score:
                    best_score = score
                    best = candidate
                    best_index = idx



            # Match trouvé

            if (
                best is not None
                and best_score >= self.match_threshold
            ):

                # Protection faux match très éloigné
                max_drift = 900

                if abs(best.time - expected) > max_drift:

                    best = None
                    best_score = -1



            if best is not None:

                keep_current = True


                # Lookahead :
                # évite de prendre une transition
                # appartenant au morceau suivant

                if index + 1 < len(setlist):

                    next_expected = setlist[
                        index + 1
                    ].get(
                        "time",
                        expected
                    )


                    current_delta = abs(
                        best.time - expected
                    )

                    next_delta = abs(
                        best.time - next_expected
                    )


                    if next_delta + 120 < current_delta:
                        keep_current = False



                if keep_current:

                    detected = best.time


                    result.append(
                        TrackDecision(
                            number=number,
                            title=title,
                            expected=expected,
                            detected=detected,
                            correction=detected - expected,
                            status="MATCHED",
                            score=best_score
                        )
                    )


                    last_detected = detected
                    transition_index = best_index + 1

                    continue



            # FALLBACK

            detected = max(
                expected,
                last_detected
            )


            result.append(
                TrackDecision(
                    number=number,
                    title=title,
                    expected=expected,
                    detected=detected,
                    correction=0,
                    status="FALLBACK",
                    score=0
                )
            )


        return result

    # ==================================================
    # STATS
    # ==================================================

    def compute_stats(
        self,
        tracks
    ):

        scores = []
        corrections = []


        for track in tracks:

            if track.status == "MATCHED":

                self.stats.matched += 1

                scores.append(
                    track.score
                )

                corrections.append(
                    abs(
                        track.correction
                    )
                )


            elif track.status == "FALLBACK":

                self.stats.fallback += 1



        if scores:

            self.stats.average_score = (
                sum(scores)
                /
                len(scores)
            )


        if corrections:

            self.stats.average_correction = (
                sum(corrections)
                /
                len(corrections)
            )



# ==================================================
# COMPATIBILITE V3
# ==================================================

def apply_hybrid(
    setlist,
    transitions,
    window=30
):

    engine = HybridGenerator(
        window=window
    )


    return [
        vars(x)
        for x in engine.generate(
            setlist,
            transitions
        )
    ]
