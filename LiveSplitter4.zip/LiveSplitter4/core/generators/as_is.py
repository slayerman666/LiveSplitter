# -*- coding: utf-8 -*-

"""
LiveSplitter V4
AS IS Setlist Generator

Génération depuis la setlist projet.
"""


import os



class AsIsGenerator:


    def __init__(
        self,
        project
    ):

        self.project = project



    def generate(self):

        """
        Charge la setlist existante du projet.
        """

        filename = os.path.join(
            self.project.paths["setlist"],
            "setlist.txt"
        )


        if not os.path.exists(filename):

            raise FileNotFoundError(
                filename
            )


        tracks = self.parse(
            filename
        )


        result = {

            "status": True,

            "mode": "as_is",

            "file": filename,

            "track_count": len(tracks),

            "tracks": tracks
        }


        self.project.data["setlist"] = result


        self.project.save()


        return result



    def parse(
        self,
        filename
    ):

        tracks = []


        with open(
            filename,
            "r",
            encoding="utf-8"
        ) as file:


            for line in file:

                line = line.strip()


                if not line:
                    continue


                if line.startswith("#"):
                    continue


                parts = line.split("|")


                if len(parts) != 3:
                    continue


                number, title, timestamp = parts


                try:

                    number = int(number)

                except ValueError:

                    continue


                tracks.append({

                    "number": number,

                    "title": title.strip(),

                    "timestamp": timestamp.strip()
                })


        return tracks

