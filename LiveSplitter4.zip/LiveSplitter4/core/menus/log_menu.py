#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Log Manager Menu
"""

from pathlib import Path

def log_menu(project):

    if project is None:
        print("[WARN] No active project")
        input("ENTER...")
        return


    while True:

        print()
        print("=" * 50)
        print("=== LOG MANAGER ===")
        print("=" * 50)

        print("1) View Log")
        print("2) Clear Log")
        print("0) Back")


        choice = input("Choice : ").strip()


        if choice == "0":

            return


        elif choice == "1":

            print()

            logs_dir = project.paths.get(
                "logs"
            )

            log_file = None


            if logs_dir:

                candidate = Path(logs_dir) / "live_splitter.log"

                if candidate.exists():

                    log_file = candidate


            if log_file:

                print("=== LOG ===")
                print()

                print(
                    log_file.read_text(
                        encoding="utf-8"
                    )
                )

            else:

                print(
                    "[INFO] No log available"
                )


            input("\nENTER...")


        elif choice == "2":

            print()

            logs_dir = project.paths.get(
                "logs"
            )


            if not logs_dir:

                print(
                    "[INFO] No log directory"
                )

                input("\nENTER...")
                continue


            log_file = Path(logs_dir) / "live_splitter.log"


            if not log_file.exists():

                print(
                    "[INFO] No log available"
                )

                input("\nENTER...")
                continue


            confirm = input(
                "Clear log? Y/N : "
            ).strip().lower()


            if confirm == "y":

                log_file.write_text(
                    "",
                    encoding="utf-8"
                )

                print(
                    "[OK] Log cleared"
                )

            else:

                print(
                    "[CANCEL]"
                )


            input("\nENTER...")


        else:

            print(
                "[INFO] Unknown choice"
            )

            input("\nENTER...")
