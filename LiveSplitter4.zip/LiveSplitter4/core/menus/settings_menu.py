#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Settings Menu
"""


def settings_menu(project):

    from core.settings import Settings
    from core.utils import log


    log(
        "SETTINGS MENU OPENED",
        "Logs"
    )


    settings = Settings()


    while True:

        print()
        print("=" * 50)
        print("=== SETTINGS ===")
        print("=" * 50)

        print("1) View Analysis Settings")
        print("2) Update Analysis Settings")
        print("0) Back")


        choice = input(
            "Choice : "
        ).strip()


        if choice == "0":

            return


        elif choice == "1":

            data = settings.get_analysis()

            log(
                "SETTINGS VIEW ANALYSIS",
                "Logs"
            )

            print()
            print("=== ANALYSIS SETTINGS ===")
            print()

            print(
                f"Mode              : {data.get('mode')}"
            )

            print(
                f"Silence threshold : {data.get('silence_threshold')} dB"
            )

            print(
                f"Silence duration  : {data.get('silence_duration')} sec"
            )

            print(
                f"Hybrid window     : {data.get('hybrid_window')} sec"
            )

            input(
                "\nENTER..."
            )


        elif choice == "2":

            print()
            print("=== UPDATE ANALYSIS SETTINGS ===")
            print()

            print("1) Silence threshold")
            print("2) Silence duration")
            print("3) Hybrid window")
            print("0) Back")


            option = input(
                "Choice : "
            ).strip()


            if option == "1":

                current = settings.get_analysis().get(
                    "silence_threshold"
                )

                value = input(
                    f"Silence threshold [{current}] : "
                ).strip()

                if not value:
                    continue

                value = float(value)

                settings.set(
                    "silence_threshold",
                    value
                )


            elif option == "2":

                current = settings.get_analysis().get(
                    "silence_duration"
                )

                value = input(
                    f"Silence duration [{current}] : "
                ).strip()

                if not value:
                    continue

                value = float(value)

                settings.set(
                    "silence_duration",
                    value
                )


            elif option == "3":

                current = settings.get_analysis().get(
                    "hybrid_window"
                )

                value = input(
                    f"Hybrid window [{current}] : "
                ).strip()

                if not value:
                    continue

                value = int(value)

                settings.set(
                    "hybrid_window",
                    value
                )

        else:

            print(
                "[ERROR] Invalid choice"
            )
