#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.1

Project Menu

Gestion du projet actif.
"""

import os

from core.project import Project, PROJECT_ROOT



def header(title):

    print()
    print("=" * 50)
    print(f"=== {title} ===")
    print("=" * 50)
    print()



def pause():

    input("\nENTER to continue...")



def list_projects():

    Project.init_import()

    os.makedirs(
        PROJECT_ROOT,
        exist_ok=True
    )


    projects = []


    for name in os.listdir(PROJECT_ROOT):

        path = os.path.join(
            PROJECT_ROOT,
            name
        )


        if os.path.isdir(path):

            project_file = os.path.join(
                path,
                "project.json"
            )


            if os.path.exists(project_file):

                projects.append(name)


    return projects



def new_project():

    header(
        "NEW PROJECT"
    )


    name = input(
        "Project name : "
    ).strip()


    if not name:

        print(
            "[ERROR] Empty project name"
        )

        pause()

        return None



    path = os.path.join(
        PROJECT_ROOT,
        name
    )


    project = Project(
        path
    )


    project.create(
        name
    )


    print()

    print(
        "[OK] Project created"
    )


    pause()


    return project



def open_project():

    header(
        "OPEN EXISTING PROJECT"
    )


    projects = list_projects()


    if not projects:

        print(
            "[INFO] No projects found"
        )

        pause()

        return None



    for i, name in enumerate(
        projects,
        start=1
    ):

        print(
            f"{i}) {name}"
        )


    print(
        "0) Back"
    )


    choice = input(
        "Choice : "
    ).strip()


    if choice == "0":

        return None



    try:

        index = int(choice) - 1

        name = projects[index]


    except Exception:

        print(
            "[ERROR] Invalid choice"
        )

        pause()

        return None



    path = os.path.join(
        PROJECT_ROOT,
        name
    )


    project = Project(
        path
    )


    project.load()


    print()

    print(
        "[OK] Project loaded"
    )


    pause()


    return project



def recap_project(project):

    header(
        "RECAP SO FAR"
    )


    if project is None:

        print(
            "[INFO] No active project"
        )

    else:

        recap = project.recap()


        for key, value in recap.items():

            print(
                f"{key:<12}: {value}"
            )


    pause()



def project_menu(project):


    while True:


        header(
            "PROJECT"
        )


        if project:

            print(
                f"ACTIVE PROJECT : {project.data.get('name','')}"
            )

            print()



        print(
            "1) New Project"
        )

        print(
            "2) Open Existing Project"
        )

        print(
            "3) Recap So Far"
        )

        print(
            "0) Back"
        )


        choice = input(
            "Choice : "
        ).strip()



        if choice == "0":

            return project



        elif choice == "1":

            new = new_project()

            if new:

                project = new



        elif choice == "2":

            new = open_project()

            if new:

                project = new



        elif choice == "3":

            recap_project(
                project
            )
