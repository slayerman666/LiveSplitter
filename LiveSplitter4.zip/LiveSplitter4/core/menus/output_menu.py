#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
from core.export import ExportManager

"""
LiveSplitter V4
Output Manager Menu
"""


def output_menu(project):

    if project is None:
        print("[WARN] No active project")
        input("ENTER...")
        return


    while True:

        print()
        print("=" * 50)
        print("=== OUTPUT MANAGER ===")
        print("=" * 50)
        print("1) Browse Output")
        print("2) Export Package")
        print("3) Cleanup")
        print("0) Back")

        choice = input("Choice : ").strip()

        if choice == "0":
            return

        elif choice == "1":

            print()
            print("=== OUTPUT BROWSER ===")
            print()

            tracks = project.paths.get(
                "tracks"
            )

            if tracks and os.path.exists(tracks):

                files = sorted(
                    [
                        f for f in os.listdir(tracks)
                        if f.lower().endswith(".mp3")
                    ]
                )

                print(
                    f"Tracks : {len(files)}"
                )

                for f in files:

                    path = os.path.join(
                        tracks,
                        f
                    )

                    size = os.path.getsize(
                        path
                    ) // 1024 // 1024

                    print(
                        f" - {f} ({size} MB) OK"
                    )

            else:

                print(
                    "[EMPTY] No tracks"
                )


            playlist = os.path.join(
                project.paths["playlist"],
                "playlist.m3u"
            )

            print()

            if os.path.exists(playlist):

                print(
                    "[OK] Playlist :",
                    playlist
                )

            else:

                print(
                    "[MISSING] Playlist"
                )


            input("\nENTER...")


        elif choice == "2":

            print()
            print("=== EXPORT PACKAGE ===")
            print()

            try:

                exporter = ExportManager(
                    project.path
                )

                zip_file = exporter.create_zip()

                print(
                    "[OK] Package created:"
                )

                print(
                    zip_file
                )

            except Exception as error:

                print(
                    "[ERROR]",
                    error
                )


            input("\nENTER...")


        elif choice == "3":

            while True:

                print()
                print("=" * 50)
                print("=== CLEANUP ===")
                print("=" * 50)
                print("1) Delete Generated Tracks")
                print("2) Delete Playlist")
                print("0) Back")

                cleanup = input("Choice : ").strip()


                if cleanup == "0":
                    break


                elif cleanup == "1":

                    print()
                    print("WARNING:")
                    print("This will delete generated MP3 tracks.")

                    confirm = input(
                        "Continue? Y/N : "
                    ).strip().lower()


                    if confirm == "y":

                        tracks = project.paths.get(
                            "tracks"
                        )

                        removed = 0

                        if tracks and os.path.exists(tracks):

                            for file in os.listdir(tracks):

                                if file.lower().endswith(".mp3"):

                                    os.remove(
                                        os.path.join(
                                            tracks,
                                            file
                                        )
                                    )

                                    removed += 1


                        print(
                            f"[OK] {removed} tracks deleted"
                        )

                    else:

                        print(
                            "[CANCEL]"
                        )


                    input("\nENTER...")


                elif cleanup == "2":

                    print()
                    print(
                        "Delete playlist.m3u?"
                    )

                    confirm = input(
                        "Continue? Y/N : "
                    ).strip().lower()


                    if confirm == "y":

                        playlist = os.path.join(
                            project.paths["playlist"],
                            "playlist.m3u"
                        )


                        if os.path.exists(playlist):

                            os.remove(
                                playlist
                            )

                            print(
                                "[OK] Playlist deleted"
                            )

                        else:

                            print(
                                "[INFO] No playlist found"
                            )

                    else:

                        print(
                            "[CANCEL]"
                        )


                    input("\nENTER...")


                else:

                    print(
                        "[INFO] Unknown choice"
                    )


        else:

            print("[INFO] Unknown choice")
            input("ENTER...")
