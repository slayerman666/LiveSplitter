#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.10

Setlist Manager Menu

Gestion :
- import setlist
- génération AS_IS / AUTO / HYBRID
- export setlist
"""

import os
import shutil

from core.setlist import SetlistManager
from core.setlist_generator import SetlistGenerator



def header(title):

    print()

    print("=" * 50)

    print(
        f"=== {title} ==="
    )

    print("=" * 50)



def pause():

    input(
        "\nENTER..."
    )



def list_import_setlists():

    folder = (
        "/storage/emulated/0/"
        "LiveSplitter4/"
        "Import/"
        "Setlist"
    )

    os.makedirs(
        folder,
        exist_ok=True
    )

    result = []

    for name in sorted(
        os.listdir(folder)
    ):

        path = os.path.join(
            folder,
            name
        )

        if (
            os.path.isfile(path)
            and name.lower().endswith(".txt")
        ):

            result.append(
                path
            )

    return result



def import_setlist(project):

    header(
        "IMPORT SETLIST"
    )


    files = list_import_setlists()


    if not files:

        print(
            "[INFO] No setlist found"
        )

        pause()

        return



    for i, file in enumerate(
        files,
        1
    ):

        print(
            f"{i}) {os.path.basename(file)}"
        )


    print(
        "0) Back"
    )


    choice = input(
        "Choice : "
    )


    if choice == "0":

        return


    try:

        selected = files[
            int(choice)-1
        ]


        manager = SetlistManager(
            project
        )


        tracks = manager.import_setlist(
            selected
        )


        # IMPORTANT :
        # Conservation des titres importés
        # pour SetlistGenerator V5.2

        project.setlist_tracks = tracks


        print()

        print(
            "[OK] Setlist imported"
        )

        print(
            f"Tracks : {len(tracks)}"
        )


    except Exception as error:

        print(
            "[ERROR]",
            error
        )


    pause()

def generate_setlist(project, mode):

    header(
        f"GENERATE SETLIST - {mode.upper()}"
    )


    try:

        generator = SetlistGenerator(
            project,
            mode
        )


        result = generator.generate()


        # IMPORTANT :
        # Conservation de la sortie V5.2
        # pour le menu Splitter

        project.normalized_setlist = result


        print()

        print(
            "[OK] Generation completed"
        )


        print(
            "Mode :",
            result.mode
        )


        print(
            "Tracks :",
            result.count()
        )


    except Exception as error:

        import traceback


        print()

        print("=" * 60)

        print(
            "SETLIST GENERATOR CRASH"
        )

        print("=" * 60)


        traceback.print_exc()


        print()

        print(
            f"[ERROR] {repr(error)}"
        )


    pause()



def create_generate_menu(project):

    while True:

        header(
            "CREATE / GENERATE SETLIST"
        )


        print(
            "1) AUTO"
        )

        print(
            "2) HYBRID"
        )

        print(
            "3) AS IS"
        )

        print(
            "0) Back"
        )


        choice = input(
            "Choice : "
        )


        if choice == "0":

            return


        elif choice == "1":

            generate_setlist(
                project,
                "auto"
            )


        elif choice == "2":

            generate_setlist(
                project,
                "hybrid"
            )


        elif choice == "3":

            generate_setlist(
                project,
                "as_is"
            )


def display_setlist(project):

    normalized = getattr(
        project,
        "normalized_setlist",
        None
    )

    if normalized is None:
        normalized = project.load_normalized_setlist()

    if normalized is None:
        print(
            "[INFO] No normalized setlist available"
        )
        return None

    print()

    for track in normalized.tracks:

        minutes = track.start // 60
        seconds = track.start % 60

        print(
            f"{track.number:02d} | "
            f"{track.title} | "
            f"{minutes:02d}:{seconds:02d}"
        )

    return normalized



def edit_setlist(project):

    header(
        "EDIT SETLIST"
    )

    normalized = display_setlist(
        project
    )

    if normalized is None:
        pause()
        return


    print()

    choice = input(
        "Track number (0 back) : "
    ).strip()


    if choice == "0":
        return


    try:
        number = int(choice)

    except ValueError:
        print(
            "[ERROR] Invalid number"
        )
        pause()
        return


    track = None

    for item in normalized.tracks:

        if item.number == number:
            track = item
            break


    if track is None:
        print(
            "[ERROR] Track not found"
        )
        pause()
        return


    print()

    print(
        "Current title:",
        track.title
    )


    title = input(
        "New title (ENTER keep) : "
    ).strip()


    if title:
        track.title = title


    project.save_normalized_setlist(
        normalized.to_dict()
    )


    project.normalized_setlist = normalized


    print()

    print(
        "[OK] Normalized setlist updated"
    )

    pause()


def export_setlist(project):

    header(
        "EXPORT SETLIST"
    )


    source = (
        project.data
        .get(
            "setlist",
            {}
        )
        .get(
            "file",
            ""
        )
    )


    if (
        not source
        or not os.path.exists(source)
    ):

        print(
            "[INFO] No setlist"
        )

        pause()

        return



    folder = project.paths.get(
        "export",
        os.path.join(
            project.paths["root"],
            "Export"
        )
    )


    os.makedirs(
        folder,
        exist_ok=True
    )


    destination = os.path.join(
        folder,
        "setlist_export.txt"
    )


    shutil.copy2(
        source,
        destination
    )


    print(
        "[OK]",
        destination
    )


    pause()

def setlist_menu(project):

    if project is None:

        print(
            "[WARN] No active project"
        )

        pause()

        return



    while True:

        header(
            "SETLIST MANAGER"
        )


        print(
            "1) Import Setlist"
        )

        print(
            "2) Create / Generate Setlist"
        )

        print(
            "3) Edit Setlist"
        )

        print(
            "4) Export Setlist"
        )

        print(
            "0) Back"
        )


        choice = input(
            "Choice : "
        )


        if choice == "0":

            return


        elif choice == "1":

            import_setlist(
                project
            )


        elif choice == "2":

            create_generate_menu(
                project
            )


        elif choice == "3":

            edit_setlist(
                project
            )


        elif choice == "4":

            export_setlist(
                project
            )


        else:

            print(
                "[ERROR] Invalid choice"
            )

            pause()
