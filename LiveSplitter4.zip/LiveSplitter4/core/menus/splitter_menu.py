#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V5

Splitter Menu

Rôle :
- Vérification projet
- Lancement découpage
- Rapport
- Génération playlist

La génération de setlist est gérée par setlist_menu.py

Le Splitter reçoit uniquement une NormalizedSetlist.
"""

import os

from core.splitter import Splitter
from core.playlist import Playlist
from core.utils import log
from core.models.setlist import NormalizedSetlist



def header(title):

    print()

    print("=" * 50)

    print(
        f"=== {title} ==="
    )

    print("=" * 50)



def pause():

    input(
        "\nENTER..."
    )



def verify_project(project):

    print()

    print(
        "=== PROJECT CHECK ==="
    )


    data = project.data

    checks = []


    source = (
        data
        .get(
            "source",
            {}
        )
        .get(
            "file"
        )
    )


    checks.append(
        (
            "Audio source",
            bool(source)
        )
    )


    setlist = (
        data
        .get(
            "setlist",
            {}
        )
        .get(
            "file"
        )
    )


    checks.append(
        (
            "Setlist",
            bool(setlist)
        )
    )


    artwork = (
        data
        .get(
            "metadata",
            {}
        )
        .get(
            "artwork"
        )
    )


    checks.append(
        (
            "Artwork",
            bool(artwork)
        )
    )


    metadata = data.get(
        "metadata",
        {}
    )


    checks.append(
        (
            "Metadata",
            bool(metadata)
        )
    )


    ok = True


    for name, status in checks:

        if status:

            print(
                f"[OK] {name}"
            )

        else:

            ok = False

            print(
                f"[MISSING] {name}"
            )


    print()


    if ok:

        print(
            "[READY] Project ready for splitting."
        )

    else:

        print(
            "[WARN] Project incomplete."
        )


    pause()

def splitter_menu(project):

    if project is None:

        print(
            "[WARN] No active project"
        )

        pause()

        return



    while True:

        header(
            "SPLITTER"
        )


        print(
            "1) Verify Project"
        )

        print(
            "2) Run Split"
        )

        print(
            "3) Last Report"
        )

        print(
            "4) Generate Playlist"
        )

        print(
            "0) Back"
        )


        choice = input(
            "Choice : "
        ).strip()



        if choice == "0":

            return



        elif choice == "1":

            verify_project(
                project
            )



        elif choice == "2":

            try:

                if not hasattr(
                    project,
                    "normalized_setlist"
                ):

                    normalized_data = (
                        project.load_normalized_setlist()
                    )

                    if normalized_data is None:
                        raise ValueError(
                            "No normalized setlist available. "
                            "Generate setlist first."
                        )

                    normalized_data = (
                        project.load_normalized_setlist()
                    )

                    if normalized_data is None:
                        raise ValueError(
                            "No normalized setlist available. "
                            "Generate setlist first."
                    )

                    project.normalized_setlist = normalized_data

                    log(
                        "NORMALIZED SETLIST RESTORED FROM PROJECT",
                        project
                    )

                    log(
                        "NORMALIZED SETLIST RESTORED FROM PROJECT",
                        project
                    )


                splitter = Splitter(
                    project.path
                )


                splitter.run(
                    project.normalized_setlist
                )


            except Exception as error:

                print()

                print(
                    f"[ERROR] {error}"
                )


            pause()



        elif choice == "3":

            print()

            print(
                "=" * 50
            )

            print(
                "=== SPLIT REPORT ==="
            )

            print(
                "=" * 50
            )


            data = project.data


            print()

            print(
                "Project :",
                data.get(
                    "name",
                    ""
                )
            )


            source = data.get(
                "source",
                {}
            )


            print(
                "[{}] Audio source".format(
                    "OK"
                    if source.get("file")
                    else "MISSING"
                )
            )


            setlist = data.get(
                "setlist",
                {}
            )


            print(
                "[{}] Setlist".format(
                    "OK"
                    if setlist.get("file")
                    else "MISSING"
                )
            )


            print(
                "Tracks planned :",
                setlist.get(
                    "track_count",
                    0
                )
            )


            print()

            tracks = project.paths.get(
                "tracks"
            )


            count = 0


            if (
                tracks
                and os.path.exists(tracks)
            ):

                count = len(
                    [
                        f
                        for f in os.listdir(tracks)
                        if f.lower().endswith(".mp3")
                    ]
                )


            print(
                "Output tracks :",
                count
            )

            print()

            playlist = os.path.join(
                project.paths["playlist"],
                "playlist.m3u"
            )


            print(
                "[{}] Playlist".format(
                    "OK"
                    if os.path.exists(playlist)
                    else "MISSING"
                )
            )


            pause()



        elif choice == "4":

            try:

                playlist = Playlist(
                    project.path
                )


                playlist.run()


            except Exception as error:

                print()

                print(
                    f"[ERROR] {error}"
                )


            pause()



        else:

            print(
                "[ERROR] Invalid choice"
            )

            pause()
