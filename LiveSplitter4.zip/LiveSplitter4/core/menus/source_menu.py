#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.2

Source Manager Menu

Gestion des sources audio du projet actif.
"""

from core.source import SourceManager
from core.youtube import YoutubeImporter
from core.audio_info import get_audio_info
from core.utils import log



def header(title):

    print()
    print("=" * 50)
    print(f"=== {title} ===")
    print("=" * 50)
    print()



def pause():

    input("\nENTER to continue...")



def format_duration(seconds):

    seconds = int(seconds)

    hours = seconds // 3600

    minutes = (
        seconds % 3600
    ) // 60

    secs = seconds % 60


    return (
        f"{hours:02d}:"
        f"{minutes:02d}:"
        f"{secs:02d}"
    )



def source_information(project):

    header(
        "SOURCE INFORMATION"
    )


    manager = SourceManager(
        project
    )


    source = manager.get_source()


    if not source:

        print(
            "[INFO] No source imported"
        )

        pause()

        return



    info = source.get(
        "info",
        {}
    )


    print(
        f"File Name   : {info.get('filename','')}"
    )


    print(
        f"Duration    : {format_duration(info.get('duration',0))}"
    )


    print(
        f"Codec       : {info.get('codec','')}"
    )


    print(
        f"Bitrate     : {info.get('bitrate','')} kbps"
    )


    print(
        f"Sample Rate : {info.get('sample_rate','')} Hz"
    )


    print(
        f"Channels    : {info.get('channels',0)}"
    )


    print()


    print(
        "Project Source:"
    )


    print(
        source.get(
            "file",
            ""
        )
    )


    pause()



def select_local_source(project):

    header(
        "SELECT LOCAL SOURCE"
    )


    manager = SourceManager(
        project
    )


    files = manager.list_import_sources()


    if not files:

        print(
            "[INFO] No audio files in Import/Source"
        )

        pause()

        return



    for index, file in enumerate(
        files,
        start=1
    ):

        print(
            f"{index}) {file.split('/')[-1]}"
        )


    print(
        "0) Back"
    )


    choice = input(
        "Choice : "
    ).strip()



    if choice == "0":

        return



    try:

        index = int(choice) - 1

        selected = files[index]


    except Exception:

        print(
            "[ERROR] Invalid choice"
        )

        pause()

        return



    try:

        info = manager.import_source(
            selected
        )


        print()

        print(
            "[OK] Source imported"
        )


        print(
            f"Duration : {format_duration(info.get('duration',0))}"
        )


        print(
            f"Bitrate  : {info.get('bitrate','')} kbps"
        )


    except Exception as e:

        print()

        print(
            f"[ERROR] {e}"
        )


    pause()



def add_source_menu(project):

    while True:

        header(
            "ADD SOURCE"
        )


        print(
            "1) Local File"
        )

        print(
            "2) YouTube"
        )

        print(
            "0) Back"
        )


        choice = input(
            "Choice : "
        ).strip()



        if choice == "0":

            return



        elif choice == "1":

            select_local_source(
                project
            )



        elif choice == "2":

            header(
                "YOUTUBE"
            )


            url = input(
                "YouTube URL : "
            ).strip()


            if not url:

                print(
                    "[ERROR] Empty URL"
                )

                pause()

                continue


            try:

                importer = YoutubeImporter(
                    project
                )


                result = importer.download(
                    url
                )


                info = get_audio_info(
                    result["file"]
                )

                project.data["source"] = {
                    "status": True,
                    "type": "youtube",
                    "file": result["file"],
                    "info": info
                }

                project.save()


                log(
                    "SOURCE IMPORTED : youtube",
                    project
                )


                print()

                print(
                    "[OK] YouTube source imported"
                )

                print(
                    f"Duration : {format_duration(info.get('duration',0))}"
                )

                print(
                    f"Bitrate  : {info.get('bitrate','')} kbps"
                )


            except Exception as e:

                log(
                    f"YOUTUBE IMPORT FAILED : {e}",
                    project
                )

                print(
                    f"[ERROR] {e}"
                )


            pause()



def source_menu(project):


    if project is None:

        print(
            "[WARN] No active project"
        )

        pause()

        return



    while True:


        header(
            "SOURCE MANAGER"
        )


        print(
            "1) Add Source"
        )


        print(
            "2) Source Information"
        )


        print(
            "0) Back"
        )


        choice = input(
            "Choice : "
        ).strip()



        if choice == "0":

            return



        elif choice == "1":

            add_source_menu(
                project
            )



        elif choice == "2":

            source_information(
                project
            )
