#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.2

Metadata Manager Menu

Gestion des informations concert
et artwork du projet actif.
"""

import os

from PIL import Image

from core.metadata import MetadataManager
from core.project import IMPORT_ROOT



def header(title):

    print()
    print("=" * 50)
    print(f"=== {title} ===")
    print("=" * 50)



def pause():

    input("\nENTER...")



def concert_information(project):

    header(
        "CONCERT INFORMATION"
    )


    manager = MetadataManager(
        project
    )


    current = manager.get_metadata()


    artist = input(
        f"Artist [{current.get('artist','')}]: "
    ).strip()


    album = input(
        f"Event / Album [{current.get('album','')}]: "
    ).strip()


    date = input(
        f"Date [{current.get('date','')}]: "
    ).strip()


    venue = input(
        f"Venue [{current.get('venue','')}]: "
    ).strip()


    genre = input(
        f"Genre [{current.get('genre','')}]: "
    ).strip()



    manager.update(

        artist=artist or current.get("artist",""),

        album=album or current.get("album",""),

        date=date or current.get("date",""),

        venue=venue or current.get("venue",""),

        genre=genre or current.get("genre","")
    )


    print()

    print(
        "[OK] Metadata updated"
    )


    pause()



def list_artwork():

    folder = os.path.join(
        IMPORT_ROOT,
        "Artwork"
    )


    os.makedirs(
        folder,
        exist_ok=True
    )


    files = []


    for name in sorted(
        os.listdir(folder)
    ):

        path = os.path.join(
            folder,
            name
        )


        if os.path.isfile(path):

            if name.lower().endswith(
                (
                    ".jpg",
                    ".jpeg",
                    ".png"
                )
            ):

                files.append(path)


    return files



def import_artwork(project):

    header(
        "IMPORT ARTWORK"
    )


    manager = MetadataManager(
        project
    )


    files = list_artwork()


    if not files:

        print(
            "[INFO] No artwork found in Import/Artwork"
        )

        pause()

        return



    for i, file in enumerate(
        files,
        start=1
    ):

        print(
            f"{i}) {os.path.basename(file)}"
        )


    print(
        "0) Back"
    )


    choice = input(
        "Choice : "
    ).strip()


    if choice == "0":

        return



    try:

        selected = files[
            int(choice)-1
        ]


        destination = manager.add_artwork(
            selected
        )


        print()

        print(
            "[OK] Artwork imported"
        )

        print(
            destination
        )


    except Exception as e:

        print(
            f"[ERROR] {e}"
        )


    pause()



def artwork_information(project):

    header(
        "ARTWORK INFORMATION"
    )


    manager = MetadataManager(
        project
    )


    metadata = manager.get_metadata()


    artwork = metadata.get(
        "artwork",
        ""
    )


    if not artwork:

        print(
            "[INFO] No artwork available"
        )

        pause()

        return



    filename = os.path.basename(
        artwork
    )


    print(
        f"File    : {filename}"
    )


    try:

        with Image.open(
            artwork
        ) as img:

            width, height = img.size

            fmt = img.format



            print(
                f"Format  : {fmt}"
            )

            print(
                f"Size    : {width}x{height}"
            )


    except Exception:

        print(
            "Format  : Unknown"
        )


    print(
        f"Path    : {artwork}"
    )


    print()

    print(
        "[Artwork available]"
    )


    pause()



def artwork_menu(project):

    while True:

        header(
            "ARTWORK"
        )


        print(
            "1) Import Artwork"
        )

        print(
            "2) Artwork Information"
        )

        print(
            "0) Back"
        )


        choice = input(
            "Choice : "
        ).strip()


        if choice == "0":

            return


        elif choice == "1":

            import_artwork(
                project
            )


        elif choice == "2":

            artwork_information(
                project
            )



def metadata_menu(project):

    if project is None:

        print(
            "[WARN] No active project"
        )

        pause()

        return



    while True:

        header(
            "METADATA MANAGER"
        )


        print(
            "1) Concert Information"
        )

        print(
            "2) Artwork"
        )

        print(
            "0) Back"
        )


        choice = input(
            "Choice : "
        ).strip()


        if choice == "0":

            return


        elif choice == "1":

            concert_information(
                project
            )


        elif choice == "2":

            artwork_menu(
                project
            )
