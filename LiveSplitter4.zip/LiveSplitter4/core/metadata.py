#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Metadata Manager

Gestion des informations du concert.
"""

import os
import shutil

from core.utils import log


class MetadataManager:

    def __init__(self, project):
        self.project = project


    def update(
        self,
        artist="",
        album="",
        date="",
        venue="",
        genre=""
    ):

        existed = bool(
            self.project.data.get("metadata", {}).get("status")
        )

        self.project.data["metadata"] = {
            "status": True,
            "artist": artist,
            "album": album,
            "date": date,
            "venue": venue,
            "genre": genre,
            "artwork": ""
        }

        self.project.save()

        if existed:
            log(
                f"METADATA UPDATED : Artist={artist} | Album={album}",
                self.project
            )
        else:
            log(
                f"METADATA ADDED : Artist={artist} | Album={album}",
                self.project
            )


    def add_artwork(
        self,
        artwork_file
    ):

        existed = bool(
            self.project.data.get("metadata", {}).get("artwork")
        )

        if not os.path.exists(artwork_file):
            raise FileNotFoundError(
                artwork_file
            )


        # Création du dossier Artwork du projet si nécessaire
        os.makedirs(
            self.project.paths["artwork"],
            exist_ok=True
        )


        destination = os.path.join(
            self.project.paths["artwork"],
            os.path.basename(artwork_file)
        )


        shutil.copy2(
            artwork_file,
            destination
        )


        self.project.data["metadata"]["artwork"] = (
            destination
        )

        self.project.save()


        if existed:
            log(
                f"ARTWORK UPDATED : {os.path.basename(destination)}",
                self.project
            )
        else:
            log(
                f"ARTWORK ADDED : {os.path.basename(destination)}",
                self.project
            )


        return destination


    def get_metadata(self):

        return (
            self.project.data
            .get(
                "metadata",
                {}
            )
        )
