#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.7
Splitter

Rôle :
- Charger auto_mapping.json
- Nettoyer Output/Tracks avant génération
- Découper le concert source avec FFmpeg
- Générer les pistes MP3

Compatible Termux / Android
"""

import os
import sys
import subprocess

from core.utils import (
    get_project_paths,
    load_json,
    clean_output,
    clean_filename,
    log
)


VERSION = "4.7"


class Splitter:


    def __init__(self, project_dir):

        self.project_dir = project_dir

        self.paths = get_project_paths(
            project_dir
        )

        self.source_file = None
        self.tracks = []
        self.generated_tracks = []
        self.setlist = None



    def load_source(self):

        project_file = self.paths["project_json"]

        if os.path.exists(project_file):

            project = load_json(
                project_file
            )

            self.source_file = project.get(
                "source",
                {}
            ).get(
                "file"
            )


        if self.source_file:

            return


        source_dir = self.paths["source"]


        for file in os.listdir(source_dir):

            if file.lower().endswith(
                ".mp3"
            ):

                self.source_file = os.path.join(
                    source_dir,
                    file
                )

                return



    def load_mapping(self):

        normalized_file = os.path.join(
            self.project_dir,
            "Analysis",
            "Results",
            "normalized_setlist.json"
        )

        if os.path.exists(normalized_file):

            log(
                "NORMALIZED SETLIST LOADED FOR SPLIT",
                self
            )

            data = load_json(
                normalized_file
            )

            self.tracks = data.get(
                "tracks",
                []
            )

            return


        print(
            f"[LOAD] {self.paths['mapping']}"
        )

        data = load_json(
            self.paths["mapping"]
        )

        self.tracks = data.get(
            "tracks",
            []
        )



    def cut_track(self, track):

        number = track.get(
            "number",
            0
        )

        title = clean_filename(
            track.get(
                "title",
                f"Track {number:02d}"
            )
        )


        start = track.get(
            "start",
            0
        )

        end = track.get(
            "end",
            0
        )


        filename = (
            f"{number:02d} - {title}.mp3"
        )


        output = os.path.join(
            self.paths["tracks"],
            filename
        )


        print(
            f"[CUT] {filename} {start}s -> {end}s"
        )


        command = [

            "ffmpeg",

            "-y",

            "-i",
            self.source_file,

            "-ss",
            str(start),

            "-to",
            str(end),

            "-c",
            "copy",

            output
        ]


        subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL
        )


        self.generated_tracks.append(output)

        return output



    def run(self, setlist=None):

        print()
        print(
            f"=== LiveSplitter Splitter V{VERSION} ==="
        )

        log(
            "SPLIT START",
            self.project_dir
        )
        print()


        self.load_source()


        if not self.source_file:

            raise FileNotFoundError(
                "Aucun fichier source trouvé"
            )


        if not os.path.exists(
            self.source_file
        ):

            raise FileNotFoundError(
                self.source_file
            )


        removed = clean_output(
            self.project_dir
        )


        print(
            f"[CLEAN] Tracks supprimés : {removed['tracks']}"
        )

        print(
            f"[CLEAN] Playlist supprimée : {removed['playlist']}"
        )


        if setlist is not None:
            print("[LOAD] NormalizedSetlist")
            self.tracks = [
                vars(track)
                for track in setlist.tracks
            ]
        else:
            self.load_mapping()


        os.makedirs(
            self.paths["tracks"],
            exist_ok=True
        )


        count = 0


        for track in self.tracks:

            self.cut_track(
                track
            )

            count += 1



        print()

        self.project_data_save()

        log(
            f"SPLIT COMPLETE : {count} tracks",
            self.project_dir
        )

        print(
            f"[OK] {count} tracks generated"
        )


        #
        # TAGS + ARTWORK
        #

        try:

            print()

            print("[TAGS] Applying metadata...")

            from core.project import Project
            from core.tags import TagManager

            project = Project(
                self.project_dir
            )

            project.load()

            log(
                "TAGGING START",
                project
            )

            TagManager(
                project
            ).tag_tracks()

            log(
                f"TAGGING COMPLETE : {count} tracks",
                project
            )

            print("[OK] Tags applied")


        except Exception as e:

            print("[WARN] Tagging failed:", e)




    def project_data_save(self):

        project_file = self.paths["project_json"]

        if not os.path.exists(project_file):
            return

        data = load_json(
            project_file
        )

        data.setdefault(
            "output",
            {}
        )

        data["output"]["split"] = True
        data["output"]["tracks"] = self.generated_tracks

        from core.utils import save_json

        save_json(
            project_file,
            data
        )


def main():

    if len(sys.argv) < 2:

        print(
            "Usage : python splitter.py projects/Project"
        )

        sys.exit(1)


    splitter = Splitter(
        sys.argv[1]
    )

    splitter.run()



if __name__ == "__main__":

    main()
