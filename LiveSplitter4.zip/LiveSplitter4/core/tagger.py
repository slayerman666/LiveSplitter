#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.8
Tagger

Rôle :
- Charger project.json
- Charger auto_mapping.json
- Vérifier les pistes générées
- Injecter tags ID3
- Ajouter artwork

Compatible Termux / Android
"""

import os
import sys

from mutagen.mp3 import MP3
from mutagen.id3 import (
    ID3,
    TIT2,
    TPE1,
    TALB,
    TDRC,
    TCON,
    COMM,
    TXXX,
    APIC
)

from core.utils import (
    get_project_paths,
    load_json
)


VERSION = "4.8"



class Tagger:


    def __init__(self, project_dir):

        self.project_dir = project_dir

        self.paths = get_project_paths(
            project_dir
        )

        self.project = {}
        self.mapping = []



    def load_files(self):

        print(
            "[LOAD] project.json"
        )

        self.project = load_json(
            self.paths["project_json"]
        )


        print(
            "[LOAD] auto_mapping.json"
        )

        data = load_json(
            self.paths["mapping"]
        )

        self.mapping = data.get(
            "tracks",
            []
        )



    def find_track_file(self, number):

        prefix = f"{number:02d} - "

        matches = []


        if not os.path.exists(
            self.paths["tracks"]
        ):

            return None


        for filename in os.listdir(
            self.paths["tracks"]
        ):

            if (
                filename.startswith(prefix)
                and filename.lower().endswith(".mp3")
            ):

                matches.append(filename)


        if len(matches) == 0:

            print(
                f"[WARN] Piste {number:02d} absente"
            )

            return None


        if len(matches) > 1:

            print(
                f"[WARN] Plusieurs fichiers piste {number:02d}"
            )


        return os.path.join(
            self.paths["tracks"],
            sorted(matches)[0]
        )



    def add_artwork(self, tags):

        artwork_dir = self.paths["artwork"]

        cover = None


        if os.path.exists(
            artwork_dir
        ):

            for file in os.listdir(
                artwork_dir
            ):

                if file.lower().endswith(
                    (".jpg", ".jpeg")
                ):

                    cover = os.path.join(
                        artwork_dir,
                        file
                    )

                    break


        if not cover:

            return False


        with open(
            cover,
            "rb"
        ) as image:

            tags.delall(
                "APIC:"
            )

            tags.add(
                APIC(
                    encoding=3,
                    mime="image/jpeg",
                    type=3,
                    desc="Cover",
                    data=image.read()
                )
            )


        return True



    def tag_file(self, filename, track):

        audio = MP3(
            filename,
            ID3=ID3
        )


        if audio.tags is None:

            audio.add_tags()


        metadata = self.project.get(
            "metadata",
            {}
        )


        title = track.get(
            "title",
            "Unknown"
        )


        audio.tags.delall("TIT2")
        audio.tags.add(
            TIT2(
                encoding=3,
                text=title
            )
        )


        audio.tags.delall("TPE1")
        audio.tags.add(
            TPE1(
                encoding=3,
                text=metadata.get(
                    "artist",
                    ""
                )
            )
        )


        audio.tags.delall("TALB")
        audio.tags.add(
            TALB(
                encoding=3,
                text=metadata.get(
                    "album",
                    ""
                )
            )
        )


        audio.tags.delall("TDRC")
        audio.tags.add(
            TDRC(
                encoding=3,
                text=str(
                    metadata.get(
                        "date",
                        ""
                    )
                )
            )
        )


        audio.tags.delall("TCON")
        audio.tags.add(
            TCON(
                encoding=3,
                text=metadata.get(
                    "genre",
                    "Metal"
                )
            )
        )


        audio.tags.delall(
            "COMM::fra:Comment"
        )

        audio.tags.add(
            COMM(
                encoding=3,
                lang="fra",
                desc="Comment",
                text="Live Concert Bootleg"
            )
        )


        audio.tags.delall(
            "TXXX:Venue"
        )

        audio.tags.add(
            TXXX(
                encoding=3,
                desc="Venue",
                text=metadata.get(
                    "venue",
                    ""
                )
            )
        )


        self.add_artwork(
            audio.tags
        )


        audio.save()



    def run(self):

        print()
        print(
            f"=== LiveSplitter Tagger V{VERSION} ==="
        )
        print()


        self.load_files()


        expected = len(
            self.mapping
        )


        generated = len(
            [
                f for f in os.listdir(
                    self.paths["tracks"]
                )
                if f.lower().endswith(".mp3")
            ]
        )


        if expected != generated:

            print(
                f"[WARN] Mapping {expected} pistes / fichiers {generated}"
            )


        count = 0


        for track in self.mapping:

            number = track.get(
                "number"
            )


            filename = self.find_track_file(
                number
            )


            if not filename:

                continue


            print(
                f"[TAG] {os.path.basename(filename)}"
            )


            self.tag_file(
                filename,
                track
            )


            count += 1



        print()


        if os.path.exists(
            self.paths["artwork"]
        ):

            print(
                "[ARTWORK] cover embedded"
            )


        print()

        print(
            f"[OK] {count} tracks tagged"
        )



def main():

    if len(sys.argv) < 2:

        print(
            "Usage : python tagger.py projects/Project"
        )

        sys.exit(1)


    tagger = Tagger(
        sys.argv[1]
    )


    tagger.run()



if __name__ == "__main__":

    main()
