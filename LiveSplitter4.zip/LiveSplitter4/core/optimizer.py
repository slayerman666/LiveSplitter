#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter V4.5
Optimizer

Fusion intelligente des transitions.

Entrée :
    projects/<Projet>/Analysis/Results/*_fusion.json

Sortie :
    projects/<Projet>/Analysis/Results/*_fusion_transitions.json

Fonctions :
- regroupement des marqueurs proches
- suppression des faux positifs
- protection des solos
- conservation des fins via silence
"""


import os
import sys
import json


VERSION = "4.5"


# réglages
MERGE_WINDOW = 30
MINIMUM_GAP = 300

IGNORE_BEFORE = 45

MIN_ONSET_SCORE = 85


def load_fusion(project):

    results = os.path.join(
        project,
        "Analysis",
        "Results"
    )

    if not os.path.exists(results):
        raise FileNotFoundError(
            results
        )

    for file in os.listdir(results):

        if file.endswith(
            "_fusion.json"
        ):

            path = os.path.join(
                results,
                file
            )

            with open(
                path,
                encoding="utf-8"
            ) as f:

                return json.load(f), results, file

    raise FileNotFoundError(
        "Aucun fichier *_fusion.json trouvé"
    )



def merge_markers(data):

    raw = data.get(
        "markers",
        []
    )


    points = []


    for m in raw:

        points.append(
            {
                "time": m.get(
                    "time",
                    0
                ),

                "score": m.get(
                    "score",
                    0
                ),

                "sources": m.get(
                    "sources",
                    [
                        m.get(
                            "detector",
                            "unknown"
                        )
                    ]
                )
            }
        )


    points.sort(
        key=lambda x:x["time"]
    )


    clusters = []


    current = []


    for p in points:

        if not current:

            current.append(p)

            continue


        if (
            p["time"]
            -
            current[-1]["time"]
            <= MERGE_WINDOW
        ):

            current.append(p)

        else:

            clusters.append(
                current
            )

            current = [
                p
            ]


    if current:
        clusters.append(
            current
        )


    return clusters



def optimize_clusters(clusters):

    transitions = []


    for cluster in clusters:

        times = []

        sources = []

        score = 0


        for item in cluster:

            times.append(
                item["time"]
            )

            score += item["score"]


            for s in item["sources"]:

                if s not in sources:
                    sources.append(s)


        position = int(
            sum(times)
            /
            len(times)
        )


        avg_score = int(
            score
            /
            len(cluster)
        )


        if position < IGNORE_BEFORE:

            continue


        #
        # filtre faux onset
        #

        if (
            sources == ["onset"]
            and
            avg_score < MIN_ONSET_SCORE
        ):

            continue



        #
        # silence = fin de morceau
        #

        if "silence" in sources:

            grade = "A"

            reason = "song_end_silence"

            avg_score = max(
                avg_score,
                90
            )


        #
        # confirmations multiples
        #

        elif len(sources) >= 2:

            grade = "A"

            reason = "multi_detector"

            avg_score += 10


        elif "onset" in sources:

            grade = "B"

            reason = "strong_onset"


        else:

            grade = "C"

            reason = "weak_transition"



        avg_score = max(
            0,
            min(
                100,
                avg_score
            )
        )


        transitions.append(
            {
                "time": position,

                "score": avg_score,

                "confidence": avg_score,

                "grade": grade,

                "reason": reason,

                "sources": sources
            }
        )


    return transitions



def remove_close(transitions):

    if not transitions:
        return []


    transitions.sort(
        key=lambda x:x["time"]
    )


    output = []


    for t in transitions:


        if not output:

            output.append(t)

            continue


        previous = output[-1]


        gap = (
            t["time"]
            -
            previous["time"]
        )


        if gap < MINIMUM_GAP:


            # garder le meilleur

            if (
                t["score"]
                >
                previous["score"]
            ):

                output[-1] = t


        else:

            output.append(t)


    return output



def save(project, source, transitions):

    output = os.path.join(
        project,
        "Analysis",
        "Results",
        source.replace(
            "_fusion.json",
            "_fusion_transitions.json"
        )
    )


    result = {

        "version": VERSION,

        "count": len(
            transitions
        ),

        "transitions": []

    }


    for i,t in enumerate(
        transitions,
        1
    ):

        t["id"] = i

        result["transitions"].append(
            t
        )


    with open(
        output,
        "w",
        encoding="utf-8"
    ) as f:

        json.dump(
            result,
            f,
            indent=4,
            ensure_ascii=False
        )


    print(
        "[OK]",
        output
    )



def optimize_project(project):

    data, results, filename = load_fusion(
        project
    )


    clusters = merge_markers(
        data
    )


    transitions = optimize_clusters(
        clusters
    )


    transitions = remove_close(
        transitions
    )


    save(
        project,
        filename,
        transitions
    )



if __name__ == "__main__":


    if len(sys.argv) < 2:

        print(
            "Usage : python optimizer.py projects/<Projet>"
        )

        sys.exit(1)


    optimize_project(
        sys.argv[1]
    )
