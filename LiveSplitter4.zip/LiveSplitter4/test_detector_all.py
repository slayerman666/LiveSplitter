# -*- coding: utf-8 -*-

"""
LiveSplitter V4

Test multi détecteurs
"""

from core.project import Project
from core.detector_manager import DetectorManager



project = Project(
    "projects/Test_Project"
)

project.load()


manager = DetectorManager(
    project
)


audio = (
    project.data
    ["source"]
    ["file"]
)


print("Available detectors:")

print(
    manager.available()
)



print("\nRunning all detectors...\n")


markers = manager.run_all(
    audio
)



print("Markers:")


for marker in markers:

    print(marker)



print(
    "\nTotal markers:",
    len(markers)
)
