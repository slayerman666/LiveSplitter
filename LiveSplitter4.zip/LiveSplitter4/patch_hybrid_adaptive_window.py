#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

FILE = Path("core/generators/hybrid.py")

text = FILE.read_text(encoding="utf-8")

old = """            search_window = max(
                self.window,
                180
            )
"""

new = """            drift = abs(
                last_detected - expected
            )

            search_window = max(
                self.window,
                180,
                drift + 120
            )
"""

if old not in text:
    print("[ERROR] search_window block not found")
    raise SystemExit(1)

text = text.replace(old, new, 1)

backup = FILE.with_suffix(FILE.suffix + ".adaptive_window.bak")
backup.write_text(FILE.read_text(encoding="utf-8"), encoding="utf-8")

FILE.write_text(text, encoding="utf-8")

print("[OK] hybrid.py patched")
print(f"[OK] Backup: {backup}")
