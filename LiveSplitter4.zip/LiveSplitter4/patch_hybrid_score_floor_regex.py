#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import re

FILE = Path("core/generators/hybrid.py")

text = FILE.read_text(encoding="utf-8")

pattern = r"""
elif\s+delta\s*<=\s*600:
\s*distance_score\s*=\s*int\(
\s*100\s*-\s*\(\(delta\s*-\s*60\)\s*\*\s*0\.12\)
\s*\)
else:
\s*distance_score\s*=\s*20
"""

replacement = """elif delta <= 600:
            distance_score = max(
                60,
                int(
                    100 - ((delta - 60) * 0.12)
                )
            )
        else:
            distance_score = 60"""

new_text, count = re.subn(
    pattern,
    replacement,
    text,
    count=1,
    flags=re.VERBOSE
)

if count == 0:
    print("[ERROR] score block not found")
    raise SystemExit(1)

backup = FILE.with_suffix(".score_floor_regex.bak")
backup.write_text(text, encoding="utf-8")

FILE.write_text(new_text, encoding="utf-8")

print("[OK] score floor patched")
print(f"[OK] Backup: {backup}")
