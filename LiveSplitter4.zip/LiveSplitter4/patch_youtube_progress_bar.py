#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

p = Path("core/youtube.py")

txt = p.read_text(
    encoding="utf-8"
)


start = txt.find(
    "    def hook(self, data):",
    txt.find("class YoutubeProgress")
)

end = txt.find(
    "\n\n\nclass YoutubeImporter",
    start
)


if start == -1 or end == -1:
    print("[ERROR] YoutubeProgress.hook not found")
    exit(1)


new_hook = '''    def hook(self, data):

        if data.get("status") != "downloading":
            return


        total = (
            data.get("total_bytes")
            or data.get("total_bytes_estimate")
        )


        downloaded = data.get(
            "downloaded_bytes",
            0
        )


        if not total:
            return


        percent = int(
            downloaded * 100 / total
        )


        if percent == self.last_percent:
            return


        self.last_percent = percent


        bar_length = 30


        filled = int(
            bar_length * percent / 100
        )


        bar = (
            "█" * filled
            +
            "░" * (
                bar_length - filled
            )
        )


        speed = data.get(
            "_speed_str",
            "--"
        )


        eta = data.get(
            "_eta_str",
            "--"
        )


        print(
            f"\\r[{bar}] {percent:3d}%  {speed}  ETA {eta}",
            end="",
            flush=True
        )


        if percent >= 100:
            print()
'''


txt = (
    txt[:start]
    +
    new_hook
    +
    txt[end:]
)


p.write_text(
    txt,
    encoding="utf-8"
)


print("[OK] Dynamic YouTube progress bar patched")
