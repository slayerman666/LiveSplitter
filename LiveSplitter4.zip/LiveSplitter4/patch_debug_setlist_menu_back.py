#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import re

file = Path("core/menus/setlist_menu.py")

text = file.read_text(encoding="utf-8")

pattern = r'(def create_generate_menu\(project\):.*?if choice == "0":\s*)return'

replacement = (
    r'\1'
    'print("[DEBUG] Leaving create_generate_menu")\n'
    '                                                             pause()\n'
    '                                                             return'
)

new_text, count = re.subn(
    pattern,
    replacement,
    text,
    flags=re.S
)

if count == 0:
    raise SystemExit("[ERROR] Bloc create_generate_menu choice 0 introuvable")

file.write_text(new_text, encoding="utf-8")

print(f"[OK] Patch applied ({count})")
