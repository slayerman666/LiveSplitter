#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil


FILE = Path("core/youtube.py")


backup = FILE.with_suffix(".py.bak_format_auto")
shutil.copy2(FILE, backup)

print("[OK] Backup :", backup)


text = FILE.read_text(
    encoding="utf-8"
)


# Remettre un format compatible
text = text.replace(
    '"140/bestaudio/best"',
    '"bestaudio[ext=m4a]/bestaudio/best"'
)


# Ajouter android en secours
text = text.replace(
    '''"player_client":
                    [
                        "web"
                    ]''',
    '''"player_client":
                    [
                        "web",
                        "android"
                    ]'''
)


FILE.write_text(
    text,
    encoding="utf-8"
)

print("[OK] Format YouTube corrigé")
print("[OK] Client web+android activé")
