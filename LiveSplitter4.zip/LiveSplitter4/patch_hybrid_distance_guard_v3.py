#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

file = Path("core/generators/hybrid.py")

lines = file.read_text(encoding="utf-8").splitlines()

backup = Path("core/generators/hybrid.py.distance_guard_v3.bak")
backup.write_text("\n".join(lines) + "\n", encoding="utf-8")

insert_after = 355  # ligne affichée par nl -ba (index humain)

patch = [
"                # Protection contre les faux matchs trop éloignés",
"                max_drift = 900",
"",
"                if abs(best.time - expected) > max_drift:",
"                    best = None",
"                    best_score = -1",
]

# éviter double patch
if any("max_drift = 900" in l for l in lines):
    print("[ERROR] patch already present")
    exit(1)

lines[insert_after:insert_after] = patch

file.write_text("\n".join(lines) + "\n", encoding="utf-8")

print("[OK] distance guard inserted")
print("[OK] backup:", backup)
