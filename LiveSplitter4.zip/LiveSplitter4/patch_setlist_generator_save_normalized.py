#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os


FILE = "core/setlist_generator.py"


def patch():

    if not os.path.exists(FILE):
        raise FileNotFoundError(FILE)

    with open(FILE, "r", encoding="utf-8") as f:
        lines = f.readlines()


    if any(
        "save_normalized_setlist" in line
        for line in lines
    ):
        print("[INFO] Patch déjà appliqué")
        return


    start = None
    end = None


    for i, line in enumerate(lines):

        if line.strip().startswith(
            "def finalize_setlist"
        ):
            start = i

        if start is not None and i > start:
            if line.strip() == "return normalized":
                end = i
                break


    if start is None or end is None:
        raise Exception(
            "Bloc finalize_setlist introuvable - aucun changement effectué"
        )


    indent = lines[end][:len(lines[end]) -
                       len(lines[end].lstrip())]


    insert = [
        "\n",
        indent + "self.project.save_normalized_setlist(\n",
        indent + "    normalized.to_dict()\n",
        indent + ")\n",
        "\n"
    ]


    lines[end:end] = insert


    with open(FILE, "w", encoding="utf-8") as f:
        f.writelines(lines)


    print(
        "[OK] setlist_generator.py patché"
    )


if __name__ == "__main__":
    patch()
