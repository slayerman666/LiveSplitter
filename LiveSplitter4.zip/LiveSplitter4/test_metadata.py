# -*- coding: utf-8 -*-

"""
Test Metadata Manager
"""

from core.project import Project
from core.metadata import MetadataManager


project = Project(
    "projects/Test_Project"
)


project.load()


metadata = MetadataManager(
    project
)


metadata.update(
    artist="Machine Head",
    album="Hellfest 2024",
    date="2024",
    venue="Hellfest",
    genre="Metal"
)


print("\nMetadata:")
print(
    metadata.get_metadata()
)


print("\nProject recap:")
print(
    project.recap()
)
