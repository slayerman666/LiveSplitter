#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil


FILE = Path("core/youtube.py")


if not FILE.exists():
    print("[ERROR] core/youtube.py introuvable")
    exit(1)


backup = FILE.with_suffix(".py.bak")

shutil.copy2(
    FILE,
    backup
)

print("[OK] Backup :", backup)


text = FILE.read_text(
    encoding="utf-8"
)


changed = False


# Format audio
old = '"bestaudio/best"'
new = '"140/bestaudio/best"'

if old in text:
    text = text.replace(
        old,
        new
    )
    changed = True
    print("[OK] Format audio corrigé")
else:
    print("[WARN] Format audio déjà corrigé ou introuvable")


# Qualité MP3
old = '"preferredquality":\n                                        "0"'

new = '"preferredquality":\n                                        "320"'

if old in text:
    text = text.replace(
        old,
        new
    )
    changed = True
    print("[OK] Qualité MP3 320 kbps")
else:
    print("[WARN] preferredquality 0 introuvable")


# Ajout noplaylist
if '"noplaylist"' not in text:

    marker = '''"noprogress":
                True,
'''

    if marker in text:

        text = text.replace(
            marker,
            marker +
            '''

            "noplaylist":
                True,
''',
            1
        )

        changed = True
        print("[OK] noplaylist ajouté")

    else:
        print("[WARN] Bloc noprogress introuvable")


if changed:

    FILE.write_text(
        text,
        encoding="utf-8"
    )

    print("[OK] Patch appliqué")

else:

    print("[WARN] Aucun changement")
