from pathlib import Path

p = Path("core/menus/source_menu.py")

txt = p.read_text(
    encoding="utf-8"
)


old = '''                info = manager.import_source(
                    metadata["file"]
                )
'''


new = '''                info = {
                    "file": metadata["file"],
                    "duration": 0,
                    "bitrate": ""
                }
'''


if old not in txt:
    print("[WARN] YouTube import_source block not found")

else:
    txt = txt.replace(
        old,
        new,
        1
    )

    p.write_text(
        txt,
        encoding="utf-8"
    )

    print("[OK] YouTube double import removed")
