#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil

target = Path("core/generators/hybrid.py")

if not target.exists():
    print("[ERROR] hybrid.py not found")
    exit(1)

lines = target.read_text(encoding="utf-8").splitlines()

backup = Path("core/generators/hybrid.fallback_flow_v3.bak")
shutil.copy2(target, backup)

start = None
end = None

for i, line in enumerate(lines):
    if "if (" in line and "best is not None" in "".join(lines[i:i+3]):
        start = i
        break

if start is None:
    print("[ERROR] fallback condition not found")
    exit(1)

for i in range(start, min(start + 10, len(lines))):
    if "detected = best.time" in lines[i]:
        end = i + 1
        break

if end is None:
    print("[ERROR] detected assignment not found")
    exit(1)

replacement = [
"            if best is not None:",
"",
"                strong_transition = (",
"                    best.score >= 90",
"                    and best.time > last_detected",
"                )",
"",
"                if best_score >= self.match_threshold or strong_transition:",
"                    detected = best.time"
]

new_lines = lines[:start] + replacement + lines[end:]

target.write_text(
    "\n".join(new_lines) + "\n",
    encoding="utf-8"
)

print("[OK] patched")
print("[OK] backup:", backup)
