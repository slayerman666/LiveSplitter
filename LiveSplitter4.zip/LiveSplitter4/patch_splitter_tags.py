from pathlib import Path

p = Path("core/splitter.py")

txt = p.read_text(encoding="utf-8")


old = '''        self.project_data_save()

        print(
            f"[OK] {count} tracks generated"
        )
'''


new = '''        self.project_data_save()

        print(
            f"[OK] {count} tracks generated"
        )


        #
        # TAGS + ARTWORK
        #

        try:

            print()

            print("[TAGS] Applying metadata...")

            from core.project import Project
            from core.tags import TagManager

            project = Project(
                self.project_dir
            )

            project.load()

            TagManager(
                project
            ).tag_tracks()

            print("[OK] Tags applied")


        except Exception as e:

            print("[WARN] Tagging failed:", e)
'''


if old not in txt:
    print("Bloc splitter introuvable.")
    raise SystemExit(1)


txt = txt.replace(old, new, 1)

p.write_text(
    txt,
    encoding="utf-8"
)

print("Patch splitter tags appliqué.")
