#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil

target = Path("core/builders/hybrid_builder.py")
backup = Path("core/builders/hybrid_builder.cleanup_v1.bak")

shutil.copy2(target, backup)

text = target.read_text(encoding="utf-8")

start = text.index("        # Absorption FALLBACK intermédiaires")
end = text.index("# Normalisation robuste des timelines")

replacement = """        # Absorption des groupes FALLBACK intermédiaires
        cleaned = []

        i = 0

        while i < len(result.tracks):

            track = result.tracks[i]

            if track.metadata.get("status") == "FALLBACK":

                j = i

                while (
                    j < len(result.tracks)
                    and result.tracks[j].metadata.get("status") == "FALLBACK"
                ):
                    j += 1

                if (
                    j < len(result.tracks)
                    and result.tracks[j].metadata.get("status") == "MATCHED"
                ):
                    i = j
                    continue

            cleaned.append(track)
            i += 1

        result.tracks = cleaned


        # Reconstruction timeline après suppression

        for idx, track in enumerate(result.tracks):

            track.number = idx + 1

            if idx < len(result.tracks) - 1:
                track.end = result.tracks[idx + 1].start


"""

text = text[:start] + replacement + text[end:]

target.write_text(text, encoding="utf-8")

print("[OK] cleanup applied")
print("[OK] backup:", backup)
