#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

FILE = Path("core/builders/hybrid_builder.py")

content = FILE.read_text(encoding="utf-8")

start = content.find("# Calcul robuste des fins")

if start == -1:
    print("[ERROR] Marker not found")
    exit(1)

end = content.find("\n\n        return result", start)

if end == -1:
    print("[ERROR] End marker not found")
    exit(1)


new_block = """# Calcul des fins sécurisé

        for i in range(len(result.tracks)-1):

            current = result.tracks[i]
            nxt = result.tracks[i + 1]

            if nxt.start > current.start:
                current.end = nxt.start
            else:
                current.end = current.start
"""


content = (
    content[:start]
    + new_block
    + content[end:]
)

FILE.write_text(content, encoding="utf-8")

print("[OK] HybridBuilder patched")
