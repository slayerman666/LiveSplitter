import json

src = "/storage/emulated/0/LiveSplitter4/cookies.txt"
dst = "/storage/emulated/0/LiveSplitter4/cookies_netscape.txt"


with open(src, "r", encoding="utf-8") as f:
    cookies = json.load(f)


with open(dst, "w", encoding="utf-8") as f:

    f.write("# Netscape HTTP Cookie File\n")

    for c in cookies:

        domain = c.get("domain","")
        include = "TRUE" if domain.startswith(".") else "FALSE"
        path = c.get("path","/")
        secure = "TRUE" if c.get("secure") else "FALSE"
        expires = str(
            int(c.get("expirationDate",0))
        )
        name = c.get("name","")
        value = c.get("value","")

        f.write(
            "\t".join([
                domain,
                include,
                path,
                secure,
                expires,
                name,
                value
            ])
            + "\n"
        )


print("OK:", dst)
