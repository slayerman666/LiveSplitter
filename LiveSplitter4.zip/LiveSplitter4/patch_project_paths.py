from pathlib import Path

path = Path("core/project.py")
text = path.read_text(encoding="utf-8")

needle = '''            "logs":'''

insert = '''            "normalized_setlist":
                os.path.join(
                    path,
                    "Analysis",
                    "Results",
                    "normalized_setlist.json"
                ),

'''

if "normalized_setlist" in text:
    print("normalized_setlist existe déjà.")
    raise SystemExit(0)

idx = text.find(needle)
if idx == -1:
    print("Impossible de trouver le bloc logs.")
    raise SystemExit(1)

text = text[:idx] + insert + text[idx:]

path.write_text(text, encoding="utf-8")

print("project.py patché.")
