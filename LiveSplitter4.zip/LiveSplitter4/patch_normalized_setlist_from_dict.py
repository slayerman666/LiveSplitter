#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Patch LiveSplitter V4

Ajoute NormalizedSetlist.from_dict()
pour reconstruire un objet depuis
normalized_setlist.json
"""

import os


FILE = "core/models/setlist.py"


OLD = """        return {
            "mode": self.mode,
            "count": len(self.tracks),
            "tracks": [
                vars(track)
                for track in self.tracks
            ]
        }
"""


NEW = """        return {
            "mode": self.mode,
            "count": len(self.tracks),
            "tracks": [
                vars(track)
                for track in self.tracks
            ]
        }


    @classmethod
    def from_dict(cls, data):

        result = cls(
            mode=data.get(
                "mode",
                "unknown"
            )
        )

        for item in data.get(
            "tracks",
            []
        ):

            result.add(
                Track(
                    number=item.get(
                        "number",
                        0
                    ),

                    title=item.get(
                        "title",
                        ""
                    ),

                    start=item.get(
                        "start",
                        0
                    ),

                    end=item.get(
                        "end",
                        0
                    ),

                    confidence=item.get(
                        "confidence",
                        0
                    ),

                    source=item.get(
                        "source",
                        "unknown"
                    ),

                    metadata=item.get(
                        "metadata",
                        {}
                    )
                )
            )

        return result
"""


def patch():

    if not os.path.exists(FILE):
        raise FileNotFoundError(FILE)


    with open(
        FILE,
        "r",
        encoding="utf-8"
    ) as f:
        content = f.read()


    if "def from_dict" in content:
        print(
            "[INFO] Patch déjà appliqué"
        )
        return


    if OLD not in content:
        raise Exception(
            "Bloc to_dict introuvable - aucun changement effectué"
        )


    content = content.replace(
        OLD,
        NEW,
        1
    )


    with open(
        FILE,
        "w",
        encoding="utf-8"
    ) as f:
        f.write(content)


    print(
        "[OK] setlist.py patché"
    )


if __name__ == "__main__":
    patch()
