# -*- coding: utf-8 -*-

"""
Test Mode Manager
"""

from core.mode import ModeManager



for mode in [
    "as_is",
    "auto",
    "hybrid",
    "unknown"
]:

    manager = ModeManager(
        mode
    )

    print(
        mode,
        manager.validate(),
        manager.get_mode()
    )
