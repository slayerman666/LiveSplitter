from core.project import Project
import os


project = Project(
    "projects/Test_Project"
)


project.create(
    "Test Project"
)


print("\nProject recap:")
print(
    project.recap()
)


print("\nProject folders:")

for name, path in project.paths.items():

    status = (
        "OK"
        if os.path.exists(path)
        else "MISSING"
    )

    print(
        f"{name}: {status}"
    )
