#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil


FILE = Path("core/youtube.py")

backup = FILE.with_suffix(".py.bak_clients")

shutil.copy2(FILE, backup)

print("[OK] Backup :", backup)


text = FILE.read_text(
    encoding="utf-8"
)


old = '''"player_client": [
                            "web"
                        ]'''


new = '''"player_client": [
                            "web",
                            "android"
                        ]'''


if old in text:

    text = text.replace(
        old,
        new
    )

    print("[OK] get_info client corrigé")

else:

    print("[WARN] Bloc get_info non trouvé")


FILE.write_text(
    text,
    encoding="utf-8"
)

print("[OK] Terminé")
