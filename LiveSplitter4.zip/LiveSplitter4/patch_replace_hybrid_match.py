#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

FILE = Path("core/generators/hybrid.py")

NEW_MATCH = r'''    def match(
            self,
            setlist,
            transitions
    ):

        result = []

        if not setlist:
            return result

        transition_index = 0
        last_detected = 0

        for index, track in enumerate(setlist):

            number = track.get(
                "number",
                index + 1
            )

            title = track.get(
                "title",
                f"Track {index+1}"
            )

            expected = track.get(
                "time",
                last_detected
            )

            if index == 0:

                result.append(
                    TrackDecision(
                        number=number,
                        title=title,
                        expected=0,
                        detected=0,
                        correction=0,
                        status="START",
                        score=100
                    )
                )

                continue

            best = None
            best_index = None
            best_score = -1

            for idx in range(
                    transition_index,
                    len(transitions)
            ):

                candidate = transitions[idx]

                if candidate.time <= last_detected:
                    continue

                score = self.calculate_score(
                    candidate,
                    expected
                )

                if score > best_score:
                    best_score = score
                    best = candidate
                    best_index = idx

            if (
                best is not None
                and
                best_score >= self.match_threshold
            ):

                detected = best.time

                result.append(
                    TrackDecision(
                        number=number,
                        title=title,
                        expected=expected,
                        detected=detected,
                        correction=detected - expected,
                        status="MATCHED",
                        score=best_score
                    )
                )

                last_detected = detected
                transition_index = best_index + 1

            else:

                detected = max(
                    expected,
                    last_detected
                )

                result.append(
                    TrackDecision(
                        number=number,
                        title=title,
                        expected=expected,
                        detected=detected,
                        correction=0,
                        status="FALLBACK",
                        score=0
                    )
                )

                last_detected = detected

        return result

'''

text = FILE.read_text(encoding="utf-8")

start = text.find("    def match(")
end = text.find("    def compute_stats(", start)

if start == -1:
    print("[ERROR] match start not found")
    raise SystemExit(1)

if end == -1:
    print("[ERROR] compute_stats marker not found")
    raise SystemExit(1)

backup = FILE.with_suffix(".hybrid_match_before_global.bak")
backup.write_text(text, encoding="utf-8")

text = text[:start] + NEW_MATCH + "\n" + text[end:]

FILE.write_text(text, encoding="utf-8")

print("[OK] hybrid.py match() replaced")
print(f"[OK] Backup created: {backup}")
