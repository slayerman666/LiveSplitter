#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path
import shutil
import re

target = Path("core/generators/hybrid.py")

if not target.exists():
    print("[ERROR] hybrid.py not found")
    exit(1)

text = target.read_text(encoding="utf-8")

backup = target.with_name("hybrid.fallback_flow_v2.bak")
shutil.copy2(target, backup)

pattern = r"""            if\s*\(\s*
                best is not None\s*
                and best_score >= self\.match_threshold
            \):\s*
                detected = best\.time"""

replacement = """            if best is not None:

                strong_transition = (
                    best.score >= 90
                    and best.time > last_detected
                )

                if best_score >= self.match_threshold or strong_transition:
                    detected = best.time"""

new_text, count = re.sub(
    pattern,
    replacement,
    text,
    count=1,
    flags=re.MULTILINE
)

if count != 1:
    print("[ERROR] fallback condition not found")
    exit(1)

target.write_text(new_text, encoding="utf-8")

print("[OK] patched")
print("[OK] backup:", backup)
