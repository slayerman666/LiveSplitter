# -*- coding: utf-8 -*-

"""
LiveSplitter V4
Test Source Manager
"""

from core.project import Project
from core.source import SourceManager


project = Project(
    "projects/Test_Project"
)


project.load()


manager = SourceManager(
    project
)


info = manager.scan_source()


print("\nSource information:")
print(info)


print("\nProject recap:")
print(
    project.recap()
)
