#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from pathlib import Path

p = Path("core/youtube.py")

txt = p.read_text(
    encoding="utf-8"
)


target = '''            "noprogress":
                True
'''


insert = '''            "noprogress":
                True,

            "js_runtimes":
            {
                "deno":
                {}
            },

            "extractor_args":
            {
                "youtube":
                {
                    "player_client":
                    [
                        "android"
                    ]
                }
            }
'''


if target not in txt:

    print("[WARN] target not found")

else:

    txt = txt.replace(
        target,
        insert,
        1
    )

    p.write_text(
        txt,
        encoding="utf-8"
    )

    print("[OK] YouTube 403 options added")
