from pathlib import Path

p = Path("core/analyzer.py")

txt = p.read_text(encoding="utf-8")


# Ajouter l'import Project si absent
if "from core.project import Project" not in txt:
    txt = txt.replace(
        "from core.detectors import fusion",
        "from core.detectors import fusion\nfrom core.project import Project",
        1
    )


# Cherche self.project_dir et ajoute self.project juste après
marker = """        self.project_dir = os.path.dirname(
            os.path.dirname(
                audio_file
            )
        )
"""

insert = """        self.project_dir = os.path.dirname(
            os.path.dirname(
                audio_file
            )
        )

        self.project = Project(
            self.project_dir
        )

        try:
            self.project.load()
        except Exception:
            pass
"""

if marker in txt:
    # éviter double insertion
    if "self.project = Project(" not in txt:
        txt = txt.replace(
            marker,
            insert,
            1
        )
else:
    print("[WARN] bloc project_dir introuvable")


# Corriger les logs
txt = txt.replace(
    '"ANALYSIS START",\n            self.project_dir',
    '"ANALYSIS START",\n            self.project'
)

txt = txt.replace(
    '"ANALYSIS COMPLETE : {len(self.results.get(\'markers\', []))} markers",\n            self.project_dir',
    '"ANALYSIS COMPLETE : {len(self.results.get(\'markers\', []))} markers",\n            self.project'
)


p.write_text(
    txt,
    encoding="utf-8"
)

print("Analyzer project fix2 appliqué")
