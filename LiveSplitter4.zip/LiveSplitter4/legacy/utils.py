#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter v2.0

Fonctions utilitaires communes.
"""

import os
import re


# =========================
# NETTOYAGE NOM FICHIER
# =========================

def sanitize_filename(name):

    replacements = {
        "?": "",
        "/": "-",
        "\\": "-",
        ":": "-",
        "*": "",
        "\"": "",
        "<": "",
        ">": "",
        "|": "-"
    }

    for old, new in replacements.items():
        name = name.replace(old, new)

    return name.strip()

# =========================
# NOM DE FICHIER
# =========================

def clean_name(text):

    """
    Supprime les caractères interdits
    pour les noms de fichiers.
    """

    return re.sub(
        r'[\\/:*?"<>|]',
        "-",
        str(text)
    )



# =========================
# TEMPS
# =========================

def time_to_seconds(value):

    """
    Convertit :
    01:23
    ou
    01:02:03

    en secondes.
    """

    parts = value.split(":")


    try:

        if len(parts) == 2:

            return (
                int(parts[0]) * 60
                +
                int(parts[1])
            )


        if len(parts) == 3:

            return (
                int(parts[0]) * 3600
                +
                int(parts[1]) * 60
                +
                int(parts[2])
            )


    except ValueError:

        return 0


    return 0



def seconds_to_time(seconds):

    """
    Convertit des secondes
    en HH:MM:SS.
    """

    seconds = int(seconds)


    hours = seconds // 3600

    minutes = (
        seconds % 3600
    ) // 60

    secs = seconds % 60


    if hours > 0:

        return (
            f"{hours:02d}:"
            f"{minutes:02d}:"
            f"{secs:02d}"
        )


    return (
        f"{minutes:02d}:"
        f"{secs:02d}"
    )



# =========================
# FICHIERS
# =========================

def list_files(folder, extensions):

    """
    Retourne les fichiers compatibles
    triés alphabétiquement.
    """

    if not os.path.exists(folder):

        return []


    result = []


    for file in os.listdir(folder):

        path = os.path.join(
            folder,
            file
        )


        if os.path.isfile(path):

            if file.lower().endswith(
                tuple(extensions)
            ):

                result.append(file)


    return sorted(result)



def choose_file(files):

    """
    Affiche une liste numérotée
    et retourne le choix utilisateur.
    """

    if not files:

        return None


    for index, file in enumerate(
        files,
        start=1
    ):

        print(
            f"{index} - {file}"
        )


    print("")


    try:

        choice = int(
            input("Choix : ")
        )


        if (
            choice >= 1
            and choice <= len(files)
        ):

            return files[
                choice - 1
            ]


    except ValueError:

        pass


    return None



# =========================
# IMAGE
# =========================

def image_mime(filename):

    """
    Retourne le type MIME
    d'une image.
    """

    ext = (
        os.path.splitext(filename)[1]
        .lower()
    )


    if ext in [".jpg", ".jpeg"]:

        return "image/jpeg"


    if ext == ".png":

        return "image/png"


    return "application/octet-stream"



# =========================
# AFFICHAGE
# =========================

def status(value):

    """
    Retourne un glyphe
    selon l'état.
    """

    if value:

        return "✅"

    return "❌"
