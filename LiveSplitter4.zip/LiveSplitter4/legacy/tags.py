#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter - Tags Engine v1.0

Gestion des tags ID3 MP3
"""

import os
from mutagen.id3 import (
    ID3,
    TIT2,
    TPE1,
    TALB,
    TRCK,
    TDRC,
    TCON,
    APIC
)


# =========================
# AJOUT TAGS
# =========================

def add_tags(
        filename,
        track_number,
        title,
        config
):


    audio = ID3()


    audio.add(

        TPE1(
            encoding=3,
            text=config["artist"]
        )

    )


    audio.add(

        TALB(
            encoding=3,
            text=config["album"]
        )

    )


    audio.add(

        TIT2(
            encoding=3,
            text=title
        )

    )


    audio.add(

        TRCK(
            encoding=3,
            text=str(track_number)
        )

    )


    audio.add(

        TDRC(
            encoding=3,
            text=str(config["year"])
        )

    )


    audio.add(

        TCON(
            encoding=3,
            text=config["genre"]
        )

    )


    # =====================
    # POCHETTE
    # =====================

    artwork = config.get(
        "cover"
    )


    if artwork and os.path.exists(artwork):


        with open(

            artwork,

            "rb"

        ) as img:


            audio.add(

                APIC(

                    encoding=3,

                    mime="image/jpeg",

                    type=3,

                    desc="Front Cover",

                    data=img.read()

                )

            )



    audio.save(
        filename,
        v2_version=3
    )



# =========================
# TEST
# =========================

if __name__ == "__main__":

    print(
        "Module tags.py OK"
    )
