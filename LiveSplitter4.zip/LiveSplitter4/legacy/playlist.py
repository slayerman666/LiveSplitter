#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter v2.1.2

Générateur playlist M3U compatible Android
avec chemins absolus.
"""

import os



# =========================
# CREATION PLAYLIST
# =========================

def create_playlist(
        album_folder,
        album_name
):

    if not os.path.isdir(album_folder):

        return None



    tracks = []


    for filename in os.listdir(album_folder):

        if filename.lower().endswith(".mp3"):

            tracks.append(filename)



    if not tracks:

        return None



    tracks.sort()



    playlist = os.path.join(
        album_folder,
        album_name + ".m3u"
    )



    lines = []

    lines.append(
        "#EXTM3U"
    )



    for track in tracks:


        title = os.path.splitext(
            track
        )[0]


        lines.append(
            "#EXTINF:-1," + title
        )


        # Chemin complet Android

        full_path = os.path.abspath(
            os.path.join(
                album_folder,
                track
            )
        )


        lines.append(
            full_path
        )



    content = "\n".join(lines) + "\n"



    # Ecriture brute UTF-8 avec vrais LF

    with open(
        playlist,
        "wb"
    ) as file:


        file.write(
            content.encode("utf-8")
        )



    return playlist
