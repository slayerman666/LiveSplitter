#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
LiveSplitter - Setlist Engine v1.4

Mode AUTO :
Association transitions détectées + estimation

Mode MANUEL :
Lecture d'une setlist horodatée
"""

import os

# =========================
# CONVERSION TEMPS
# =========================

def time_to_seconds(value):

    parts = value.strip().split(":")

    if len(parts) == 3:

        h, m, s = parts

        return (
            int(h) * 3600
            +
            int(m) * 60
            +
            int(s)
        )

    elif len(parts) == 2:

        m, s = parts

        return (
            int(m) * 60
            +
            int(s)
        )

    else:

        return int(parts[0])



# =========================
# CHARGEMENT SETLIST MANUELLE
# =========================

def load_manual_setlist(filename):

    tracks = []


    if not os.path.exists(filename):

        print(
            "❌ Setlist introuvable :",
            filename
        )

        return tracks



    with open(
        filename,
        "r",
        encoding="utf-8"
    ) as file:


        for line in file:


            line = line.strip()


            if not line:
                continue


            if line.startswith("#"):
                continue


            try:

                number, title, timestamp = line.split("|")


                tracks.append(

                    {
                        "number": int(number),
                        "title": title.strip(),
                        "time": time_to_seconds(timestamp),
                        "type": "MANUAL",
                        "score": 100
                    }

                )


            except Exception:

                continue



    return tracks

# =========================
# CHARGEMENT SETLIST GENERIQUE
# =========================

def load_setlist(filename):

    tracks = []

    if not os.path.exists(filename):

        print(
            "❌ Setlist introuvable :",
            filename
        )

        return tracks


    with open(
        filename,
        "r",
        encoding="utf-8"
    ) as file:


        for index, line in enumerate(file, start=1):

            line = line.strip()


            if not line:
                continue


            if line.startswith("#"):
                continue


            # Format avec timing
            if "|" in line:

                try:

                    number, title, timestamp = line.split("|")

                    tracks.append(
                        {
                            "number": int(number),
                            "title": title.strip(),
                            "time": time_to_seconds(timestamp),
                            "type": "MANUAL",
                            "score": 100
                        }
                    )

                except Exception:
                    continue


            # Format sans timing
            else:

                tracks.append(
                    {
                        "number": index,
                        "title": line,
                    }
                )


    return tracks


# =========================
# RECHERCHE AUTO
# =========================

def find_transition(
        expected,
        transitions,
        used,
        tolerance=120
):

    best = None
    best_delta = None


    for index, item in enumerate(transitions):


        if index in used:
            continue


        delta = abs(
            item["time"]
            -
            expected
        )


        if delta <= tolerance:


            if (
                best_delta is None
                or
                delta < best_delta
            ):

                best_delta = delta

                best = (
                    index,
                    item
                )


    return best



# =========================
# MATCH AUTO
# =========================

def match_setlist(transitions):


    result = []

    used = set()


    for number, song in enumerate(
        SETLIST,
        start=1
    ):


        title, expected = song


        if expected == 0:


            result.append(

                {
                    "number": number,
                    "title": title,
                    "time": 0,
                    "type": "AUTO",
                    "score": 100
                }

            )

            continue



        match = find_transition(
            expected,
            transitions,
            used
        )


        if match:


            index, item = match

            used.add(index)


            result.append(

                {
                    "number": number,
                    "title": title,
                    "time": item["time"],
                    "type": "AUTO",
                    "score": item["score"]
                }

            )


        else:


            result.append(

                {
                    "number": number,
                    "title": title,
                    "time": expected,
                    "type": "ESTIME",
                    "score": 0
                }

            )


    return result



# =========================
# RAPPORT
# =========================

def print_report(result):


    for item in result:

        print(
            f'{item["number"]:02d} - '
            f'{item["title"]:<25} '
            f'{item["time"]:>5}s '
            f'{item["type"]:<7} '
            f'⭐{item["score"]}'
        )



# =========================
# TEST
# =========================

if __name__ == "__main__":

    import sys
    import ast


    if len(sys.argv) > 1:

        transitions = ast.literal_eval(
            sys.argv[1]
        )

        print_report(
            match_setlist(transitions)
        )
